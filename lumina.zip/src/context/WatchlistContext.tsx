import React, { createContext, useContext, useState, useEffect } from "react";
import { MediaItem, WatchlistItem } from "../types";
import { useAuth } from "./AuthContext";

interface WatchlistContextType {
  watchlist: WatchlistItem[];
  addToWatchlist: (item: MediaItem) => void;
  removeFromWatchlist: (id: number) => void;
  isInWatchlist: (id: number) => boolean;
}

const WatchlistContext = createContext<WatchlistContextType | undefined>(undefined);

export const WatchlistProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, currentProfile } = useAuth();
  const [watchlist, setWatchlist] = useState<WatchlistItem[]>([]);

  // Construct a profile-specific storage key
  const getStorageKey = () => {
    if (user && currentProfile) {
      return `lumina_watchlist_${user.email}_${currentProfile.id}`;
    }
    return null;
  };

  // Synchronize on mount and whenever user or currentProfile changes
  useEffect(() => {
    const key = getStorageKey();
    if (key) {
      try {
        const stored = localStorage.getItem(key);
        if (stored) {
          setWatchlist(JSON.parse(stored));
        } else {
          setWatchlist([]);
        }
      } catch (e) {
        console.error("Could not read profile watchlist from localStorage", e);
        setWatchlist([]);
      }
    } else {
      setWatchlist([]);
    }
  }, [user?.email, currentProfile?.id]);

  const saveWatchlist = (updated: WatchlistItem[]) => {
    setWatchlist(updated);
    const key = getStorageKey();
    if (key) {
      try {
        localStorage.setItem(key, JSON.stringify(updated));
      } catch (e) {
        console.error("Could not persist watchlist to localStorage", e);
      }
    }
  };

  const addToWatchlist = (item: MediaItem) => {
    if (watchlist.some((w) => w.id === item.id)) return;

    const newItem: WatchlistItem = {
      id: item.id,
      media_type: item.media_type,
      title: item.title || item.name || item.original_title || "Untitled",
      poster_path: item.poster_path,
      backdrop_path: item.backdrop_path,
      vote_average: item.vote_average,
      release_date: item.release_date || item.first_air_date,
      addedAt: new Date().toISOString(),
    };

    saveWatchlist([newItem, ...watchlist]);
  };

  const removeFromWatchlist = (id: number) => {
    saveWatchlist(watchlist.filter((w) => w.id !== id));
  };

  const isInWatchlist = (id: number) => {
    return watchlist.some((w) => w.id === id);
  };

  return (
    <WatchlistContext.Provider value={{ watchlist, addToWatchlist, removeFromWatchlist, isInWatchlist }}>
      {children}
    </WatchlistContext.Provider>
  );
};

export const useWatchlist = () => {
  const context = useContext(WatchlistContext);
  if (!context) {
    throw new Error("useWatchlist must be used within a WatchlistProvider");
  }
  return context;
};
