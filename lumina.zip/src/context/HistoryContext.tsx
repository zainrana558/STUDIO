import React, { createContext, useContext, useState, useEffect } from "react";
import { MediaItem, WatchHistory } from "../types";
import { useAuth } from "./AuthContext";

interface HistoryContextType {
  history: WatchHistory[];
  updateHistory: (item: MediaItem | { id: number; title: string; poster_path: string; backdrop_path: string; media_type?: 'movie' | 'tv' }, currentTime: number, duration: number) => void;
  removeFromHistory: (id: number) => void;
  clearHistory: () => void;
  getHistoryItem: (id: number) => WatchHistory | undefined;
}

const HistoryContext = createContext<HistoryContextType | undefined>(undefined);

export const HistoryProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, currentProfile } = useAuth();
  const [history, setHistory] = useState<WatchHistory[]>([]);

  // Construct a profile-specific storage key
  const getStorageKey = () => {
    if (user && currentProfile) {
      return `lumina_history_${user.email}_${currentProfile.id}`;
    }
    return null;
  };

  // Synchronize on mount and whenever user or currentProfile changes
  useEffect(() => {
    const key = getStorageKey();
    if (key) {
      try {
        const stored = localStorage.getItem(key);
        if (stored) {
          setHistory(JSON.parse(stored));
        } else {
          setHistory([]);
        }
      } catch (e) {
        console.error("Could not read watch history from localStorage", e);
        setHistory([]);
      }
    } else {
      setHistory([]);
    }
  }, [user?.email, currentProfile?.id]);

  const saveHistory = (updated: WatchHistory[]) => {
    setHistory(updated);
    const key = getStorageKey();
    if (key) {
      try {
        localStorage.setItem(key, JSON.stringify(updated));
      } catch (e) {
        console.error("Could not persist history to localStorage", e);
      }
    }
  };

  const updateHistory = (
    item: any,
    currentTime: number,
    duration: number
  ) => {
    if (!item?.id) return;
    
    const safeDuration = duration > 0 ? duration : 3600; // default 1 hour if not specified
    const progress = Math.min(100, Math.max(0, parseFloat(((currentTime / safeDuration) * 100).toFixed(1))));

    // Build the history item
    const historyItem: WatchHistory = {
      id: item.id,
      media_type: item.media_type || 'movie',
      title: item.title || item.name || item.original_title || "Untitled Video",
      poster_path: item.poster_path || "",
      backdrop_path: item.backdrop_path || "",
      progress,
      currentTime: Math.floor(currentTime),
      duration: Math.floor(safeDuration),
      watchedAt: new Date().toISOString(),
    };

    // Filter out previous record if exists
    const cleanHistory = history.filter((h) => h.id !== item.id);
    
    // Add to top of array
    saveHistory([historyItem, ...cleanHistory]);
  };

  const removeFromHistory = (id: number) => {
    saveHistory(history.filter((h) => h.id !== id));
  };

  const clearHistory = () => {
    saveHistory([]);
  };

  const getHistoryItem = (id: number) => {
    return history.find((h) => h.id === id);
  };

  return (
    <HistoryContext.Provider
      value={{
        history,
        updateHistory,
        removeFromHistory,
        clearHistory,
        getHistoryItem,
      }}
    >
      {children}
    </HistoryContext.Provider>
  );
};

export const useHistory = () => {
  const context = useContext(HistoryContext);
  if (!context) {
    throw new Error("useHistory must be used within a HistoryProvider");
  }
  return context;
};
