import React, { createContext, useContext, useState, useEffect } from "react";

export interface UserProfile {
  id: string;
  name: string;
  avatarIdx: number; // 0 to 4
  bgColor: string; // Tailwind color representation
}

export interface UserAccount {
  email: string;
  provider: "email" | "google" | "github";
}

interface AuthContextType {
  user: UserAccount | null;
  profiles: UserProfile[];
  currentProfile: UserProfile | null;
  loading: boolean;
  login: (email: string, provider?: "email" | "google" | "github") => Promise<void>;
  signup: (email: string) => Promise<void>;
  logout: () => void;
  selectProfile: (profileId: string) => void;
  createProfile: (name: string, avatarIdx: number) => boolean;
  deleteProfile: (profileId: string) => boolean;
  editProfile: (profileId: string, name: string, avatarIdx: number) => boolean;
  clearActiveProfile: () => void;
}

const PRESET_AVATARS = [
  { idx: 0, bgColor: "from-[#ff073a] to-[#bf00ff]" }, // Neon Red to Magenta
  { idx: 1, bgColor: "from-[#00f0ff] to-[#0072ff]" }, // Cyan to Blue
  { idx: 2, bgColor: "from-[#39ff14] to-[#0575e6]" }, // Lime Green to Blue
  { idx: 3, bgColor: "from-[#f107a3] to-[#7b2ff7]" }, // Pink to Deep Purple
  { idx: 4, bgColor: "from-[#ffb300] to-[#f77737]" }, // Amber Gold to Orange
];

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<UserAccount | null>(null);
  const [profiles, setProfiles] = useState<UserProfile[]>([]);
  const [currentProfile, setCurrentProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  // Initialize Auth state from localStorage
  useEffect(() => {
    try {
      const savedUser = localStorage.getItem("lumina_auth_user");
      if (savedUser) {
        const u = JSON.parse(savedUser);
        setUser(u);
        
        // Load profiles for this user
        const savedProfiles = localStorage.getItem(`lumina_profiles_${u.email}`);
        if (savedProfiles) {
          const loadedProfiles = JSON.parse(savedProfiles);
          setProfiles(loadedProfiles);
          
          // Load active profile if any
          const savedActiveProfileId = localStorage.getItem(`lumina_active_profile_id_${u.email}`);
          if (savedActiveProfileId) {
            const active = loadedProfiles.find((p: UserProfile) => p.id === savedActiveProfileId);
            if (active) setCurrentProfile(active);
          }
        } else {
          // Setup a default initial profile
          const defaultProfile: UserProfile = {
            id: "p_default",
            name: "Main Profile",
            avatarIdx: 0,
            bgColor: PRESET_AVATARS[0].bgColor,
          };
          const initialProfiles = [defaultProfile];
          setProfiles(initialProfiles);
          localStorage.setItem(`lumina_profiles_${u.email}`, JSON.stringify(initialProfiles));
        }
      }
    } catch (e) {
      console.error("Failed to initialize auth state", e);
    } finally {
      setLoading(false);
    }
  }, []);

  const login = async (email: string, provider: "email" | "google" | "github" = "email") => {
    setLoading(true);
    const u: UserAccount = { email, provider };
    setUser(u);
    localStorage.setItem("lumina_auth_user", JSON.stringify(u));

    // Pull or initialize profiles for this user account
    const savedProfiles = localStorage.getItem(`lumina_profiles_${email}`);
    let loadedProfiles: UserProfile[] = [];
    if (savedProfiles) {
      loadedProfiles = JSON.parse(savedProfiles);
    } else {
      loadedProfiles = [
        {
          id: Math.random().toString(36).substring(2, 9),
          name: email.split("@")[0].toUpperCase(),
          avatarIdx: 0,
          bgColor: PRESET_AVATARS[0].bgColor,
        },
      ];
      localStorage.setItem(`lumina_profiles_${email}`, JSON.stringify(loadedProfiles));
    }
    setProfiles(loadedProfiles);
    
    // Auto-select first profile if only one index exists
    if (loadedProfiles.length === 1) {
      setCurrentProfile(loadedProfiles[0]);
      localStorage.setItem(`lumina_active_profile_id_${email}`, loadedProfiles[0].id);
    } else {
      setCurrentProfile(null);
      localStorage.removeItem(`lumina_active_profile_id_${email}`);
    }
    setLoading(false);
  };

  const signup = async (email: string) => {
    await login(email, "email");
  };

  const logout = () => {
    if (user) {
      localStorage.removeItem(`lumina_active_profile_id_${user.email}`);
    }
    setUser(null);
    setProfiles([]);
    setCurrentProfile(null);
    localStorage.removeItem("lumina_auth_user");
  };

  const selectProfile = (profileId: string) => {
    if (!user) return;
    const profile = profiles.find((p) => p.id === profileId);
    if (profile) {
      setCurrentProfile(profile);
      localStorage.setItem(`lumina_active_profile_id_${user.email}`, profileId);
    }
  };

  const createProfile = (name: string, avatarIdx: number): boolean => {
    if (!user) return false;
    if (profiles.length >= 5) return false; // up to 5 profiles

    const newProfile: UserProfile = {
      id: Math.random().toString(36).substring(2, 9),
      name: name.trim() || `Profile ${profiles.length + 1}`,
      avatarIdx,
      bgColor: PRESET_AVATARS[avatarIdx]?.bgColor || PRESET_AVATARS[0].bgColor,
    };

    const updated = [...profiles, newProfile];
    setProfiles(updated);
    localStorage.setItem(`lumina_profiles_${user.email}`, JSON.stringify(updated));
    return true;
  };

  const deleteProfile = (profileId: string): boolean => {
    if (!user) return false;
    if (profiles.length <= 1) return false; // Must keep at least 1 profile

    const updated = profiles.filter((p) => p.id !== profileId);
    setProfiles(updated);
    localStorage.setItem(`lumina_profiles_${user.email}`, JSON.stringify(updated));

    if (currentProfile?.id === profileId) {
      const fallback = updated[0];
      setCurrentProfile(fallback);
      localStorage.setItem(`lumina_active_profile_id_${user.email}`, fallback.id);
    }
    return true;
  };

  const editProfile = (profileId: string, name: string, avatarIdx: number): boolean => {
    if (!user) return false;
    const updated = profiles.map((p) => {
      if (p.id === profileId) {
        return {
          ...p,
          name: name.trim() || p.name,
          avatarIdx,
          bgColor: PRESET_AVATARS[avatarIdx]?.bgColor || p.bgColor,
        };
      }
      return p;
    });

    setProfiles(updated);
    localStorage.setItem(`lumina_profiles_${user.email}`, JSON.stringify(updated));

    if (currentProfile?.id === profileId) {
      const updatedProfile = updated.find((p) => p.id === profileId);
      if (updatedProfile) setCurrentProfile(updatedProfile);
    }
    return true;
  };

  const clearActiveProfile = () => {
    if (user) {
      localStorage.removeItem(`lumina_active_profile_id_${user.email}`);
    }
    setCurrentProfile(null);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        profiles,
        currentProfile,
        loading,
        login,
        signup,
        logout,
        selectProfile,
        createProfile,
        deleteProfile,
        editProfile,
        clearActiveProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
};

export const AVATAR_PRESETS = PRESET_AVATARS;
