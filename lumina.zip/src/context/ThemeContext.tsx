import React, { createContext, useContext, useState, useEffect } from "react";
import { MediaItem } from "../types";

export type ThemeMode = "classic" | "anime" | "playful" | "abyss" | "cosmic";

export interface ThemeConfig {
  id: ThemeMode;
  name: string;
  tagline: string;
  fontFamily: string;
  bgColor: string;
  accentColor: string;
  accentGlow: string;
  cardRadius: string;
  cardBorder: string;
  animationPhysics: {
    damping: number;
    stiffness: number;
    mass: number;
  };
}

export const THEME_SPECS: Record<ThemeMode, ThemeConfig> = {
  classic: {
    id: "classic",
    name: "Cinematic Classic",
    tagline: "Golden age of cinema",
    fontFamily: "font-sans",
    bgColor: "#0B0E11",
    accentColor: "#d4af37", // Metallic Gold
    accentGlow: "rgba(212, 175, 55, 0.4)",
    cardRadius: "rounded-xl",
    cardBorder: "border-white/5 hover:border-[#d4af37]/40",
    animationPhysics: {
      damping: 25,
      stiffness: 120,
      mass: 1.0,
    },
  },
  anime: {
    id: "anime",
    name: "Otaku Mode",
    tagline: "Neon electric cyberpunk anime stream",
    fontFamily: "font-anime",
    bgColor: "#0d1117", // Slate dark
    accentColor: "#00f0ff", // Electric Cyan
    accentGlow: "rgba(0, 240, 255, 0.5)",
    cardRadius: "rounded-none", // Sharp edges
    cardBorder: "border-white/10 hover:border-[#00f0ff]/80",
    animationPhysics: {
      damping: 15,
      stiffness: 220, // Snappy & intense
      mass: 0.8,
    },
  },
  playful: {
    id: "playful",
    name: "Playful Mode",
    tagline: "Bouncy animation & soft pastels",
    fontFamily: "font-playful",
    bgColor: "#0e0b16", // Deep royal violet base
    accentColor: "#ff007f", // Bubblegum Pink / Pink accent
    accentGlow: "rgba(255, 0, 127, 0.4)",
    cardRadius: "rounded-2xl", // Plump rounded corners
    cardBorder: "border-white/5 hover:border-[#ff007f]/50",
    animationPhysics: {
      damping: 8, // Bouncy elastic springs
      stiffness: 100,
      mass: 0.7,
    },
  },
  abyss: {
    id: "abyss",
    name: "The Abyss",
    tagline: "Vignette obsidian absolute dark horror",
    fontFamily: "font-serif-horror",
    bgColor: "#050505", // Deep pitch dark
    accentColor: "#be0000", // Crimson Red
    accentGlow: "rgba(190, 0, 0, 0.3)",
    cardRadius: "rounded-none", // Editorial zero border-radius
    cardBorder: "border-white/5 hover:border-[#be0000]/60",
    animationPhysics: {
      damping: 40, // Slow burning, creepy slow ease
      stiffness: 70,
      mass: 1.4,
    },
  },
  cosmic: {
    id: "cosmic",
    name: "Cosmic Mode",
    tagline: "Neon stellar glowing space navy & plasma",
    fontFamily: "font-cosmic",
    bgColor: "#020210", // Space navy deep space
    accentColor: "#bf00ff", // Plasma Purple
    accentGlow: "rgba(191, 0, 255, 0.5)",
    cardRadius: "rounded-xl",
    cardBorder: "border-white/5 hover:border-[#bf00ff]/60",
    animationPhysics: {
      damping: 30, // Ethereal floaty physics
      stiffness: 80,
      mass: 1.2,
    },
  },
};

interface ThemeContextType {
  activeTheme: ThemeMode;
  config: ThemeConfig;
  setTheme: (theme: ThemeMode) => void;
  autoDetectTheme: (item: MediaItem | null) => void;
  autoDetectByGenreId: (genreId: number) => void;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export const ThemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [activeTheme, setActiveThemeState] = useState<ThemeMode>("classic");

  // Load selection from storage on startup
  useEffect(() => {
    const saved = localStorage.getItem("lumina_aesthetic_theme");
    if (saved && Object.keys(THEME_SPECS).includes(saved)) {
      setTheme(saved as ThemeMode);
    }
  }, []);

  const setTheme = (theme: ThemeMode) => {
    setActiveThemeState(theme);
    localStorage.setItem("lumina_aesthetic_theme", theme);

    // Dynamic document body/root style injection
    const config = THEME_SPECS[theme];
    const root = document.documentElement;

    root.style.setProperty("--theme-bg", config.bgColor);
    root.style.setProperty("--theme-accent", config.accentColor);
    root.style.setProperty("--theme-glow", config.accentGlow);

    // Apply exact class combinations to the <html> tag for global cascade rules
    Object.keys(THEME_SPECS).forEach((tName) => {
      root.classList.remove(`theme-${tName}`);
    });
    root.classList.add(`theme-${theme}`);
    
    // Set matching background color for body
    document.body.style.backgroundColor = config.bgColor;
  };

  // Helper routine to automatically morph theme based on browsed media item characteristics
  const autoDetectTheme = (item: MediaItem | null) => {
    if (!item) return;

    // Direct genre ID arrays check
    const genreIds = item.genre_ids || [];
    const nameStr = (item.title || item.name || "").toLowerCase();

    // 1. ANIME (Otaku Mode) - Animation + Japanese keywords / name check
    if (
      genreIds.includes(16) && 
      (nameStr.includes("anime") || nameStr.includes("season") || nameStr.includes("naruto") || nameStr.includes("demon") || nameStr.includes("titan") || nameStr.includes("dragon ball") || nameStr.includes("hero"))
    ) {
      setTheme("anime");
      return;
    }

    // 2. CARTOON / PLAYFUL - General Family Animation
    if (genreIds.includes(16) || genreIds.includes(10751)) {
      setTheme("playful");
      return;
    }

    // 3. HORROR (The Abyss) - Horror (27), Thriller (53), Mystery (9648)
    if (genreIds.includes(27) || genreIds.includes(53) || genreIds.includes(9648)) {
      setTheme("abyss");
      return;
    }

    // 4. SCI-FI & FANTASY (Cosmic) - Sci-Fi (878), Fantasy (14), Adventure (12)
    if (genreIds.includes(878) || genreIds.includes(14)) {
      setTheme("cosmic");
      return;
    }

    // Default back to Cinematic Classic
    setTheme("classic");
  };

  // Switch based on clicks of specific menu genre buttons
  const autoDetectByGenreId = (genreId: number) => {
    if ([16].includes(genreId)) {
      setTheme("anime");
    } else if ([10751].includes(genreId)) {
      setTheme("playful");
    } else if ([27, 53, 9648].includes(genreId)) {
      setTheme("abyss");
    } else if ([878, 14].includes(genreId)) {
      setTheme("cosmic");
    } else {
      setTheme("classic");
    }
  };

  const config = THEME_SPECS[activeTheme];

  return (
    <ThemeContext.Provider
      value={{
        activeTheme,
        config,
        setTheme,
        autoDetectTheme,
        autoDetectByGenreId,
      }}
    >
      <div 
        id="theme-root-wrapper"
        className={`w-full min-h-screen transition-colors duration-500 text-gray-100 ${config.fontFamily}`}
        style={{ backgroundColor: config.bgColor }}
      >
        {children}
      </div>
    </ThemeContext.Provider>
  );
};

export const useAestheticTheme = () => {
  const context = useContext(ThemeContext);
  if (context === undefined) {
    throw new Error("useAestheticTheme must be used inside a ThemeProvider");
  }
  return context;
};
