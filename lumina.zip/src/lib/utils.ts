import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

/**
 * Merge Tailwind classes with clsx and tailwind-merge
 */
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/**
 * Format time in seconds to HH:MM:SS or MM:SS
 */
export function formatTime(seconds: number): string {
  if (isNaN(seconds) || seconds === Infinity || seconds < 0) return "00:00";
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);

  const mStr = String(m).padStart(2, "0");
  const sStr = String(s).padStart(2, "0");

  if (h > 0) {
    const hStr = String(h).padStart(2, "0");
    return `${hStr}:${mStr}:${sStr}`;
  }
  return `${mStr}:${sStr}`;
}

/**
 * Resolve TMDB image paths with beautiful dark cyberpunk fallbacks
 */
export function getImageUrl(
  path: string | null | undefined,
  size: 'w342' | 'w500' | 'w780' | 'w1280' | 'original' = 'w500',
  fallbackType: 'poster' | 'backdrop' | 'avatar' = 'poster'
): string {
  if (path && path.startsWith('http')) {
    return path;
  }
  if (path) {
    return `https://image.tmdb.org/t/p/${size}${path}`;
  }

  // Neon Cyberpunk fallbacks from Unsplash that look premium
  if (fallbackType === 'backdrop') {
    return "https://images.unsplash.com/photo-1542751371-adc38448a05e?q=80&w=1200&auto=format&fit=crop"; // Cyberpunk gaming vibe
  }
  if (fallbackType === 'avatar') {
    return "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?q=80&w=300&auto=format&fit=crop"; // Standard avatar
  }
  // Default Poster
  return "https://images.unsplash.com/photo-1578301978693-85fa9c0320b9?q=80&w=500&auto=format&fit=crop"; // Neon grid art poster fallback
}
