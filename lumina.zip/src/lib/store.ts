import { create } from "zustand";
import { MediaItem } from "../types";

export type ViewType = 'home' | 'trending' | 'movies' | 'tv' | 'watchlist' | 'history' | 'settings' | 'player' | 'genre';

interface AppStore {
  activeView: ViewType;
  setView: (view: ViewType) => void;
  selectedMedia: MediaItem | null;
  selectMedia: (media: MediaItem | null) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  
  // Dynamic genre hub switching
  activeGenre: string; // 'anime' | 'cartoons' | 'horror' | 'scifi' | 'movies'
  setGenreView: (genre: string) => void;
  
  // Custom config simulation
  playbackServer: string; // 'vidsrc' | 'embedsu' | 'trailer'
  setPlaybackServer: (server: string) => void;
  playbackQuality: string; // '1080p' | '720p' | 'auto'
  setPlaybackQuality: (quality: string) => void;

  // Fluid backdrop morphing
  hoveredMedia: MediaItem | null;
  setHoveredMedia: (media: MediaItem | null) => void;
}

export const useAppStore = create<AppStore>((set) => ({
  activeView: 'home',
  setView: (view) => set({ activeView: view }),
  selectedMedia: null,
  selectMedia: (media) => {
    set({ selectedMedia: media });
    if (media) {
      set({ activeView: 'player' });
    }
  },
  searchQuery: '',
  setSearchQuery: (query) => set({ searchQuery: query }),
  
  // Dynamic Genre State initializers
  activeGenre: 'anime',
  setGenreView: (genre) => set({ activeView: 'genre', activeGenre: genre }),
  
  // Global settings for streaming
  playbackServer: 'vidsrc',
  setPlaybackServer: (server) => set({ playbackServer: server }),
  playbackQuality: 'auto',
  setPlaybackQuality: (quality) => set({ playbackQuality: quality }),

  // Dynamic hover media
  hoveredMedia: null,
  setHoveredMedia: (media) => set({ hoveredMedia: media }),
}));
export default useAppStore;
