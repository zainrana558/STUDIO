import { MediaDetails, MediaItem } from "../../types";

export const MOCK_GENRES = [
  { id: 28, name: "Action" },
  { id: 12, name: "Adventure" },
  { id: 16, name: "Animation" },
  { id: 18, name: "Drama" },
  { id: 878, name: "Sci-Fi" },
  { id: 53, name: "Thriller" },
  { id: 10759, name: "Action & Adventure" },
  { id: 10765, name: "Sci-Fi & Fantasy" }
];

export const MOCK_MEDIA_ITEMS: MediaItem[] = [
  {
    id: 693134,
    title: "Dune: Part Two",
    overview: "Follow the mythic journey of Paul Atreides as he unites with Chani and the Fremen while on a path of revenge against the conspirators who destroyed his family. Facing a choice between the love of his life and the fate of the known universe, he endeavors to prevent a terrible future only he can foresee.",
    poster_path: "https://images.unsplash.com/photo-1547483238-f400e65ccd56?q=80&w=500&auto=format&fit=crop", // Desert dunes graphic
    backdrop_path: "https://images.unsplash.com/photo-1509316785289-025f5b846b35?q=80&w=1200&auto=format&fit=crop",
    media_type: "movie",
    release_date: "2024-02-27",
    vote_average: 8.3,
    genre_ids: [878, 12, 18],
  },
  {
    id: 105248,
    name: "Cyberpunk: Edgerunners",
    overview: "A street kid trying to survive in a technology and body modification-obsessed city of the future. Having everything to lose, he chooses to stay alive by becoming an edgerunner — a mercenary outlaw also known as a cyberpunk.",
    poster_path: "https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?q=80&w=500&auto=format&fit=crop", // Cyberpunk alleyway
    backdrop_path: "https://images.unsplash.com/photo-1515621061946-eff1c2a352bd?q=80&w=1200&auto=format&fit=crop", // Neon skyline
    media_type: "tv",
    first_air_date: "2022-09-13",
    vote_average: 8.6,
    genre_ids: [16, 10765, 10759],
  },
  {
    id: 335984,
    title: "Blade Runner 2049",
    overview: "Thirty years after the events of the first film, a new blade runner, LAPD Officer K, unearths a long-buried secret that has the potential to plunge what's left of society into chaos. K's discovery leads him on a quest to find Rick Deckard, a former LAPD blade runner who has been missing for 30 years.",
    poster_path: "https://images.unsplash.com/photo-1508739773434-c26b3d09e071?q=80&w=500&auto=format&fit=crop", // Neon orange forest
    backdrop_path: "https://images.unsplash.com/photo-1509198397868-475647b2a1e5?q=80&w=1200&auto=format&fit=crop", // Soft vaporwave city
    media_type: "movie",
    release_date: "2017-10-04",
    vote_average: 8.5,
    genre_ids: [878, 18, 53],
  },
  {
    id: 94605,
    name: "Arcane",
    overview: "Amid the stark discord of twin cities Piltover and Zaun, two sisters fight on rival sides of war between magic technologies and clashing convictions.",
    poster_path: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=500&auto=format&fit=crop", // Glowing neon shapes
    backdrop_path: "https://images.unsplash.com/photo-1563089145-599997674d42?q=80&w=1200&auto=format&fit=crop", // Vibrant magenta grid
    media_type: "tv",
    first_air_date: "2021-11-06",
    vote_average: 8.7,
    genre_ids: [16, 10765, 10759, 18],
  },
  {
    id: 157336,
    title: "Interstellar",
    overview: "The adventures of a group of explorers who make use of a newly discovered wormhole to surpass the limitations on human space travel and conquer the vast distances involved in an interstellar voyage.",
    poster_path: "https://images.unsplash.com/photo-1462331940025-496dfbfc7564?q=80&w=500&auto=format&fit=crop", // Nebula
    backdrop_path: "https://images.unsplash.com/photo-1451187580459-43490279c0fa?q=80&w=1200&auto=format&fit=crop", // Space cyber lines
    media_type: "movie",
    release_date: "2014-11-05",
    vote_average: 8.4,
    genre_ids: [878, 12, 18],
  },
  {
    id: 603,
    title: "The Matrix",
    overview: "Set in the 22nd century, The Matrix tells the story of a computer hacker who joins a group of underground insurgents fighting the vast and powerful computers who now rule the earth.",
    poster_path: "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?q=80&w=500&auto=format&fit=crop", // Matrix code rainfall
    backdrop_path: "https://images.unsplash.com/photo-1510511459019-5dda7724fd87?q=80&w=1200&auto=format&fit=crop", // Digital grid
    media_type: "movie",
    release_date: "1999-03-30",
    vote_average: 8.2,
    genre_ids: [878, 28],
  },
  {
    id: 86831,
    name: "Love, Death & Robots",
    overview: "Terrifying creatures, wicked surprises and dark comedy converge in this NSFW anthology of animated stories presented by Tim Miller and David Fincher.",
    poster_path: "https://images.unsplash.com/photo-1534447677768-be436bb09401?q=80&w=500&auto=format&fit=crop", // Dark red vortex
    backdrop_path: "https://images.unsplash.com/photo-1579783902614-a3fb3927b6a5?q=80&w=1200&auto=format&fit=crop", // Stylized abstract glowing art
    media_type: "tv",
    first_air_date: "2019-03-15",
    vote_average: 8.2,
    genre_ids: [16, 10765, 10759],
  },
  {
    id: 20526,
    title: "Tron: Legacy",
    overview: "Sam Flynn, the tech-savvy 27-year-old son of Kevin Flynn, looks into his father's disappearance and finds himself pulled into the same world of fierce programs and gladiatorial games where his father has been living for 20 years. Along with Kevin's loyal confidant, father and son embark on a life-and-death journey across a visually stunning cyber universe.",
    poster_path: "https://images.unsplash.com/photo-1481137344492-d5a06567210a?q=80&w=500&auto=format&fit=crop", // Orange & Blue glowing wires
    backdrop_path: "https://images.unsplash.com/photo-1478760329108-5c3ed9d495a0?q=80&w=1200&auto=format&fit=crop", // Deep blue gradient
    media_type: "movie",
    release_date: "2010-12-10",
    vote_average: 7.0,
    genre_ids: [878, 28, 12],
  },
  {
    id: 66732,
    name: "Stranger Things",
    overview: "When a young boy vanishes, a small town uncovers a mystery involving secret experiments, terrifying supernatural forces and one strange little girl.",
    poster_path: "https://images.unsplash.com/photo-1509198397868-475647b2a1e5?q=80&w=500&auto=format&fit=crop", // Spooky red/blue light
    backdrop_path: "https://images.unsplash.com/photo-1509114397022-ed747cca3f65?q=80&w=1200&auto=format&fit=crop", // Eerie red sunset silhouettes
    media_type: "tv",
    first_air_date: "2016-07-15",
    vote_average: 8.6,
    genre_ids: [10765, 18],
  },
  {
    id: 100088,
    name: "The Last of Us",
    overview: "Twenty years after modern civilization has been destroyed, Joel, a hardened survivor, is hired to smuggle Ellie, a 14-year-old girl, out of an oppressive quarantine zone. What starts as a small job soon becomes a brutal, heartbreaking journey, as they both must traverse the U.S. and depend on each other for survival.",
    poster_path: "https://images.unsplash.com/photo-1518818419601-72c8673f5852?q=80&w=500&auto=format&fit=crop", // Overgrown forest/reformed city
    backdrop_path: "https://images.unsplash.com/photo-1448375240586-882707db888b?q=80&w=1200&auto=format&fit=crop", // Overgrown mist woods
    media_type: "tv",
    first_air_date: "2023-01-15",
    vote_average: 8.7,
    genre_ids: [18, 10759],
  }
];

export const MOCK_MEDIA_DETAILS: Record<number, MediaDetails> = {
  693134: {
    id: 693134,
    title: "Dune: Part Two",
    overview: "Follow the mythic journey of Paul Atreides as he unites with Chani and the Fremen while on a path of revenge against the conspirators who destroyed his family. Facing a choice between the love of his life and the fate of the known universe, he endeavors to prevent a terrible future only he can foresee.",
    poster_path: "https://images.unsplash.com/photo-1547483238-f400e65ccd56?q=80&w=500&auto=format&fit=crop",
    backdrop_path: "https://images.unsplash.com/photo-1509316785289-025f5b846b35?q=80&w=1200&auto=format&fit=crop",
    media_type: "movie",
    release_date: "2024-02-27",
    vote_average: 8.3,
    status: "Released",
    runtime: 166,
    tagline: "Long live the fighters.",
    genres: [
      { id: 878, name: "Science Fiction" },
      { id: 12, name: "Adventure" },
      { id: 18, name: "Drama" }
    ],
    credits: {
      cast: [
        { id: 1, name: "Timothée Chalamet", character: "Paul Atreides", profile_path: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?q=80&w=150&auto=format&fit=crop" },
        { id: 2, name: "Zendaya", character: "Chani", profile_path: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=150&auto=format&fit=crop" },
        { id: 3, name: "Rebecca Ferguson", character: "Lady Jessica Atreides", profile_path: null },
        { id: 4, name: "Austin Butler", character: "Feyd-Rautha Harkonnen", profile_path: null }
      ]
    }
  },
  105248: {
    id: 105248,
    name: "Cyberpunk: Edgerunners",
    overview: "A street kid trying to survive in a technology and body modification-obsessed city of the future. Having everything to lose, he chooses to stay alive by becoming an edgerunner — a mercenary outlaw also known as a cyberpunk.",
    poster_path: "https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?q=80&w=500&auto=format&fit=crop",
    backdrop_path: "https://images.unsplash.com/photo-1515621061946-eff1c2a352bd?q=80&w=1200&auto=format&fit=crop",
    media_type: "tv",
    first_air_date: "2022-09-13",
    vote_average: 8.6,
    status: "Ended",
    number_of_episodes: 10,
    number_of_seasons: 1,
    tagline: "Get chrome or die trying.",
    genres: [
      { id: 16, name: "Animation" },
      { id: 10765, name: "Sci-Fi & Fantasy" },
      { id: 10759, name: "Action & Adventure" }
    ],
    credits: {
      cast: [
        { id: 11, name: "Zach Aguilar", character: "David Martinez (English)", profile_path: null },
        { id: 12, name: "Emi Lo", character: "Lucy (English)", profile_path: null },
        { id: 13, name: "William C. Stephens", character: "Maine", profile_path: null },
        { id: 14, name: "Giancarlo Esposito", character: "Faraday", profile_path: null }
      ]
    }
  },
  335984: {
    id: 335984,
    title: "Blade Runner 2049",
    overview: "Thirty years after the events of the first film, a new blade runner, LAPD Officer K, unearths a long-buried secret that has the potential to plunge what's left of society into chaos. K's discovery leads him on a quest to find Rick Deckard, a former LAPD blade runner who has been missing for 30 years.",
    poster_path: "https://images.unsplash.com/photo-1508739773434-c26b3d09e071?q=80&w=500&auto=format&fit=crop",
    backdrop_path: "https://images.unsplash.com/photo-1509198397868-475647b2a1e5?q=80&w=1200&auto=format&fit=crop",
    media_type: "movie",
    release_date: "2017-10-04",
    vote_average: 8.5,
    status: "Released",
    runtime: 164,
    tagline: "The key to the future is finally unearthed.",
    genres: [
      { id: 878, name: "Science Fiction" },
      { id: 18, name: "Drama" },
      { id: 53, name: "Thriller" }
    ],
    credits: {
      cast: [
        { id: 21, name: "Ryan Gosling", character: "K", profile_path: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?q=80&w=150&auto=format&fit=crop" },
        { id: 22, name: "Harrison Ford", character: "Rick Deckard", profile_path: null },
        { id: 23, name: "Ana de Armas", character: "Joi", profile_path: null },
        { id: 24, name: "Sylvia Hoeks", character: "Luv", profile_path: null }
      ]
    }
  },
  94605: {
    id: 94605,
    name: "Arcane",
    overview: "Amid the stark discord of twin cities Piltover and Zaun, two sisters fight on rival sides of war between magic technologies and clashing convictions.",
    poster_path: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=500&auto=format&fit=crop",
    backdrop_path: "https://images.unsplash.com/photo-1563089145-599997674d42?q=80&w=1200&auto=format&fit=crop",
    media_type: "tv",
    first_air_date: "2021-11-06",
    vote_average: 8.7,
    status: "Returning Series",
    number_of_episodes: 18,
    number_of_seasons: 2,
    tagline: "Every legend has a beginning.",
    genres: [
      { id: 16, name: "Animation" },
      { id: 10765, name: "Sci-Fi & Fantasy" },
      { id: 10759, name: "Action & Adventure" },
      { id: 18, name: "Drama" }
    ],
    credits: {
      cast: [
        { id: 31, name: "Hailee Steinfeld", character: "Vi", profile_path: null },
        { id: 32, name: "Ella Purnell", character: "Jinx", profile_path: null },
        { id: 33, name: "Kevin Alejandro", character: "Jayce", profile_path: null },
        { id: 34, name: "Harry Lloyd", character: "Viktor", profile_path: null }
      ]
    }
  },
  157336: {
    id: 157336,
    title: "Interstellar",
    overview: "The adventures of a group of explorers who make use of a newly discovered wormhole to surpass the limitations on human space travel and conquer the vast distances involved in an interstellar voyage.",
    poster_path: "https://images.unsplash.com/photo-1462331940025-496dfbfc7564?q=80&w=500&auto=format&fit=crop",
    backdrop_path: "https://images.unsplash.com/photo-1451187580459-43490279c0fa?q=80&w=1200&auto=format&fit=crop",
    media_type: "movie",
    release_date: "2014-11-05",
    vote_average: 8.4,
    status: "Released",
    runtime: 169,
    tagline: "Mankind was born on Earth. It was never meant to die here.",
    genres: [
      { id: 878, name: "Science Fiction" },
      { id: 12, name: "Adventure" },
      { id: 18, name: "Drama" }
    ],
    credits: {
      cast: [
        { id: 41, name: "Matthew McConaughey", character: "Cooper", profile_path: null },
        { id: 42, name: "Anne Hathaway", character: "Brand", profile_path: null },
        { id: 43, name: "Jessica Chastain", character: "Murph", profile_path: null },
        { id: 44, name: "Michael Caine", character: "Professor Brand", profile_path: null }
      ]
    }
  },
  603: {
    id: 603,
    title: "The Matrix",
    overview: "Set in the 22nd century, The Matrix tells the story of a computer hacker who joins a group of underground insurgents fighting the vast and powerful computers who now rule the earth.",
    poster_path: "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?q=80&w=500&auto=format&fit=crop",
    backdrop_path: "https://images.unsplash.com/photo-1510511459019-5dda7724fd87?q=80&w=1200&auto=format&fit=crop",
    media_type: "movie",
    release_date: "1999-03-30",
    vote_average: 8.2,
    status: "Released",
    runtime: 136,
    tagline: "Welcome to the Real World.",
    genres: [
      { id: 878, name: "Science Fiction" },
      { id: 28, name: "Action" }
    ],
    credits: {
      cast: [
        { id: 51, name: "Keanu Reeves", character: "Neo / Thomas A. Anderson", profile_path: null },
        { id: 52, name: "Laurence Fishburne", character: "Morpheus", profile_path: null },
        { id: 53, name: "Carrie-Anne Moss", character: "Trinity", profile_path: null },
        { id: 54, name: "Hugo Weaving", character: "Agent Smith", profile_path: null }
      ]
    }
  },
  86831: {
    id: 86831,
    name: "Love, Death & Robots",
    overview: "Terrifying creatures, wicked surprises and dark comedy converge in this NSFW anthology of animated stories presented by Tim Miller and David Fincher.",
    poster_path: "https://images.unsplash.com/photo-1534447677768-be436bb09401?q=80&w=500&auto=format&fit=crop",
    backdrop_path: "https://images.unsplash.com/photo-1579783902614-a3fb3927b6a5?q=80&w=1200&auto=format&fit=crop",
    media_type: "tv",
    first_air_date: "2019-03-15",
    vote_average: 8.2,
    status: "Returning Series",
    number_of_episodes: 35,
    number_of_seasons: 3,
    tagline: "Not for the faint of circuit.",
    genres: [
      { id: 16, name: "Animation" },
      { id: 10765, name: "Sci-Fi & Fantasy" },
      { id: 10759, name: "Action & Adventure" }
    ],
    credits: {
      cast: [
        { id: 61, name: "Scott Whyte", character: "Various (voice)", profile_path: null },
        { id: 62, name: "Nolan North", character: "Various (voice)", profile_path: null }
      ]
    }
  },
  20526: {
    id: 20526,
    title: "Tron: Legacy",
    overview: "Sam Flynn, the tech-savvy 27-year-old son of Kevin Flynn, looks into his father's disappearance and finds himself pulled into the same world of fierce programs and gladiatorial games where his father has been living for 20 years. Along with Kevin's loyal confidant, father and son embark on a life-and-death journey across a visually stunning cyber universe.",
    poster_path: "https://images.unsplash.com/photo-1481137344492-d5a06567210a?q=80&w=500&auto=format&fit=crop",
    backdrop_path: "https://images.unsplash.com/photo-1478760329108-5c3ed9d495a0?q=80&w=1200&auto=format&fit=crop",
    media_type: "movie",
    release_date: "2010-12-10",
    vote_average: 7.0,
    status: "Released",
    runtime: 125,
    tagline: "The Game Has Changed.",
    genres: [
      { id: 878, name: "Science Fiction" },
      { id: 28, name: "Action" },
      { id: 12, name: "Adventure" }
    ],
    credits: {
      cast: [
        { id: 71, name: "Garrett Hedlund", character: "Sam Flynn", profile_path: null },
        { id: 72, name: "Jeff Bridges", character: "Kevin Flynn / Clu", profile_path: null },
        { id: 73, name: "Olivia Wilde", character: "Quorra", profile_path: null },
        { id: 74, name: "Michael Sheen", character: "Castor / Zuse", profile_path: null }
      ]
    }
  },
  66732: {
    id: 66732,
    name: "Stranger Things",
    overview: "When a young boy vanishes, a small town uncovers a mystery involving secret experiments, terrifying supernatural forces and one strange little girl.",
    poster_path: "https://images.unsplash.com/photo-1509198397868-475647b2a1e5?q=80&w=500&auto=format&fit=crop",
    backdrop_path: "https://images.unsplash.com/photo-1509114397022-ed747cca3f65?q=80&w=1200&auto=format&fit=crop",
    media_type: "tv",
    first_air_date: "2016-07-15",
    vote_average: 8.6,
    status: "Returning Series",
    number_of_episodes: 34,
    number_of_seasons: 4,
    tagline: "One friend can change everything.",
    genres: [
      { id: 10765, name: "Sci-Fi & Fantasy" },
      { id: 18, name: "Drama" }
    ],
    credits: {
      cast: [
        { id: 81, name: "Millie Bobby Brown", character: "Eleven", profile_path: null },
        { id: 82, name: "Finn Wolfhard", character: "Mike Wheeler", profile_path: null },
        { id: 83, name: "Winona Ryder", character: "Joyce Byers", profile_path: null },
        { id: 84, name: "David Harbour", character: "Jim Hopper", profile_path: null }
      ]
    }
  },
  100088: {
    id: 100088,
    name: "The Last of Us",
    overview: "Twenty years after modern civilization has been destroyed, Joel, a hardened survivor, is hired to smuggle Ellie, a 14-year-old girl, out of an oppressive quarantine zone. What starts as a small job soon becomes a brutal, heartbreaking journey, as they both must traverse the U.S. and depend on each other for survival.",
    poster_path: "https://images.unsplash.com/photo-1518818419601-72c8673f5852?q=80&w=500&auto=format&fit=crop",
    backdrop_path: "https://images.unsplash.com/photo-1448375240586-882707db888b?q=80&w=1200&auto=format&fit=crop",
    media_type: "tv",
    first_air_date: "2023-01-15",
    vote_average: 8.7,
    status: "Returning Series",
    number_of_episodes: 9,
    number_of_seasons: 1,
    tagline: "When you're lost in the darkness, look for the light.",
    genres: [
      { id: 18, name: "Drama" },
      { id: 10759, name: "Action & Adventure" }
    ],
    credits: {
      cast: [
        { id: 91, name: "Pedro Pascal", character: "Joel Miller", profile_path: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?q=80&w=150&auto=format&fit=crop" },
        { id: 92, name: "Bella Ramsey", character: "Ellie", profile_path: null },
        { id: 93, name: "Gabriel Luna", character: "Tommy Miller", profile_path: null }
      ]
    }
  }
};
