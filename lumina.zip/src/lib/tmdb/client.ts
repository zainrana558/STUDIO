import { MediaDetails, MediaItem } from "../../types";
import { MOCK_MEDIA_ITEMS, MOCK_MEDIA_DETAILS } from "./mockData";

const PROXY_URL = '/api/tmdb';

/**
 * Perform a safe network request. Bypasses proxy and hits TMDB directly
 * if the user configured a custom API key in browser local storage.
 */
async function fetchFromProxy<T>(path: string, params: Record<string, string> = {}): Promise<T> {
  const customKey = localStorage.getItem("lumina_custom_tmdb_key");
  
  if (customKey && customKey.trim() !== "") {
    const query = new URLSearchParams();
    for (const [key, value] of Object.entries(params)) {
      if (value !== undefined) {
        query.set(key, String(value));
      }
    }
    query.set("api_key", customKey.trim());
    
    // Direct endpoint fetch
    const url = `https://api.themoviedb.org/3/${path}?${query.toString()}`;
    const res = await fetch(url);
    if (!res.ok) {
      throw new Error(`TMDb official API returned status ${res.status}`);
    }
    return res.json() as Promise<T>;
  }

  // Fallback default routing to server proxy
  const query = new URLSearchParams(params).toString();
  const url = `${PROXY_URL}/${path}${query ? `?${query}` : ''}`;
  const res = await fetch(url);
  if (!res.ok) {
    throw new Error(`Proxy returned status ${res.status}`);
  }
  return res.json() as Promise<T>;
}

export const tmdbClient = {
  /**
   * Get trending items
   */
  getTrending: async (
    type: 'all' | 'movie' | 'tv' = 'all',
    period: 'day' | 'week' = 'week'
  ): Promise<MediaItem[]> => {
    try {
      const data = await fetchFromProxy<{ results: MediaItem[] }>(`trending/${type}/${period}`);
      if (data && data.results && data.results.length > 0) {
        return data.results.map(item => ({
          ...item,
          media_type: item.media_type || (type !== 'all' ? type : 'movie')
        }));
      }
      throw new Error("Empty results from TMDB API");
    } catch (e) {
      console.warn("TMDB API Key missing/invalid, using mock database backup for Trending.", e);
      // Fallback
      if (type === 'all') {
        return MOCK_MEDIA_ITEMS;
      }
      return MOCK_MEDIA_ITEMS.filter(item => item.media_type === type);
    }
  },

  /**
   * Get popular items
   */
  getPopular: async (type: 'movie' | 'tv'): Promise<MediaItem[]> => {
    try {
      const data = await fetchFromProxy<{ results: MediaItem[] }>(`${type}/popular`);
      if (data && data.results && data.results.length > 0) {
        return data.results.map(item => ({ ...item, media_type: type }));
      }
      throw new Error("Empty results from TMDB API");
    } catch (e) {
      console.warn(`TMDB API error on ${type}/popular, pulling beautiful mock fallback.`, e);
      return MOCK_MEDIA_ITEMS.filter(item => item.media_type === type);
    }
  },

  /**
   * Get top rated items
   */
  getTopRated: async (type: 'movie' | 'tv'): Promise<MediaItem[]> => {
    try {
      const data = await fetchFromProxy<{ results: MediaItem[] }>(`${type}/top_rated`);
      if (data && data.results && data.results.length > 0) {
        return data.results.map(item => ({ ...item, media_type: type }));
      }
      throw new Error("Empty results from TMDB API");
    } catch (e) {
      console.warn(`TMDB API error on ${type}/top_rated, pulling beautiful mock fallback.`, e);
      const items = MOCK_MEDIA_ITEMS.filter(item => item.media_type === type);
      return [...items].sort((a, b) => b.vote_average - a.vote_average);
    }
  },

  /**
   * Get now playing movies
   */
  getNowPlaying: async (): Promise<MediaItem[]> => {
    try {
      const data = await fetchFromProxy<{ results: MediaItem[] }>("movie/now_playing");
      if (data && data.results && data.results.length > 0) {
        return data.results.map(item => ({ ...item, media_type: 'movie' }));
      }
      throw new Error("Empty results from TMDB API");
    } catch (e) {
      console.warn("TMDB API now_playing failed, pulling movie fallback.", e);
      return MOCK_MEDIA_ITEMS.filter(item => item.media_type === 'movie');
    }
  },

  /**
   * Get on the air TV shows
   */
  getOnTheAir: async (): Promise<MediaItem[]> => {
    try {
      const data = await fetchFromProxy<{ results: MediaItem[] }>("tv/on_the_air");
      if (data && data.results && data.results.length > 0) {
        return data.results.map(item => ({ ...item, media_type: 'tv' }));
      }
      throw new Error("Empty results from TMDB API");
    } catch (e) {
      console.warn("TMDB API on_the_air failed, pulling tv fallback.", e);
      return MOCK_MEDIA_ITEMS.filter(item => item.media_type === 'tv');
    }
  },

  /**
   * Get detailed item metadata by ID
   */
  getDetails: async (type: 'movie' | 'tv', id: number): Promise<MediaDetails> => {
    try {
      const data = await fetchFromProxy<MediaDetails>(`${type}/${id}`, {
        append_to_response: "credits,videos"
      });
      if (data && data.id) {
        return {
          ...data,
          media_type: type
        };
      }
      throw new Error(`Could not find details for ${type} id ${id}`);
    } catch (e) {
      console.warn(`TMDB API fetch details failed for ${type} ID: ${id}. Resorting to curated details.`, e);
      // Fallback
      const key = Number(id);
      if (MOCK_MEDIA_DETAILS[key]) {
        return MOCK_MEDIA_DETAILS[key];
      }
      // Synthetic fallback details if of a custom searched/dynamic element
      const brief = MOCK_MEDIA_ITEMS.find(item => item.id === key) || MOCK_MEDIA_ITEMS[0];
      return {
        ...brief,
        media_type: type,
        genres: brief.genres || [
          { id: 878, name: "Science Fiction" },
          { id: 28, name: "Action" }
        ],
        status: "Released",
        runtime: type === 'movie' ? 142 : undefined,
        number_of_episodes: type === 'tv' ? 10 : undefined,
        number_of_seasons: type === 'tv' ? 1 : undefined,
        tagline: "Experience high-fidelity modern production.",
        credits: {
          cast: [
            { id: 101, name: "Keanu Reeves", character: "Lead Pilot", profile_path: null },
            { id: 102, name: "Zendaya", character: "Communications Specialist", profile_path: null }
          ]
        }
      };
    }
  },

  /**
   * Search across movies and TV shows
   */
  searchMedia: async (query: string): Promise<MediaItem[]> => {
    if (!query.trim()) return [];
    try {
      const data = await fetchFromProxy<{ results: MediaItem[] }>("search/multi", { query });
      if (data && data.results) {
        return data.results
          .filter(item => item.media_type === 'movie' || item.media_type === 'tv')
          .map(item => ({
            ...item,
            media_type: item.media_type as 'movie' | 'tv'
          }));
      }
      return [];
    } catch (e) {
      console.warn(`Search TMDB API failed for query: ${query}. Searching locally in high-fidelity mock.`, e);
      const lowQuery = query.toLowerCase();
      return MOCK_MEDIA_ITEMS.filter(item => {
        const title = (item.title || item.name || "").toLowerCase();
        const overview = (item.overview || "").toLowerCase();
        return title.includes(lowQuery) || overview.includes(lowQuery);
      });
    }
  }
};
export default tmdbClient;
