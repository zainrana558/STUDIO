export interface Genre {
  id: number;
  name: string;
}

export interface CastMember {
  id: number;
  name: string;
  character: string;
  profile_path: string | null;
}

export interface MediaItem {
  id: number;
  title?: string;
  name?: string;
  original_title?: string;
  original_name?: string;
  overview: string;
  poster_path: string;
  backdrop_path: string;
  media_type: 'movie' | 'tv';
  release_date?: string;
  first_air_date?: string;
  vote_average: number;
  vote_count?: number;
  genre_ids?: number[];
  genres?: Genre[];
}

export interface MediaDetails extends MediaItem {
  tagline?: string;
  runtime?: number;
  number_of_episodes?: number;
  number_of_seasons?: number;
  genres: Genre[];
  credits?: {
    cast: CastMember[];
  };
  status?: string;
}

export interface WatchlistItem {
  id: number;
  media_type: 'movie' | 'tv';
  title: string;
  poster_path: string;
  backdrop_path: string;
  vote_average: number;
  release_date?: string;
  addedAt: string;
}

export interface WatchHistory {
  id: number;
  media_type: 'movie' | 'tv';
  title: string;
  poster_path: string;
  backdrop_path: string;
  progress: number; // percentage (0 - 100)
  currentTime: number; // seconds
  duration: number; // seconds
  watchedAt: string;
}
