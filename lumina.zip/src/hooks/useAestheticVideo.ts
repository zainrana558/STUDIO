import { useEffect, useState, useMemo } from "react";
import { ThemeMode, useAestheticTheme } from "../context/ThemeContext";

export interface GenreVideoAsset {
  id: ThemeMode;
  genreName: string;
  videoUrl: string;
  placeholderUrl: string; // High-quality unsplash fallback
  blendColor: string;
  intensity: number; // custom mapping opacity modifier
}

// Optimized mappings of Aesthetic Themes / Genres to looping videos and high-definition fallback canvases
export const AESTHETIC_VIDEO_MAP: Record<ThemeMode, GenreVideoAsset> = {
  classic: {
    id: "classic",
    genreName: "Classic Cinema",
    videoUrl: "https://assets.mixkit.co/videos/preview/mixkit-dust-particles-hovering-in-the-air-40030-large.mp4",
    placeholderUrl: "https://images.unsplash.com/photo-1536440136628-849c177e76a1?q=80&w=1200",
    blendColor: "rgba(20, 22, 27, 0.85)",
    intensity: 0.07,
  },
  anime: {
    id: "anime",
    genreName: "Otaku Mode",
    videoUrl: "https://assets.mixkit.co/videos/preview/mixkit-tunnel-of-futuristic-glowing-blue-and-red-lights-41008-large.mp4",
    placeholderUrl: "https://images.unsplash.com/photo-1578632767115-351597cf2477?q=80&w=1200",
    blendColor: "rgba(13, 17, 23, 0.88)",
    intensity: 0.12,
  },
  playful: {
    id: "playful",
    genreName: "Playful Mode",
    videoUrl: "https://assets.mixkit.co/videos/preview/mixkit-pastel-colored-balls-swirling-in-a-fun-pattern-40154-large.mp4",
    placeholderUrl: "https://images.unsplash.com/photo-1518156677180-95a2893f3e9f?q=80&w=1200",
    blendColor: "rgba(14, 11, 22, 0.84)",
    intensity: 0.08,
  },
  abyss: {
    id: "abyss",
    genreName: "The Abyss",
    videoUrl: "https://assets.mixkit.co/videos/preview/mixkit-dense-smoke-drifts-on-a-black-background-40026-large.mp4",
    placeholderUrl: "https://images.unsplash.com/photo-1509248961158-e54f6934749c?q=80&w=1200",
    blendColor: "rgba(5, 5, 5, 0.95)",
    intensity: 0.15,
  },
  cosmic: {
    id: "cosmic",
    genreName: "Cosmic Mode",
    videoUrl: "https://assets.mixkit.co/videos/preview/mixkit-flying-through-a-futuristic-tunnel-with-purple-lights-41604-large.mp4",
    placeholderUrl: "https://images.unsplash.com/photo-1506318137071-a8e063b4bec0?q=80&w=1200",
    blendColor: "rgba(2, 2, 16, 0.86)",
    intensity: 0.10,
  },
};

export const useAestheticVideo = () => {
  const { activeTheme } = useAestheticTheme();
  const [preloadedUrls, setPreloadedUrls] = useState<Set<string>>(new Set());
  const [prefersReducedMotion, setPrefersReducedMotion] = useState(false);

  // 1. Accessibility Checks: Listen for systems requesting reduced animations/motion
  useEffect(() => {
    if (typeof window === "undefined") return;
    const mediaQuery = window.matchMedia("(prefers-reduced-motion: reduce)");
    setPrefersReducedMotion(mediaQuery.matches);

    const listener = (e: MediaQueryListEvent) => {
      setPrefersReducedMotion(e.matches);
    };

    mediaQuery.addEventListener("change", listener);
    return () => mediaQuery.removeEventListener("change", listener);
  }, []);

  // 2. High-Performance Pre-fetching/pre-loading pipeline
  useEffect(() => {
    if (typeof window === "undefined" || prefersReducedMotion) return;

    // Trigger silent browser pre-loading for the video assets
    const activeAsset = AESTHETIC_VIDEO_MAP[activeTheme];
    if (activeAsset && !preloadedUrls.has(activeAsset.videoUrl)) {
      const link = document.createElement("link");
      link.rel = "preload";
      link.as = "video";
      link.href = activeAsset.videoUrl;
      link.onload = () => {
        setPreloadedUrls((prev) => {
          const updated = new Set(prev);
          updated.add(activeAsset.videoUrl);
          return updated;
        });
      };
      document.head.appendChild(link);
    }

    // Proactively preload the rest of the videos sequentially after a brief timeout delay to maximize idle bandwidth
    const preloadTimer = setTimeout(() => {
      Object.values(AESTHETIC_VIDEO_MAP).forEach((asset) => {
        if (!preloadedUrls.has(asset.videoUrl) && asset.id !== activeTheme) {
          const videoElement = document.createElement("video");
          videoElement.src = asset.videoUrl;
          videoElement.preload = "auto";
          videoElement.muted = true;
          setPreloadedUrls((prev) => {
            const updated = new Set(prev);
            updated.add(asset.videoUrl);
            return updated;
          });
        }
      });
    }, 3000);

    return () => clearTimeout(preloadTimer);
  }, [activeTheme, preloadedUrls, prefersReducedMotion]);

  // Memorize asset lookup to guard against re-rendering layout calculations
  const activeAsset = useMemo(() => {
    return AESTHETIC_VIDEO_MAP[activeTheme] || AESTHETIC_VIDEO_MAP.classic;
  }, [activeTheme]);

  return {
    activeAsset,
    prefersReducedMotion,
    isPreloaded: preloadedUrls.has(activeAsset.videoUrl),
  };
};
