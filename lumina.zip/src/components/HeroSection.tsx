import React, { useState, useEffect } from "react";
import { Play, Plus, Check, Star, Info, ChevronLeft, ChevronRight } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { MediaItem } from "../types";
import { useWatchlist } from "../context/WatchlistContext";
import { useAppStore } from "../lib/store";
import { getImageUrl, cn } from "../lib/utils";

interface HeroSectionProps {
  items: MediaItem[];
}

export const HeroSection: React.FC<HeroSectionProps> = ({ items }) => {
  const { addToWatchlist, removeFromWatchlist, isInWatchlist } = useWatchlist();
  const { selectMedia } = useAppStore();
  const [activeIndex, setActiveIndex] = useState(0);

  const carouselItems = items && items.length > 0 ? items.slice(0, 5) : [];

  // Auto-rotate effect (8 seconds intervals)
  useEffect(() => {
    if (carouselItems.length <= 1) return;
    const interval = setInterval(() => {
      setActiveIndex((prev) => (prev + 1) % carouselItems.length);
    }, 8000);
    return () => clearInterval(interval);
  }, [carouselItems.length]);

  if (carouselItems.length === 0) return null;

  const currentItem = carouselItems[activeIndex];
  const itemTitle = currentItem.title || currentItem.name || currentItem.original_title || "Lumina Featured";
  const inWatchlist = isInWatchlist(currentItem.id);
  const releaseYear = currentItem.release_date 
    ? currentItem.release_date.split("-")[0] 
    : currentItem.first_air_date 
      ? currentItem.first_air_date.split("-")[0] 
      : "2024";

  const handleWatchlistToggle = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (inWatchlist) {
      removeFromWatchlist(currentItem.id);
    } else {
      addToWatchlist(currentItem);
    }
  };

  const nextSlide = () => {
    setActiveIndex((prev) => (prev + 1) % carouselItems.length);
  };

  const prevSlide = () => {
    setActiveIndex((prev) => (prev - 1 + carouselItems.length) % carouselItems.length);
  };

  return (
    <section 
      id="hero-carousel"
      className="relative w-full h-[70vh] md:h-[80vh] min-h-[480px] max-h-[850px] overflow-hidden rounded-2xl md:rounded-3xl border border-white/5 bg-black select-none"
    >
      {/* Background Backdrops with Animation */}
      <AnimatePresence mode="wait">
        <motion.div
          key={currentItem.id}
          initial={{ opacity: 0, scale: 1.05 }}
          animate={{ opacity: 0.75, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          transition={{ duration: 0.8 }}
          className="absolute inset-0 w-full h-full bg-cover bg-center"
          style={{ backgroundImage: `url(${getImageUrl(currentItem.backdrop_path, 'original', 'backdrop')})` }}
        />
      </AnimatePresence>
 
      {/* Extreme Vignette Gradient Shield Overlay */}
      <div className="absolute inset-0 bg-gradient-to-t from-[#0B0E11] via-[#0B0E11]/40 to-transparent z-10" />
      <div className="absolute inset-0 bg-gradient-to-r from-[#0B0E11] via-[#0B0E11]/20 to-transparent z-10" />
 
      {/* Cyber Grid Overlay for Styling */}
      <div className="absolute inset-0 bg-[radial-gradient(rgba(255,255,255,0.015)_1px,transparent_1px)] [background-size:16px_16px] pointer-events-none z-10" />
 
      {/* Side Slider controls */}
      <div className="absolute inset-y-0 left-2 right-2 flex justify-between items-center z-30 pointer-events-none">
        <button 
          onClick={prevSlide}
          className="pointer-events-auto p-2 rounded-full border border-white/5 bg-gray-950/60 hover:bg-[#ff073a]/20 hover:border-[#ff073a]/30 text-white hover:text-[#ff073a] transition-all cursor-pointer backdrop-blur-sm"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>
        <button 
          onClick={nextSlide}
          className="pointer-events-auto p-2 rounded-full border border-white/5 bg-gray-950/60 hover:bg-[#ff073a]/20 hover:border-[#ff073a]/30 text-white hover:text-[#ff073a] transition-all cursor-pointer backdrop-blur-sm"
        >
          <ChevronRight className="w-5 h-5" />
        </button>
      </div>
 
      {/* Carousel Content */}
      <div className="absolute inset-0 z-20 flex flex-col justify-end p-6 md:p-12 lg:p-16 w-full max-w-4xl">
        <motion.div
          key={`content-${currentItem.id}`}
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2, duration: 0.5 }}
          className="flex flex-col gap-3 md:gap-4 text-left font-sans"
        >
          {/* Badge */}
          <div className="flex flex-wrap items-center gap-2">
            <span className="px-2 py-0.5 bg-[#ff073a] text-white text-[10px] font-bold rounded tracking-wider uppercase shadow-[0_0_10px_rgba(255,7,58,0.4)]">
              {currentItem.media_type === "tv" ? "TV Spotlight" : "Featured"}
            </span>
            <span className="text-xs text-white/60">
              {releaseYear} • Rating {currentItem.vote_average.toFixed(1)}
            </span>
          </div>
 
          {/* Heading with theme-accurate white-to-faded gradient */}
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-black mb-1 lg:mb-2 tracking-tighter bg-clip-text text-transparent bg-gradient-to-r from-white to-white/60 leading-none uppercase drop-shadow-md">
            {itemTitle}
          </h1>
 
          {/* Tagline / Overview description */}
          <p className="max-w-xl text-white/70 text-sm md:text-base mb-2 md:mb-4 line-clamp-2 md:line-clamp-3 leading-relaxed drop-shadow-lg font-sans">
            {currentItem.overview || "Deep diving into premium telemetry cinematic experiences. Connect Lumina configurations and enjoy unlimited stream selections."}
          </p>
 
          {/* Action buttons */}
          <div className="flex flex-wrap gap-3 mt-1">
            {/* Play trigger */}
            <button
              onClick={() => selectMedia(currentItem)}
              className="px-8 py-3 bg-[#ff073a] rounded-lg font-bold flex items-center gap-2 shadow-[0_0_20px_rgba(255,7,58,0.3)] hover:scale-105 active:scale-95 transition-all text-xs font-mono uppercase tracking-wider text-white cursor-pointer"
            >
              <Play className="w-4 h-4 fill-white" />
              Watch Now
            </button>
 
            {/* Bookmark button */}
            <button
              onClick={handleWatchlistToggle}
              className={cn(
                "px-8 py-3 rounded-lg font-bold flex items-center gap-2 active:scale-95 transition-all text-xs font-mono uppercase tracking-wider cursor-pointer border backdrop-blur-md",
                inWatchlist
                  ? "bg-emerald-500/15 border-emerald-500/40 text-emerald-400 hover:bg-emerald-500/25"
                  : "bg-white/10 hover:bg-white/20 border-white/10 text-white"
              )}
            >
              {inWatchlist ? (
                <>
                  <Check className="w-4 h-4 text-emerald-400" />
                  In Watchlist
                </>
              ) : (
                <>
                  <Plus className="w-4 h-4" />
                  Add to Watchlist
                </>
              )}
            </button>
          </div>
        </motion.div>
      </div>
 
      {/* Navigation visual indicator dots */}
      <div className="absolute bottom-10 right-10 z-20 flex space-x-2">
        {carouselItems.map((_, index) => (
          <button
            key={index}
            onClick={() => setActiveIndex(index)}
            className={cn(
              "h-1 rounded-full transition-all duration-300 cursor-pointer",
              index === activeIndex 
                ? "w-12 bg-[#ff073a] shadow-[0_0_10px_rgba(255,7,58,0.4)]" 
                : "w-3 bg-white/20 hover:bg-white/40"
            )}
            aria-label={`Go to slide ${index + 1}`}
          />
        ))}
      </div>
    </section>
  );
};
export default HeroSection;
