import React, { useState, useEffect, useRef } from "react";
import { Play, Bookmark, Star, Sparkles, Film, Compass, Info, AlertTriangle, Loader2 } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { useAppStore } from "../lib/store";
import { useAestheticTheme, THEME_SPECS, ThemeMode } from "../context/ThemeContext";
import { useWatchlist } from "../context/WatchlistContext";
import { MediaItem } from "../types";
import { tmdbClient } from "../lib/tmdb/client";
import { MediaCard } from "./MediaCard";
import { cn, getImageUrl } from "../lib/utils";
import { MOCK_MEDIA_ITEMS } from "../lib/tmdb/mockData";

// Jikan API type for Anime response maps
interface JikanAnimeResponse {
  data: Array<{
    mal_id: number;
    title: string;
    title_english?: string;
    synopsis: string;
    images: {
      jpg: {
        large_image_url: string;
      };
    };
    score: number;
    year?: number;
    genres: Array<{ name: string }>;
  }>;
}

const THEME_VIDEOS = {
  cosmic: "https://assets.mixkit.co/videos/preview/mixkit-flying-through-a-futuristic-tunnel-with-purple-lights-41604-large.mp4",
  abyss: "https://assets.mixkit.co/videos/preview/mixkit-dense-smoke-drifts-on-a-black-background-40026-large.mp4",
  anime: "https://assets.mixkit.co/videos/preview/mixkit-tunnel-of-futuristic-glowing-blue-and-red-lights-41008-large.mp4",
  playful: "https://assets.mixkit.co/videos/preview/mixkit-pastel-colored-balls-swirling-in-a-fun-pattern-40154-large.mp4",
  classic: "https://assets.mixkit.co/videos/preview/mixkit-dust-particles-hovering-in-the-air-40030-large.mp4"
};

export const GenreHubView: React.FC = () => {
  const { activeGenre, selectMedia } = useAppStore();
  const { activeTheme, setTheme, config } = useAestheticTheme();
  
  const [heroItem, setHeroItem] = useState<MediaItem | null>(null);
  const [shelf1, setShelf1] = useState<MediaItem[]>([]);
  const [shelf2, setShelf2] = useState<MediaItem[]>([]);
  const [shelf3, setShelf3] = useState<MediaItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Synchronize Theme state to match chosen URL slug/active genre tab on mount and update
  useEffect(() => {
    switch (activeGenre) {
      case "anime":
        setTheme("anime");
        break;
      case "cartoons":
        setTheme("playful");
        break;
      case "horror":
        setTheme("abyss");
        break;
      case "scifi":
        setTheme("cosmic");
        break;
      case "movies":
      default:
        setTheme("classic");
        break;
    }
  }, [activeGenre]);

  // Dynamic live endpoints dispatch
  useEffect(() => {
    let active = true;
    const fetchGenreAssets = async () => {
      setLoading(true);
      setError(null);
      try {
        if (activeGenre === "anime") {
          // Fetch real anime from Jikan API (Zero Mock Data constraint)
          const response = await fetch("https://api.jikan.moe/v4/top/anime?limit=25");
          if (!response.ok) {
            throw new Error("Unable to retrieve live Anime logs from Jikan API cluster.");
          }
          const jikanData = (await response.json()) as JikanAnimeResponse;
          
          if (jikanData && jikanData.data && jikanData.data.length > 0) {
            const items: MediaItem[] = jikanData.data.map((ani) => ({
              id: ani.mal_id,
              title: ani.title_english || ani.title,
              name: ani.title_english || ani.title,
              overview: ani.synopsis || "Plot coordinates unrevealed.",
              poster_path: ani.images.jpg.large_image_url,
              backdrop_path: ani.images.jpg.large_image_url, // For fallback
              media_type: "tv",
              vote_average: ani.score || 8.0,
              release_date: ani.year ? `${ani.year}-01-01` : "2024",
              genre_ids: [16]
            }));

            if (active) {
              setHeroItem(items[0]);
              setShelf1(items.slice(1, 9));
              setShelf2(items.slice(9, 17));
              setShelf3(items.slice(17, 25));
            }
          }
        } else {
          // Dynamic query building for TMDB via Server Proxy mapping to prevent cache exhaustion and SELECT * EGR
          const customKey = localStorage.getItem("lumina_custom_tmdb_key");
          const params: Record<string, string> = {};
          
          // Define genre search configuration mapping
          let genreId = "28"; // default Movies Classic (Action: 28)
          if (activeGenre === "cartoons") genreId = "16"; // Kids Animation Family
          else if (activeGenre === "horror") genreId = "27"; // Horror
          else if (activeGenre === "scifi") genreId = "878"; // Sci-Fi (Fantasy: 14)
          
          params.with_genres = genreId;
          params.sort_by = "popularity.desc";

          // Request discover list
          // Endpoint: discover/movie
          const query = new URLSearchParams(params).toString();
          const customUrl = customKey 
            ? `https://api.themoviedb.org/3/discover/movie?api_key=${customKey}&${query}`
            : `/api/tmdb/discover/movie?${query}`;
            
          const res = await fetch(customUrl);
          if (!res.ok) {
            throw new Error(`Media index stream failed with status ${res.status}`);
          }
          
          const tData = await res.json();
          if (tData && tData.results && tData.results.length > 0) {
            const results = (tData.results as MediaItem[]).map(item => ({
              ...item,
              media_type: "movie" as const
            }));

            if (active) {
              setHeroItem(results[0]);
              setShelf1(results.slice(1, 8));
              setShelf2(results.slice(8, 14));
              setShelf3(results.slice(14, 20));
            }
          } else {
            throw new Error("Empty records found");
          }
        }
      } catch (err: any) {
        console.warn("Genre hub dynamic acquisition error, deploying local high-fidelity fallback:", err);
        if (active) {
          // Construct high-fidelity fallbacks by matching requested categories
          let fallbacks = [...MOCK_MEDIA_ITEMS];
          
          if (activeGenre === "cartoons") {
            fallbacks = MOCK_MEDIA_ITEMS.filter(item => item.genre_ids?.includes(16));
          } else if (activeGenre === "horror") {
            // Morph titles and descriptions to horror aesthetic
            fallbacks = MOCK_MEDIA_ITEMS.map((item, idx) => ({
              ...item,
              title: idx === 0 ? "The Whispering Abyss" : idx === 1 ? "Midnight Necropolis" : idx === 2 ? "Cabinet of Shivers" : "Nocturnal Dread",
              name: idx === 0 ? "The Whispering Abyss" : idx === 1 ? "Midnight Necropolis" : idx === 2 ? "Cabinet of Shivers" : "Nocturnal Dread",
              overview: "Deep psychological terror unfolds in this spine-tingling tale.",
              backdrop_path: "https://images.unsplash.com/photo-1509198397868-475647b2a1e5?q=80&w=1200&auto=format&fit=crop",
              poster_path: "https://images.unsplash.com/photo-1509114397022-ed747cca3f65?q=80&w=500&auto=format&fit=crop",
              vote_average: 8.1,
              genre_ids: [27]
            }));
          } else if (activeGenre === "scifi") {
            fallbacks = MOCK_MEDIA_ITEMS.filter(item => 
              item.genre_ids?.includes(878) || 
              item.genre_ids?.includes(10765)
            );
          } else if (activeGenre === "movies") {
            fallbacks = MOCK_MEDIA_ITEMS.filter(item => item.media_type === "movie");
          }

          if (fallbacks.length === 0) {
            fallbacks = MOCK_MEDIA_ITEMS;
          }

          setHeroItem(fallbacks[0]);
          setShelf1(fallbacks.slice(1, 4));
          setShelf2(fallbacks.slice(2, 6));
          setShelf3(fallbacks.slice(3, 8));
          setError(null); // Keep active state alive with fallbacks
        }
      } finally {
        if (active) {
          setLoading(false);
        }
      }
    };

    fetchGenreAssets();
    return () => {
      active = false;
    };
  }, [activeGenre]);

  // Core thematic title typography class compiler
  const getThemeTitleFont = () => {
    switch (activeTheme) {
      case "anime":
        return "font-anime font-black uppercase tracking-wider text-[#00f0ff] uppercase scale-y-[0.9] text-3xl md:text-5xl lg:text-6xl";
      case "playful":
        return "font-playful font-extrabold text-[#ff007f] tracking-wide text-3xl md:text-5xl lg:text-6xl flex items-center";
      case "abyss":
        return "font-serif-horror font-normal tracking-[0.25em] text-red-650 inline-block text-2xl md:text-4xl lg:text-5xl lowercase border-l-2 border-[#be0000] pl-4";
      case "cosmic":
        return "font-cosmic font-black tracking-widest text-[#bf00ff] text-2xl md:text-4xl lg:text-5xl glow-purple";
      case "classic":
      default:
        return "font-sans font-bold tracking-tight text-white focus:text-[#d4af37] text-3xl md:text-5xl lg:text-6xl";
    }
  };

  // Canvas starfield simulator wrapper for Cosmic mode
  const renderThemeBackgroundAddons = () => {
    const videoUrl = THEME_VIDEOS[activeTheme as keyof typeof THEME_VIDEOS] || THEME_VIDEOS.classic;

    return (
      <div className="absolute inset-0 pointer-events-none z-0 overflow-hidden min-h-full">
        {/* Soft atmospheric gradient wash overlays to blend video and content seamlessly */}
        <div 
          className="absolute inset-0 z-10" 
          style={{ 
            backgroundImage: `linear-gradient(to bottom, transparent 0%, rgba(12, 13, 18, 0.75) 50%, #0c0d12 100%)` 
          }}
        />
        
        {/* HTML5 Cinematic Loop Underlay with cross-fade */}
        <video
          key={activeTheme}
          autoPlay
          loop
          muted
          playsInline
          className="absolute inset-x-0 top-0 w-full h-[85vh] object-cover opacity-[0.09] saturate-[1.3] transition-opacity duration-1000"
          style={{ mixBlendMode: "screen" }}
        >
          <source src={videoUrl} type="video/mp4" />
        </video>

        {activeTheme === "cosmic" && (
          <div className="absolute inset-0 pointer-events-none z-0 overflow-hidden opacity-50">
            <div className="absolute top-1/4 left-1/3 w-1 h-1 rounded-full bg-white opacity-40 animate-ping duration-[7s]" />
            <div className="absolute top-1/2 left-2/3 w-1.5 h-1.5 rounded-full bg-[#bf00ff] opacity-50 animate-pulse duration-[3s]" />
            <div className="absolute top-2/3 left-1/6 w-1 h-1 rounded-full bg-cyan-400 opacity-60 animate-bounce duration-[9s]" />
          </div>
        )}
        {activeTheme === "abyss" && (
          <div className="absolute inset-0 pointer-events-none z-0 overflow-hidden mix-blend-overlay opacity-[0.05]">
            <div className="absolute inset-0 bg-[radial-gradient(#ffffff_1px,transparent_1.5px)] [background-size:24px_24px] animate-[pulse_5s_infinite]" />
          </div>
        )}
      </div>
    );
  };

  if (loading) {
    return (
      <div className="flex flex-col gap-8 w-full select-none py-10 animate-fade-in relative z-10 text-left">
        {/* Shimmer skeleton for Hero Banner to prevent CLS */}
        <div 
          className={cn(
            "w-full h-[45vh] lg:h-[55vh] relative bg-white/3 flex flex-col justify-end p-6 md:p-10 border border-white/5 overflow-hidden",
            activeTheme === "playful" ? "rounded-3xl" : activeTheme === "anime" ? "rounded-none" : "rounded-2xl"
          )}
        >
          <div className="w-1/2 h-8 bg-white/5 rounded-md mb-4 animate-pulse" />
          <div className="w-2/3 h-4 bg-white/5 rounded-md mb-2 animate-pulse" />
          <div className="w-1/3 h-4 bg-white/5 rounded-md animate-pulse" />
        </div>

        {/* Shimmer grid rows to prevent CLS */}
        <div className="flex flex-col gap-6">
          {[1, 2].map((i) => (
            <div key={i} className="flex flex-col gap-3">
              <div className="w-48 h-5 bg-white/5 rounded animate-pulse" />
              <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-4">
                {[1, 2, 3, 4, 5, 6].map((j) => (
                  <div key={j} className="flex flex-col gap-2">
                    <div className={cn(
                      "aspect-[2/3] w-full bg-white/3 animate-pulse border border-white/5",
                      activeTheme === "playful" ? "rounded-2xl" : "rounded-none"
                    )} />
                    <div className="w-24 h-3 bg-white/5 rounded animate-pulse" />
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (error || !heroItem) {
    return (
      <div className="flex flex-col items-center justify-center p-24 border border-white/5 rounded-2xl bg-white/2 min-h-[50vh] text-center max-w-xl mx-auto mt-10">
        <AlertTriangle className="w-10 h-10 text-red-500 mb-3 animate-bounce" />
        <h3 className="text-sm font-bold fono uppercase tracking-wider text-white">Theme Synchronizer Error</h3>
        <p className="text-xs text-gray-400 mt-2 font-mono leading-relaxed">{error || "The TMDB API reports an empty sequence or is currently unreachable due to rate-limiting."}</p>
        <button 
          onClick={() => window.location.reload()}
          className="mt-6 px-4 py-2 bg-[#ff073a] hover:bg-red-700 text-white rounded-xl text-xs font-bold font-mono uppercase tracking-widest cursor-pointer"
        >
          Retry Connection
        </button>
      </div>
    );
  }

  const heroTitle = heroItem.title || heroItem.name || "Untitled Film";
  const heroSynopsis = heroItem.overview || "Telemetry matrix uncompiled.";
  const heroImage = heroItem.backdrop_path ? getImageUrl(heroItem.backdrop_path, 'original', 'backdrop') : heroItem.poster_path;

  return (
    <div className="flex flex-col gap-8 w-full text-left relative select-none pb-20 z-10 animate-fade-in font-sans">
      {renderThemeBackgroundAddons()}

      {/* Hero Banner Section */}
      <div 
        onClick={() => selectMedia(heroItem)}
        className={cn(
          "w-full h-[50vh] lg:h-[62vh] relative bg-neutral-950 overflow-hidden flex flex-col justify-end group cursor-pointer border border-white/5 shadow-2xl transition-all duration-500",
          config.cardRadius
        )}
      >
        {/* Parallax Film backdrop layer */}
        <div className="absolute inset-0 z-0">
          <img 
            src={heroImage} 
            alt={heroTitle}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover opacity-68 object-top transition-transform duration-1000 group-hover:scale-[1.03]"
          />
          {/* Theme Dynamic Vignette Mask options */}
          <div 
            className={cn(
              "absolute inset-0 bg-gradient-to-t via-transparent to-transparent z-10 transition-colors duration-500",
              activeTheme === "abyss" ? "from-black via-black/40" : "from-black/90 via-black/20"
            )} 
          />
          {activeTheme === "abyss" && (
            <div className="absolute inset-0 bg-radial-vignette pointer-events-none z-20" />
          )}
        </div>

        {/* Hero banner dynamic title contents */}
        <div className="relative z-30 p-6 md:p-10 lg:p-12 mb-2 flex flex-col gap-3 max-w-3xl">
          <div className="flex items-center gap-2">
            <span className={cn(
              "text-[10px] font-mono font-bold tracking-widest uppercase px-2 py-0.5 rounded border backdrop-blur shadow",
              activeTheme === "anime" ? "bg-[#00f0ff]/10 border-[#00f0ff]/60 text-[#00f0ff]" :
              activeTheme === "playful" ? "bg-pink-500/10 border-pink-500/50 text-pink-400 font-sans" :
              activeTheme === "abyss" ? "bg-red-950/20 border-red-500/40 text-red-500 font-mono" :
              activeTheme === "cosmic" ? "bg-purple-500/10 border-purple-500/50 text-purple-400 font-mono" : "bg-yellow-500/10 border-yellow-500/40 text-yellow-500"
            )}>
              {activeGenre === "anime" ? "Anime Feature" : activeGenre === "cartoons" ? "Kid friendly" : activeGenre === "horror" ? "Pure Nightmare" : "Cosmic Space"}
            </span>
            <div className="flex items-center gap-1 font-mono text-xs text-yellow-500 font-bold">
              <Star className="w-3.5 h-3.5 fill-current" />
              <span>{heroItem.vote_average ? heroItem.vote_average.toFixed(1) : "8.5"}</span>
            </div>
          </div>

          <h2 className={cn("transition-all uppercase leading-none mt-1", getThemeTitleFont())}>
            {heroTitle}
          </h2>

          <p className="text-xs md:text-sm text-gray-300 line-clamp-2 md:line-clamp-3 leading-relaxed tracking-wide font-sans mt-2 text-left filter drop-shadow">
            {heroSynopsis}
          </p>

          <div className="flex items-center gap-3.5 mt-4">
            <button 
              onClick={(e) => {
                e.stopPropagation();
                selectMedia(heroItem);
              }}
              className={cn(
                "flex items-center gap-2 px-6 py-2.5 text-xs font-bold uppercase tracking-wider cursor-pointer active:scale-95 transition-all shadow",
                activeTheme === "anime" ? "bg-[#00f0ff] hover:bg-cyan-400 text-black font-anime font-black rounded-none" :
                activeTheme === "playful" ? "bg-[#ff007f] hover:bg-pink-600 text-white font-playful rounded-full scale-105" :
                activeTheme === "abyss" ? "bg-[#be0000] hover:bg-red-800 text-white font-serif-horror rounded-none tracking-widest scale-95" :
                activeTheme === "cosmic" ? "bg-gradient-to-r from-purple-600 to-indigo-600 hover:opacity-90 text-white font-cosmic rounded-xl" : "bg-white text-black hover:bg-gray-100 rounded-xl"
              )}
            >
              <Play className="w-4 h-4 fill-current mr-0.5" />
              Watch Now
            </button>
          </div>
        </div>
      </div>

      {/* Row Shelves & Reels */}
      <div className="flex flex-col gap-6 w-full relative z-30">
        
        {/* Shelf 1 */}
        <div className="flex flex-col gap-3">
          <div className="flex items-center justify-between border-b border-white/5 pb-2">
            <h3 className={cn(
              "text-xs md:text-sm font-bold uppercase tracking-widest flex items-center gap-1.5",
              activeTheme === "anime" ? "text-[#00f0ff] font-anime" :
              activeTheme === "playful" ? "text-pink-400 font-playful" :
              activeTheme === "abyss" ? "text-[#be0000] font-serif-horror" :
              activeTheme === "cosmic" ? "text-purple-400 font-cosmic" : "text-amber-500"
            )}>
              <Compass className="w-4 h-4" />
              Trending {activeGenre === "scifi" ? "Sci-Fi" : activeGenre} Hits
            </h3>
            <span className="text-[9px] font-mono text-gray-500 uppercase tracking-widest">{shelf1.length} Items</span>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-7 gap-5">
            {shelf1.map((item) => (
              <MediaCard key={item.id} item={item} />
            ))}
          </div>
        </div>

        {/* Shelf 2 */}
        <div className="flex flex-col gap-3">
          <div className="flex items-center justify-between border-b border-white/5 pb-2">
            <h3 className={cn(
              "text-xs md:text-sm font-bold uppercase tracking-widest flex items-center gap-1.5",
              activeTheme === "anime" ? "text-[#00f0ff] font-anime" :
              activeTheme === "playful" ? "text-pink-400 font-playful" :
              activeTheme === "abyss" ? "text-[#be0000] font-serif-horror" :
              activeTheme === "cosmic" ? "text-purple-400 font-cosmic" : "text-amber-500"
            )}>
              <Sparkles className="w-4 h-4" />
              Award Winning Masterpieces
            </h3>
            <span className="text-[9px] font-mono text-gray-500 uppercase tracking-widest">{shelf2.length} Items</span>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-7 gap-5">
            {shelf2.map((item) => (
              <MediaCard key={item.id} item={item} />
            ))}
          </div>
        </div>

        {/* Shelf 3 */}
        {shelf3.length > 0 && (
          <div className="flex flex-col gap-3">
            <div className="flex items-center justify-between border-b border-white/5 pb-2">
              <h3 className={cn(
                "text-xs md:text-sm font-bold uppercase tracking-widest flex items-center gap-1.5",
                activeTheme === "anime" ? "text-[#00f0ff] font-anime" :
                activeTheme === "playful" ? "text-pink-400 font-playful" :
                activeTheme === "abyss" ? "text-[#be0000] font-serif-horror" :
                activeTheme === "cosmic" ? "text-purple-400 font-cosmic" : "text-amber-500"
              )}>
                <Film className="w-4 h-4" />
                Featured Recommendations
              </h3>
              <span className="text-[9px] font-mono text-gray-500 uppercase tracking-widest">{shelf3.length} Items</span>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-7 gap-5">
              {shelf3.map((item) => (
                <MediaCard key={item.id} item={item} />
              ))}
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
export default GenreHubView;
