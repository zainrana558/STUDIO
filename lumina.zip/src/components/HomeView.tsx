import React, { useState, useEffect } from "react";
import { Search, Film, Flame, Sparkles, HelpCircle, Loader2, Gamepad2, Smile, Skull, Atom, Clapperboard } from "lucide-react";
import { MediaItem } from "../types";
import { tmdbClient } from "../lib/tmdb/client";
import { useAppStore } from "../lib/store";
import { useHistory } from "../context/HistoryContext";
import { HeroSection } from "./HeroSection";
import { MediaRow } from "./MediaRow";
import { SkeletonRow } from "./SkeletonLoader";
import { Play } from "lucide-react";

export const HomeView: React.FC = () => {
  const { searchQuery, setSearchQuery, selectMedia, setGenreView } = useAppStore();
  const { history } = useHistory();
  
  const [trending, setTrending] = useState<MediaItem[]>([]);
  const [popularMovies, setPopularMovies] = useState<MediaItem[]>([]);
  const [popularTv, setPopularTv] = useState<MediaItem[]>([]);
  const [topRated, setTopRated] = useState<MediaItem[]>([]);
  const [searchResults, setSearchResults] = useState<MediaItem[]>([]);
  
  const [loading, setLoading] = useState(true);
  const [searchLoading, setSearchLoading] = useState(false);

  // 1. Fetch catalog cards on mount
  useEffect(() => {
    const fetchCatalog = async () => {
      setLoading(true);
      try {
        const [trendData, movieData, tvData, topData] = await Promise.all([
          tmdbClient.getTrending('all', 'week'),
          tmdbClient.getPopular('movie'),
          tmdbClient.getPopular('tv'),
          tmdbClient.getTopRated('movie')
        ]);
        
        setTrending(trendData || []);
        setPopularMovies(movieData || []);
        setPopularTv(tvData || []);
        setTopRated(topData || []);
      } catch (err) {
        console.error("Home view initial fetch failed:", err);
      } finally {
        setLoading(false);
      }
    };

    fetchCatalog();
  }, []);

  // 2. Continuous multi-search resolver
  useEffect(() => {
    if (!searchQuery.trim()) {
      setSearchResults([]);
      return;
    }

    const delayDebounce = setTimeout(async () => {
      setSearchLoading(true);
      try {
        const results = await tmdbClient.searchMedia(searchQuery);
        setSearchResults(results || []);
      } catch (err) {
        console.error("Search query dispatch exception:", err);
      } finally {
        setSearchLoading(false);
      }
    }, 4500); // 450ms debounce

    return () => clearTimeout(delayDebounce);
  }, [searchQuery]);

  return (
    <div className="flex flex-col gap-6 w-full text-left font-sans select-none pb-20">
      
      {/* Search Header Container */}
      <div className="flex flex-col md:flex-row items-center justify-between gap-4 py-2 border-b border-white/5 pb-4">
        <div className="text-left w-full md:w-auto">
          <span className="text-[10px] text-neon-red font-mono tracking-widest font-bold uppercase flex items-center gap-1.5 justify-start">
            <Sparkles className="w-3.5 h-3.5" />
            Lumina Premium Node
          </span>
          <h1 className="text-xl md:text-2xl font-extrabold tracking-tight text-white uppercase mt-0.5 leading-none">
            Welcome to Lumina
          </h1>
        </div>

        {/* Safe text filter */}
        <div className="relative w-full md:w-80 lg:w-96">
          <span className="absolute inset-y-0 left-0 flex items-center pl-3.5 pointer-events-none text-gray-500">
            <Search className="w-4 h-4" />
          </span>
          <input
            id="search-bar-input"
            type="text"
            placeholder="Search films, series, anime, directors..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-white/5 border border-white/10 hover:border-white/20 focus:border-[#00f0ff]/50 focus:glow-cyan rounded-full text-xs font-medium text-white placeholder-gray-500 outline-0 backdrop-blur-md transition-all font-sans"
          />
        </div>
      </div>

      {searchQuery.trim() ? (
        /* --- SEARCH LAYOUT VIEW --- */
        <div className="flex flex-col gap-4">
          <div className="flex items-center justify-between border-b border-white/5 pb-2">
            <h2 className="text-sm font-bold font-mono text-gray-400 uppercase tracking-wider">
              Search Results for: <span className="text-neon-cyan select-text font-sans">"{searchQuery}"</span>
            </h2>
            <button 
              onClick={() => setSearchQuery("")}
              className="px-2.5 py-1 rounded bg-white/5 border border-white/5 text-[9px] font-mono text-gray-400 hover:text-white hover:bg-white/10"
            >
              Clear
            </button>
          </div>

          {searchLoading ? (
            <div className="flex items-center justify-center p-20 gap-3">
              <Loader2 className="w-6 h-6 text-neon-red animate-spin" />
              <span className="text-xs text-gray-500 font-mono uppercase tracking-wider">Resolving stream indexes...</span>
            </div>
          ) : searchResults.length === 0 ? (
            <div className="flex flex-col items-center justify-center p-20 border border-dashed border-white/5 rounded-2xl bg-white/2">
              <Film className="w-10 h-10 text-gray-600 mb-2 stroke-[1.5]" />
              <p className="text-xs text-gray-400 font-mono uppercase tracking-wide">No media corresponds to search query.</p>
              <p className="text-[10px] text-gray-600 font-sans mt-1">Try keywords like 'Cyberpunk', 'Dune', 'Matrix' or generic terms.</p>
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-5">
              {searchResults.map((item) => (
                <div 
                  key={item.id}
                  onClick={() => selectMedia(item)}
                  className="cursor-pointer group flex flex-col gap-2 relative transition-transform duration-300 hover:scale-[1.03] bg-transparent rounded-xl overflow-hidden"
                >
                  <div className="aspect-[2/3] w-full rounded-xl overflow-hidden glass border border-white/5 relative bg-gray-950">
                    <img 
                      src={item.poster_path ? `https://image.tmdb.org/t/p/w342${item.poster_path}` : "https://images.unsplash.com/photo-1578301978693-85fa9c0320b9?q=80&w=342&auto=format&fit=crop"} 
                      alt={item.title || item.name}
                      referrerPolicy="no-referrer"
                      loading="lazy"
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-gray-950 via-transparent to-transparent opacity-80" />
                    <div className="absolute bottom-2.5 left-2.5 right-2.5 text-left">
                      <span className="text-[9px] font-mono text-neon-red uppercase font-bold tracking-widest block mb-0.5">
                        {item.media_type === 'tv' ? 'TV' : 'Movie'}
                      </span>
                      <h4 className="text-xs font-bold text-white uppercase truncate">
                        {item.title || item.name}
                      </h4>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      ) : (
        /* --- MAIN MOUNT LAYOUT VIEW --- */
        <>
          {/* 3. Hero Slide Frame */}
          {loading ? (
            <div className="w-full h-[40vh] rounded-3xl animate-pulse bg-gray-800/60 relative overflow-hidden flex items-center justify-center">
              <div className="absolute inset-0 shimmer-anim"></div>
              <span className="text-xs text-gray-400 font-mono z-10">Syncing Satellite Assets...</span>
            </div>
          ) : (
            <HeroSection items={trending} />
          )}

          {/* Dynamic Aesthetic Genre Dimension Hubs Selection */}
          <div className="flex flex-col gap-3 mt-4">
            <h2 className="text-[10px] font-bold font-mono text-gray-500 tracking-widest uppercase block pl-1">
              Browse Art Spaces / Aesthetic Dimensions
            </h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3.5">
              {[
                { id: 'anime', name: 'Otaku Mode', subtitle: 'Cyberpunk Anime', color: '#00f0ff', icon: Gamepad2 },
                { id: 'cartoons', name: 'Playful Mode', subtitle: 'Family & Toons', color: '#ff007f', icon: Smile },
                { id: 'horror', name: 'The Abyss', subtitle: 'Horror Thriller', color: '#be0000', icon: Skull },
                { id: 'scifi', name: 'Cosmic Space', subtitle: 'Sci-Fi & Fantasy', color: '#bf00ff', icon: Atom },
                { id: 'movies', name: 'Cinematic Classic', subtitle: 'Drama & Action', color: '#d4af37', icon: Clapperboard }
              ].map((genre) => {
                const Icon = genre.icon;
                return (
                  <button
                    id={`dimension-hub-btn-${genre.id}`}
                    key={genre.id}
                    onClick={() => setGenreView(genre.id)}
                    className="flex flex-col text-left p-4 rounded-xl bg-white/2 border border-white/5 hover:bg-white/5 transition-all duration-300 group cursor-pointer transform hover:scale-104 relative overflow-hidden"
                  >
                    <div 
                      className="absolute inset-0 opacity-0 group-hover:opacity-[0.03] transition-opacity duration-300"
                      style={{ backgroundColor: genre.color }}
                    />
                    <div 
                      className="w-10 h-10 rounded-lg flex items-center justify-center mb-3 transition-all duration-300"
                      style={{ 
                        backgroundColor: `${genre.color}15`,
                        color: genre.color
                      }}
                    >
                      <Icon className="w-5 h-5 group-hover:rotate-12 transition-transform duration-300" />
                    </div>
                    <div className="flex flex-col leading-tight">
                      <span className="text-xs font-bold text-white uppercase tracking-wider block">
                        {genre.name}
                      </span>
                      <span className="text-[9px] text-gray-500 font-mono mt-0.5 uppercase block tracking-wider">
                        {genre.subtitle}
                      </span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* 4. Categorized Horizontals */}
          <div className="flex flex-col gap-2 mt-4">
            {loading ? (
              <>
                <SkeletonRow cardCount={6} />
                <SkeletonRow cardCount={6} />
              </>
            ) : (
              <>
                {/* Netflix-style Continue Watching row */}
                {history && history.length > 0 && (
                  <div className="flex flex-col gap-3 py-4 w-full relative group/row select-none">
                    <div className="flex items-center gap-2 px-1">
                      <div className="w-1.5 h-5 rounded-full bg-gradient-to-b from-[#00f0ff] to-[#0072ff] shadow-[0_0_10px_rgba(0,240,255,0.4)]" />
                      <h2 className="text-base md:text-xl font-bold font-sans tracking-wide uppercase text-white flex items-center">
                        Continue Watching
                        <span className="ml-2.5 w-1.5 h-1.5 bg-neon-cyan rounded-full animate-pulse shadow-[0_0_8px_#00f0ff] shrink-0" />
                      </h2>
                      <span className="text-[10px] font-mono text-gray-500 font-medium px-2 py-0.5 rounded bg-white/5 uppercase">
                        {history.length} In-Progress
                      </span>
                    </div>

                    <div className="w-full overflow-x-auto scroll-smooth scrollbar-hide py-2">
                      <div className="flex gap-4 md:gap-5 w-max px-1">
                        {history.slice(0, 10).map((item) => (
                          <div 
                            key={item.id}
                            onClick={() => selectMedia({
                              id: item.id,
                              title: item.title,
                              media_type: item.media_type,
                              poster_path: item.poster_path,
                              backdrop_path: item.backdrop_path,
                              overview: "",
                              vote_average: 0
                            })}
                            className="w-[180px] sm:w-[220px] md:w-[260px] bg-white/2 hover:bg-white/5 border border-white/5 hover:border-[#00f0ff]/30 rounded-xl overflow-hidden cursor-pointer transition-all duration-300 hover:scale-[1.03] group/continue relative shadow-lg"
                          >
                            {/* Landscape Thumbnail Stage */}
                            <div className="aspect-[16/9] w-full bg-gray-950 relative overflow-hidden">
                              <img 
                                src={item.backdrop_path ? `https://image.tmdb.org/t/p/w300${item.backdrop_path}` : `https://image.tmdb.org/t/p/w300${item.poster_path}`} 
                                alt={item.title}
                                referrerPolicy="no-referrer"
                                loading="lazy"
                                className="w-full h-full object-cover transition-transform duration-500 group-hover/continue:scale-105"
                              />
                              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover/continue:opacity-100 transition-opacity flex items-center justify-center">
                                <div className="w-10 h-10 rounded-full bg-[#00f0ff] flex items-center justify-center shadow-lg text-black">
                                  <Play className="w-4 h-4 fill-current ml-0.5" />
                                </div>
                              </div>

                              {/* Persistent progress bar at bottom */}
                              <div className="absolute bottom-0 left-0 right-0 h-1 bg-white/10">
                                <div 
                                  className="h-full bg-gradient-to-r from-[#00f0ff] to-[#0072ff]"
                                  style={{ width: `${item.progress}%` }}
                                />
                              </div>
                            </div>

                            {/* Card Details */}
                            <div className="p-3 text-left">
                              <span className="text-[9px] font-mono text-[#00f0ff] uppercase font-bold tracking-widest block mb-0.5">
                                {item.media_type === 'tv' ? 'TV SERIES' : 'MOVIE'} • {Math.round(item.progress)}% COMPLETED
                              </span>
                              <h4 className="text-xs font-bold text-white uppercase truncate">
                                {item.title}
                              </h4>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                )}

                <MediaRow title="Trending Blockbusters" items={trending} />
                <MediaRow title="Popular Cinema Releases" items={popularMovies} />
                <MediaRow title="Acclaimed Television Shows" items={popularTv} />
                <MediaRow title="Critically Top Rated" items={topRated} />
              </>
            )}
          </div>
        </>
      )}
    </div>
  );
};
export default HomeView;
