import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { useAestheticVideo } from "../hooks/useAestheticVideo";

export const AestheticVideoBackground: React.FC = () => {
  const { activeAsset, prefersReducedMotion } = useAestheticVideo();
  const [videoLoaded, setVideoLoaded] = useState(false);

  // If a user has "Reduce Motion" enabled, gracefully serve a static, beautiful aesthetic vignette instead of a video
  if (prefersReducedMotion) {
    return (
      <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none transition-all duration-1000 select-none">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeAsset.id}
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.15 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.8 }}
            className="absolute inset-0 w-full h-full object-cover grayscale-[30%] saturate-[1.2]"
            style={{
              backgroundImage: `url(${activeAsset.placeholderUrl})`,
              backgroundSize: "cover",
              backgroundPosition: "center",
            }}
          />
        </AnimatePresence>
        {/* Soft edge matching color overlay layer */}
        <div 
          className="absolute inset-0 transition-all duration-700"
          style={{ 
            backgroundImage: `linear-gradient(to bottom, transparent 0%, ${activeAsset.blendColor} 65%, var(--theme-bg, #0B0E11) 100%)` 
          }}
        />
      </div>
    );
  }

  return (
    <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none select-none">
      {/* 1. Underlying fallback layer: Renders immediately to prevent visual flashing during video asset switches */}
      <AnimatePresence mode="wait">
        <motion.div
          key={`placeholder-${activeAsset.id}`}
          initial={{ opacity: 0 }}
          animate={{ opacity: 0.08 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.8, ease: "easeInOut" }}
          className="absolute inset-0 w-full h-full"
          style={{
            backgroundImage: `url(${activeAsset.placeholderUrl})`,
            backgroundSize: "cover",
            backgroundPosition: "center",
            filter: "blur(8px) brightness(0.6)",
          }}
        />
      </AnimatePresence>

      {/* 2. Hardware Accelerated Cinematic Loop Video Stream */}
      <AnimatePresence mode="wait">
        <motion.div
          key={`video-container-${activeAsset.id}`}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 1.2, ease: "easeOut" }}
          className="absolute inset-0 w-full h-[90vh] md:h-full"
        >
          <video
            key={activeAsset.videoUrl}
            autoPlay
            loop
            muted
            playsInline
            onPlay={() => setVideoLoaded(true)}
            className="absolute inset-0 w-full h-full object-cover scale-[1.01] transition-all duration-1000"
            style={{ 
              opacity: videoLoaded ? activeAsset.intensity : 0,
              mixBlendMode: "screen" 
            }}
          >
            <source src={activeAsset.videoUrl} type="video/mp4" />
          </video>
        </motion.div>
      </AnimatePresence>

      {/* 3. Global blending shade mask to keep top & bottom menus highly visible & readable */}
      <div 
        className="absolute inset-0 pointer-events-none transition-all duration-1000 z-10"
        style={{ 
          backgroundImage: `linear-gradient(to bottom, transparent 0%, rgba(11, 14, 17, 0.4) 40%, ${activeAsset.blendColor} 75%, var(--theme-bg, #0B0E11) 100%)` 
        }}
      />
    </div>
  );
};

export default AestheticVideoBackground;
