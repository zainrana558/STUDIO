import React, { useState } from "react";
import { 
  Settings as SettingsIcon,
  Server,
  Monitor,
  Key,
  Database,
  RefreshCw,
  HelpCircle,
  Cpu,
  Tv,
  Eye,
  CheckCircle,
  BookOpen,
  Sparkles,
  Palette
} from "lucide-react";
import { useAppStore } from "../lib/store";
import { useAestheticTheme, THEME_SPECS, ThemeMode } from "../context/ThemeContext";
import { cn } from "../lib/utils";

export const SettingsView: React.FC = () => {
  const { 
    playbackServer, 
    setPlaybackServer, 
    playbackQuality, 
    setPlaybackQuality 
  } = useAppStore();

  const { activeTheme, setTheme } = useAestheticTheme();

  const [customKey, setCustomKey] = useState(() => {
    return localStorage.getItem("lumina_custom_tmdb_key") || "";
  });
  const [saveStatus, setSaveStatus] = useState<"idle" | "saved">("idle");
  const [testStatus, setTestStatus] = useState<"idle" | "checking" | "success" | "error">("idle");

  const handleKeySave = (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (customKey.trim() === "") {
        localStorage.removeItem("lumina_custom_tmdb_key");
      } else {
        localStorage.setItem("lumina_custom_tmdb_key", customKey.trim());
      }
      setSaveStatus("saved");
      setTimeout(() => setSaveStatus("idle"), 3000);
      
      // Refresh window to re-initialize TMDB client
      setTimeout(() => {
        window.location.reload();
      }, 800);
    } catch (e) {
      console.error(e);
    }
  };

  const handleTestConnection = async () => {
    setTestStatus("checking");
    const testKey = customKey.trim() || "unconfigured";
    
    // Test fetch directly to TMDB or local proxy
    try {
      let url = "";
      if (customKey.trim()) {
        url = `https://api.themoviedb.org/3/trending/all/day?api_key=${testKey}`;
      } else {
        url = `/api/health`;
      }

      const res = await fetch(url);
      if (res.ok) {
        setTestStatus("success");
      } else {
        setTestStatus("error");
      }
    } catch (err) {
      setTestStatus("error");
    }
  };

  return (
    <div className="flex flex-col gap-6 w-full text-left font-sans select-none pb-20">
      
      {/* View Header */}
      <div className="border-b border-white/5 pb-4">
        <span className="text-[10px] text-neon-red font-mono tracking-widest font-bold uppercase flex items-center gap-1.5 justify-start">
          <SettingsIcon className="w-3.5 h-3.5" />
          Lumina Terminal Configuration
        </span>
        <h1 className="text-xl md:text-2xl font-extrabold tracking-tight text-white uppercase mt-1 leading-none">
          Lumina Settings & Node Console
        </h1>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Playback Settings Panel */}
        <div className="lg:col-span-2 flex flex-col gap-6">
          
          {/* Section: Stream Nodes */}
          <div className="flex flex-col gap-4 bg-white/2 border border-white/5 rounded-2xl p-5 md:p-6 text-left relative overflow-hidden">
            <h3 className="text-sm font-bold font-mono text-white uppercase tracking-wider flex items-center gap-2 border-b border-white/5 pb-3">
              <Server className="w-4 h-4 text-neon-red" />
              Default Streaming Host Nodes
            </h3>
            <p className="text-xs text-gray-400 font-sans leading-relaxed">
              Traffic routes dynamically through these public index hosts. If streams stutter, pause, or fail to load, switch to an alternative node.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {[
                { val: 'vidsrc', name: 'Server 1 (VidSrc)', desc: 'Optimized high-speed movie routing API.' },
                { val: 'embedsu', name: 'Server 2 (Embed.su)', desc: 'High-definition source, including TV shows.' },
                { val: 'simulator', name: 'Server 3 (Offline / Trailer)', desc: 'Curated trailers loop. 100% stable fallbacks.' }
              ].map((srv) => {
                const isActive = playbackServer === srv.val;
                return (
                  <button
                    key={srv.val}
                    onClick={() => setPlaybackServer(srv.val)}
                    className={cn(
                      "flex flex-col gap-2 p-4 rounded-xl text-left border cursor-pointer transition-all duration-300",
                      isActive
                        ? "bg-neon-red/10 border-neon-red text-white glow-red"
                        : "bg-white/5 border-white/5 text-gray-400 hover:text-white hover:bg-white/10"
                    )}
                  >
                    <span className="text-xs font-mono font-bold uppercase">{srv.name}</span>
                    <span className="text-[10px] text-gray-400 block leading-normal">{srv.desc}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Section: Resolution Quality */}
          <div className="flex flex-col gap-4 bg-white/2 border border-white/5 rounded-2xl p-5 md:p-6 text-left">
            <h3 className="text-sm font-bold font-mono text-white uppercase tracking-wider flex items-center gap-2 border-b border-white/5 pb-3">
              <Monitor className="w-4 h-4 text-neon-purple animate-pulse" />
              Stream Quality Preferences
            </h3>
            <p className="text-xs text-gray-400 font-sans leading-relaxed">
              Set default video rendering resolutions. Handled natively on supporting server nodes.
            </p>

            <div className="flex flex-wrap gap-2">
              {[
                { val: 'auto', name: 'Automatic Resolution' },
                { val: '1080p', name: '1080p Full HD' },
                { val: '720p', name: '720p High Def' }
              ].map((ql) => {
                const isActive = playbackQuality === ql.val;
                return (
                  <button
                    key={ql.val}
                    onClick={() => setPlaybackQuality(ql.val)}
                    className={cn(
                      "px-4 py-2 text-xs font-mono font-bold uppercase rounded-lg border cursor-pointer transition-all duration-200",
                      isActive
                        ? "bg-neon-purple/20 border-neon-purple text-white glow-purple"
                        : "bg-white/5 border-white/5 text-gray-400 hover:text-white"
                    )}
                  >
                    {ql.name}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Section: Dynamic Aesthetic Themes Selector */}
          <div className="flex flex-col gap-4 bg-white/2 border border-white/5 rounded-2xl p-5 md:p-6 text-left relative overflow-hidden">
            <h3 className="text-sm font-bold font-mono text-white uppercase tracking-wider flex items-center gap-2 border-b border-white/5 pb-3">
              <Palette className="w-4 h-4 text-[#00f0ff] animate-pulse" />
              Dynamic Aesthetic Morphing (Visual Themes)
            </h3>
            <p className="text-xs text-gray-400 font-sans leading-relaxed">
              Mould the visual canvas, typography, grid rounding, borders, color palettes, and interactive physical animation rates of the entire platform instantly.
            </p>

            <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 mt-1.5">
              {(Object.keys(THEME_SPECS) as ThemeMode[]).map((tMode) => {
                const isCurrent = activeTheme === tMode;
                const spec = THEME_SPECS[tMode];
                return (
                  <button
                    key={tMode}
                    type="button"
                    onClick={() => setTheme(tMode)}
                    className={cn(
                      "flex flex-col items-center justify-between text-center p-3.5 rounded-xl border cursor-pointer select-none transition-all duration-300 transform hover:scale-105 min-h-24",
                      isCurrent
                        ? "bg-white/10 text-white shadow-lg"
                        : "bg-white/3 border-white/5 text-gray-400 hover:text-white hover:bg-white/5"
                    )}
                    style={{
                      borderColor: isCurrent ? spec.accentColor : "transparent",
                      boxShadow: isCurrent ? `0 0 15px ${spec.accentGlow}` : "none",
                    }}
                  >
                    {/* Visual representative dot */}
                    <div 
                      className="w-4 h-4 rounded-full mb-3 shadow"
                      style={{ backgroundColor: spec.accentColor }}
                    />
                    <div className="flex flex-col gap-0.5">
                      <span className="text-[10px] font-bold uppercase tracking-wider block font-sans truncate">{spec.name}</span>
                      <span className="text-[8px] font-mono text-gray-500 uppercase block tracking-widest">{tMode}</span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Section: Custom TMDB credentials API Key */}
          <div className="flex flex-col gap-4 bg-white/2 border border-white/5 rounded-2xl p-5 md:p-6 text-left relative overflow-hidden">
            <h3 className="text-sm font-bold font-mono text-white uppercase tracking-wider flex items-center gap-2 border-b border-white/5 pb-3">
              <Key className="w-4 h-4 text-neon-cyan" />
              TMDb API Key Configuration
            </h3>
            <p className="text-xs text-gray-400 font-sans leading-relaxed">
              If Lumina's backend `.env` variables are unconfigured, you can type a personal **TMDB V3 Movie Database Key** here. It persists locally in your client's workspace and unlocks the full live catalog instantly.
            </p>

            <form onSubmit={handleKeySave} className="flex flex-col sm:flex-row items-stretch gap-3">
              <input
                type="text"
                placeholder="Paste TMDb V3 API Key (32-character hex value)"
                value={customKey}
                onChange={(e) => setCustomKey(e.target.value)}
                className="flex-1 px-4 py-2.5 bg-black border border-white/10 focus:border-neon-cyan/50 focus:glow-cyan rounded-xl text-xs font-mono text-white placeholder-gray-600 outline-0 transition-all"
              />
              
              <div className="flex gap-2">
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-neon-cyan text-black hover:brightness-115 rounded-xl text-xs font-mono font-bold uppercase tracking-wider transition-all cursor-pointer shadow-md flex items-center justify-center gap-1 shrink-0"
                >
                  {saveStatus === "saved" ? (
                    <>
                      <CheckCircle className="w-4 h-4 fill-black" />
                      Saved / Restarting
                    </>
                  ) : (
                    "Save Key"
                  )}
                </button>
                
                <button
                  type="button"
                  onClick={handleTestConnection}
                  className="px-4 py-2.5 border border-white/10 bg-white/5 hover:bg-white/10 hover:border-white/20 rounded-xl text-xs font-mono text-gray-300 transition-all cursor-pointer"
                >
                  Test Connection
                </button>
              </div>
            </form>

            {/* Test validation feedback */}
            {testStatus !== "idle" && (
              <div className="text-xs mt-1 font-mono">
                {testStatus === "checking" && <span className="text-amber-400">Pinging server nodes...</span>}
                {testStatus === "success" && <span className="text-emerald-400">Connection authorized successfully! TMDB live catalog loaded.</span>}
                {testStatus === "error" && <span className="text-red-500">Connection failed: API returned status unauthorized. Verify key value.</span>}
              </div>
            )}
          </div>
        </div>

        {/* Informative Side Panel (Telemetry & Metadata Docs) */}
        <div className="flex flex-col gap-5 bg-gradient-to-br from-card-dark to-black/40 border border-white/5 p-5 md:p-6 rounded-2xl text-left h-fit relative">
          <div className="absolute right-4 top-4 opacity-5">
            <Cpu className="w-20 h-20 text-white" />
          </div>
          
          <h3 className="text-xs font-mono font-bold uppercase tracking-widest text-gray-500 flex items-center gap-1.5 border-b border-white/5 pb-2">
            <Database className="w-3.5 h-3.5 text-neon-purple" />
            Telemetry Console
          </h3>

          <div className="flex flex-col gap-4 text-xs font-mono">
            <div className="flex justify-between py-1.5 border-b border-white/2 font-sans">
              <span className="text-gray-400">System Mode:</span>
              <span className="text-neon-cyan uppercase font-mono font-bold">Secure Browser</span>
            </div>
            <div className="flex justify-between py-1.5 border-b border-white/2 font-sans">
              <span className="text-gray-400">Security Rule:</span>
              <span className="text-emerald-400 font-mono">SANDBOX ACTIVE</span>
            </div>
            <div className="flex justify-between py-1.5 border-b border-white/2 font-sans">
              <span className="text-gray-400">Platform Host:</span>
              <span className="text-gray-300">Vite-Express SPA</span>
            </div>
            <div className="flex justify-between py-1.5 border-b border-white/2 font-sans">
              <span className="text-gray-400">Cached Entries:</span>
              <span className="text-neon-purple">DYNAMIC REVALIDATE</span>
            </div>
          </div>

          <div className="mt-4 pt-4 border-t border-white/5 flex flex-col gap-3 font-sans">
            <h4 className="text-xs font-bold text-white uppercase tracking-wide flex items-center gap-1.5">
              <BookOpen className="w-4 h-4 text-neon-red" />
              API Environment Keys
            </h4>
            <div className="text-xs text-gray-400 leading-normal space-y-2">
              <p>
                Lumina pulls content and sliders automatically from high-fidelity caches.
              </p>
              <p>
                If you choose to run in permanent, limitless cloud mode, you may define **NEXT_PUBLIC_TMDB_API_KEY** in the AI Studio environment settings variables (Secrets) tab and re-compile the applet.
              </p>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};
export default SettingsView;
