import React, { useState } from "react";
import { useAuth, UserProfile, AVATAR_PRESETS } from "../context/AuthContext";
import { Plus, Edit2, Check, Trash2, X, Play } from "lucide-react";

export const ProfileSelectionView: React.FC = () => {
  const { 
    profiles, 
    selectProfile, 
    createProfile, 
    deleteProfile, 
    editProfile,
    user 
  } = useAuth();

  const [isManaging, setIsManaging] = useState(false);
  
  // Create state
  const [showAddModal, setShowAddModal] = useState(false);
  const [newProfileName, setNewProfileName] = useState("");
  const [selectedAvatarIdx, setSelectedAvatarIdx] = useState(0);

  // Edit State
  const [editingProfile, setEditingProfile] = useState<UserProfile | null>(null);
  const [editProfileName, setEditProfileName] = useState("");
  const [editAvatarIdx, setEditAvatarIdx] = useState(0);

  const handleCreateProfile = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProfileName.trim()) return;
    
    const success = createProfile(newProfileName, selectedAvatarIdx);
    if (success) {
      setNewProfileName("");
      setSelectedAvatarIdx(0);
      setShowAddModal(false);
    }
  };

  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingProfile || !editProfileName.trim()) return;

    const success = editProfile(editingProfile.id, editProfileName, editAvatarIdx);
    if (success) {
      setEditingProfile(null);
      setEditProfileName("");
    }
  };

  const handleDeleteProfile = (profileId: string) => {
    if (confirm("Are you sure you want to delete this profile? All watchlist and watch history progress data will be permanently cleared.")) {
      deleteProfile(profileId);
      setEditingProfile(null);
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-[#0B0E11] px-6 py-12 relative overflow-hidden font-sans select-none">
      
      {/* Background ambient light projections */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden z-0">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[60%] h-[60%] bg-[#ff073a]/4 rounded-full blur-[160px]" />
      </div>

      <div className="w-full max-w-4xl flex flex-col items-center text-center z-10">
        
        {/* Header Title block */}
        <h1 className="text-3xl md:text-4xl font-black text-white tracking-widest uppercase mb-2 animate-fade-in bg-clip-text text-transparent bg-gradient-to-b from-white to-white/60">
          Who's Watching?
        </h1>
        <p className="text-xs font-mono text-white/40 uppercase tracking-widest mb-10">
          Account Sync Code: {user?.email.toUpperCase()} ({user?.provider.toUpperCase()})
        </p>

        {/* Profiles Array Map grid */}
        <div className="flex flex-wrap items-center justify-center gap-6 md:gap-8 max-w-3xl mb-12">
          {profiles.map((profile) => {
            const avatar = AVATAR_PRESETS[profile.avatarIdx] || AVATAR_PRESETS[0];
            
            return (
              <div 
                key={profile.id}
                className="flex flex-col items-center gap-3.5 group relative"
              >
                
                {/* Profile Card Circle image representation */}
                <button
                  onClick={() => {
                    if (isManaging) {
                      setEditingProfile(profile);
                      setEditProfileName(profile.name);
                      setEditAvatarIdx(profile.avatarIdx);
                    } else {
                      selectProfile(profile.id);
                    }
                  }}
                  className="w-24 h-24 md:w-28 md:h-28 rounded-2xl relative cursor-pointer outline-none overflow-hidden p-1 transition-all duration-300 hover:scale-105"
                >
                  {/* Glowing background boundary based on color preset */}
                  <div className={`w-full h-full rounded-xl bg-gradient-to-tr ${avatar.bgColor} flex items-center justify-center shadow-lg relative transition-all duration-300 group-hover:shadow-[0_0_20px_rgba(255,7,58,0.4)]`}>
                    
                    {/* Representing avatar using capital letter from profile name */}
                    <span className="text-3xl md:text-4xl font-black text-white uppercase tracking-tighter drop-shadow-md">
                      {profile.name.charAt(0)}
                    </span>

                    {/* Mask on Managing Modes */}
                    {isManaging && (
                      <div className="absolute inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center rounded-xl transition-all">
                        <Edit2 className="w-6 h-6 text-[#00f0ff] animate-pulse drop-shadow" />
                      </div>
                    )}
                  </div>

                  {/* Dynamic hovering neon borders */}
                  <div className="absolute inset-0 border-2 border-transparent group-hover:border-[#ff073a]/40 rounded-2xl transition-all duration-300 pointer-events-none" />
                </button>

                {/* Profile Name */}
                <span className="text-xs md:text-sm font-bold text-white/70 group-hover:text-white uppercase tracking-wider font-mono">
                  {profile.name}
                </span>

                {/* Indicator check mark if selected previously */}
                <div className="absolute -top-1 -right-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  <span className="w-5 h-5 bg-[#ff073a] rounded-full flex items-center justify-center text-white text-[10px] shadow">
                    ✓
                  </span>
                </div>
              </div>
            );
          })}

          {/* ADD PROFILE Button Node (Shows if total profiles < 5) */}
          {profiles.length < 5 && (
            <div className="flex flex-col items-center gap-3.5 group">
              <button
                onClick={() => setShowAddModal(true)}
                className="w-24 h-24 md:w-28 md:h-28 rounded-2xl bg-white/5 border border-white/10 border-dashed hover:border-white/30 hover:bg-white/10 flex items-center justify-center cursor-pointer transition-all duration-300 hover:scale-105"
                title="Create New Profile"
              >
                <Plus className="w-8 h-8 text-white/30 group-hover:text-white transition-colors" />
              </button>
              <span className="text-xs md:text-sm font-bold text-white/30 group-hover:text-white uppercase tracking-wider font-mono">
                Add Profile
              </span>
            </div>
          )}
        </div>

        {/* Footer actions toggle */}
        <div className="flex flex-wrap items-center justify-center gap-4 mt-4">
          <button
            onClick={() => setIsManaging(!isManaging)}
            className={`px-8 py-2.5 rounded-lg text-xs font-bold font-mono uppercase tracking-wider transition-all duration-300 border cursor-pointer active:scale-95 ${
              isManaging 
                ? "bg-[#ff073a]/15 border-[#ff073a]/40 text-[#ff073a] hover:bg-[#ff073a]/25 shadow-[0_0_15px_rgba(255,7,58,0.2)]" 
                : "bg-white/5 border-white/10 text-white/50 hover:text-white hover:border-white/20"
            }`}
          >
            {isManaging ? "Done Managing" : "Manage Profiles"}
          </button>
        </div>

      </div>

      {/* ================= ADD PROFILE MODAL OVERLAY ================= */}
      {showAddModal && (
        <div className="fixed inset-0 bg-[#0B0E11]/90 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-white/5 border border-white/10 p-6 rounded-2xl shadow-2xl relative text-left">
            <button 
              onClick={() => setShowAddModal(false)}
              className="absolute top-4 right-4 text-white/40 hover:text-white transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <h2 className="text-lg font-black text-white uppercase tracking-wide mb-1.5 flex items-center gap-2">
              <Plus className="w-5 h-5 text-[#ff073a]" />
              Add User Profile
            </h2>
            <p className="text-[11px] text-white/40 mb-5 font-mono">Create up to 5 discrete watch profile entities.</p>

            <form onSubmit={handleCreateProfile} className="flex flex-col gap-4">
              <div>
                <label className="text-[10px] font-mono font-bold tracking-wider text-white/65 uppercase block mb-1.5">
                  Profile Name
                </label>
                <input
                  type="text"
                  maxLength={15}
                  value={newProfileName}
                  onChange={(e) => setNewProfileName(e.target.value)}
                  placeholder="e.g. Action Buff"
                  className="w-full px-4 py-2.5 bg-black/40 border border-white/10 focus:border-[#00f0ff]/50 focus:glow-cyan rounded-xl text-xs font-mono text-white placeholder-gray-650 outline-0 transition-all font-sans"
                  required
                  autoFocus
                />
              </div>

              {/* Avatar Selector Presets grid */}
              <div>
                <label className="text-[10px] font-mono font-bold tracking-wider text-white/65 uppercase block mb-2">
                  Select Theme Avatar Style
                </label>
                <div className="grid grid-cols-5 gap-2.5">
                  {AVATAR_PRESETS.map((preset) => (
                    <button
                      key={preset.idx}
                      type="button"
                      onClick={() => setSelectedAvatarIdx(preset.idx)}
                      className={`aspect-square rounded-xl bg-gradient-to-tr ${preset.bgColor} cursor-pointer relative transition-all border-2 ${
                        selectedAvatarIdx === preset.idx 
                          ? "border-[#ff073a] scale-103 shadow-[0_0_12px_rgba(255,7,58,0.5)]" 
                          : "border-transparent opacity-60 hover:opacity-100"
                      }`}
                    >
                      {selectedAvatarIdx === preset.idx && (
                        <div className="absolute top-1 right-1 bg-white rounded-full p-0.5 shadow">
                          <Check className="w-2.5 h-2.5 text-black stroke-[3]" />
                        </div>
                      )}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex gap-3 mt-4">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="flex-1 py-2.5 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl text-xs font-mono text-white uppercase transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-[#ff073a] hover:bg-red-650 rounded-xl text-xs font-mono font-bold text-white uppercase tracking-wider transition-all duration-300 shadow-[0_0_15px_rgba(255,7,58,0.3)] cursor-pointer"
                >
                  Create
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ================= EDIT PROFILE MODAL OVERLAY ================= */}
      {editingProfile && (
        <div className="fixed inset-0 bg-[#0B0E11]/90 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-white/5 border border-white/10 p-6 rounded-2xl shadow-2xl relative text-left">
            <button 
              onClick={() => setEditingProfile(null)}
              className="absolute top-4 right-4 text-white/40 hover:text-white transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <h2 className="text-lg font-black text-white uppercase tracking-wide mb-1.5 flex items-center gap-2">
              <Edit2 className="w-5 h-5 text-[#00f0ff]" />
              Manage Profile Settings
            </h2>
            <p className="text-[11px] text-white/40 mb-5 font-mono">Modify profile parameters or purge active profile.</p>

            <form onSubmit={handleSaveEdit} className="flex flex-col gap-4">
              <div>
                <label className="text-[10px] font-mono font-bold tracking-wider text-white/65 uppercase block mb-1.5">
                  Profile Label
                </label>
                <input
                  type="text"
                  maxLength={15}
                  value={editProfileName}
                  onChange={(e) => setEditProfileName(e.target.value)}
                  placeholder="e.g. Retro Room"
                  className="w-full px-4 py-2.5 bg-black/40 border border-white/10 focus:border-[#00f0ff]/50 focus:glow-cyan rounded-xl text-xs font-mono text-white placeholder-gray-650 outline-0 transition-all font-sans"
                  required
                />
              </div>

              {/* Avatar Preset Grid */}
              <div>
                <label className="text-[10px] font-mono font-bold tracking-wider text-white/65 uppercase block mb-2">
                  Modify Theme Avatar Style
                </label>
                <div className="grid grid-cols-5 gap-2.5">
                  {AVATAR_PRESETS.map((preset) => (
                    <button
                      key={preset.idx}
                      type="button"
                      onClick={() => setEditAvatarIdx(preset.idx)}
                      className={`aspect-square rounded-xl bg-gradient-to-tr ${preset.bgColor} cursor-pointer relative transition-all border-2 ${
                        editAvatarIdx === preset.idx 
                          ? "border-[#ff073a] scale-103 shadow-[0_0_12px_rgba(255,7,58,0.5)]" 
                          : "border-transparent opacity-60 hover:opacity-100"
                      }`}
                    >
                      {editAvatarIdx === preset.idx && (
                        <div className="absolute top-1 right-1 bg-white rounded-full p-0.5 shadow">
                          <Check className="w-2.5 h-2.5 text-black stroke-[3]" />
                        </div>
                      )}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex flex-col gap-2 mt-4">
                <div className="flex gap-3">
                  <button
                    type="button"
                    onClick={() => setEditingProfile(null)}
                    className="flex-1 py-2.5 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl text-xs font-mono text-white uppercase transition-colors cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="flex-1 py-2.5 bg-[#00f0ff] hover:brightness-110 text-black font-bold rounded-xl text-xs font-mono uppercase tracking-wider transition-all cursor-pointer shadow-[0_0_15px_rgba(0,240,255,0.2)]"
                  >
                    Save Changes
                  </button>
                </div>

                {/* Purge Profile button (only shows if total profiles count > 1) */}
                {profiles.length > 1 && (
                  <button
                    type="button"
                    onClick={() => handleDeleteProfile(editingProfile.id)}
                    className="w-full flex items-center justify-center gap-2 py-2.5 mt-2 bg-red-650/10 border border-red-500/20 text-red-400 hover:bg-red-500/20 rounded-xl text-xs font-mono uppercase tracking-wider cursor-pointer transition-all duration-300"
                  >
                    <Trash2 className="w-4 h-4" />
                    Delete Profile Permanently
                  </button>
                )}
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
export default ProfileSelectionView;
