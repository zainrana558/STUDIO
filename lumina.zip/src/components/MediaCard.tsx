import React from "react";
import { Play, Bookmark, Star, Check } from "lucide-react";
import { motion } from "motion/react";
import { MediaItem } from "../types";
import { useWatchlist } from "../context/WatchlistContext";
import { useAppStore } from "../lib/store";
import { useAestheticTheme } from "../context/ThemeContext";
import { getImageUrl } from "../lib/utils";
import { cn } from "../lib/utils";

interface MediaCardProps {
  item: MediaItem;
}

export const MediaCard: React.FC<MediaCardProps> = ({ item }) => {
  const { addToWatchlist, removeFromWatchlist, isInWatchlist } = useWatchlist();
  const { selectMedia, setHoveredMedia } = useAppStore();
  const { activeTheme, config, autoDetectTheme } = useAestheticTheme();

  const isBookmarked = isInWatchlist(item.id);
  const title = item.title || item.name || item.original_title || "Untitled Video";
  const releaseDate = item.release_date || item.first_air_date || "";
  const year = releaseDate ? releaseDate.split("-")[0] : "2024";

  const handleBookmarkClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (isBookmarked) {
      removeFromWatchlist(item.id);
    } else {
      addToWatchlist(item);
    }
  };

  const handleCardClick = () => {
    // Dynamically morph aesthetic theme when user clicks a media detail context
    autoDetectTheme(item);
    selectMedia(item);
  };

  // Get professional Framer Motion dynamics based on the active genre/theme context
  const getMotionDynamics = () => {
    switch (activeTheme) {
      case "anime": // Otaku Mode: Snappy, high velocity, 3D tilt feel
        return {
          whileHover: {
            scale: 1.06,
            rotateY: 8,
            rotateX: -4,
            boxShadow: `0 0 20px rgba(0, 240, 255, 0.4), 0 0 40px rgba(255, 0, 127, 0.2)`,
            transition: { type: "spring", stiffness: 280, damping: 12 },
          },
          whileTap: { scale: 0.96 },
        };
      case "playful": // Playful Mode: Highly elastic physics (bouncy ease/wobble)
        return {
          whileHover: {
            scale: 1.08,
            rotate: [0, -1.5, 1.5, -1, 0],
            transition: { type: "spring", stiffness: 180, damping: 6 },
          },
          whileTap: { scale: 0.9 },
        };
      case "abyss": // The Abyss: Creepy slow burn mystery fade, low key scaling
        return {
          whileHover: {
            scale: 1.015,
            filter: "brightness(1.15) contrast(1.05)",
            boxShadow: "0 0 30px rgba(190, 0, 0, 0.35)",
            transition: { duration: 0.45, ease: [0.16, 1, 0.3, 1] },
          },
          whileTap: { scale: 0.99 },
        };
      case "cosmic": // Cosmic Mode: Ethereal floating y-offset & violet glows
        return {
          whileHover: {
            scale: 1.04,
            y: -12,
            boxShadow: `0 15px 35px rgba(191, 0, 255, 0.3)`,
            transition: { type: "spring", stiffness: 100, damping: 16 },
          },
          whileTap: { scale: 0.97 },
        };
      case "classic":
      default: // General Movies: Elegant Multi-layered cinematic gold glow
        return {
          whileHover: {
            scale: 1.03,
            y: -4,
            boxShadow: `0 12px 24px -6px rgba(0, 0, 0, 0.6), 0 0 15px rgba(212, 175, 55, 0.25)`,
            transition: { type: "spring", stiffness: 180, damping: 18 },
          },
          whileTap: { scale: 0.98 },
        };
    }
  };

  // Border highlighting mapping for active modes
  const getThemeBorderClass = () => {
    switch (activeTheme) {
      case "anime":
        return "border-2 border-transparent group-hover:border-[#00f0ff]";
      case "playful":
        return "border border-transparent group-hover:border-[#ff007f]/50";
      case "abyss":
        return "border-b-2 border-transparent group-hover:border-[#be0000]";
      case "cosmic":
        return "border border-white/5 group-hover:border-[#bf00ff]/60";
      case "classic":
      default:
        return "border border-white/5 group-hover:border-[#d4af37]/45";
    }
  };

  // Accent gradient titles
  const getThemeTitleClass = () => {
    switch (activeTheme) {
      case "anime":
        return "group-hover:text-[#00f0ff] font-anime tracking-wider";
      case "playful":
        return "group-hover:text-[#ff007f] font-playful tracking-wide";
      case "abyss":
        return "group-hover:text-[#be0000] font-serif-horror font-medium tracking-widest lowercase";
      case "cosmic":
        return "group-hover:text-[#bf00ff] font-cosmic tracking-normal";
      case "classic":
      default:
        return "group-hover:text-[#d4af37] font-sans";
    }
  };

  return (
    <motion.div
      id={`media-card-${item.id}`}
      onClick={handleCardClick}
      onMouseEnter={() => setHoveredMedia(item)}
      onMouseLeave={() => setHoveredMedia(null)}
      className={cn(
        "group flex flex-col gap-2 relative bg-transparent cursor-pointer select-none transition-transform duration-300 z-10 hover:z-25",
        config.cardRadius
      )}
      {...getMotionDynamics()}
      style={{ perspective: 1000 }} // Support 3D tilts for Anime
    >
      {/* Aspect Poster container */}
      <div 
        className={cn(
          "aspect-[2/3] w-full overflow-hidden bg-white/5 relative bg-gray-950 transition-all duration-300",
          config.cardRadius,
          getThemeBorderClass()
        )}
      >
        {/* Poster Artwork image */}
        <img 
          src={getImageUrl(item.poster_path, 'w500', 'poster')} 
          alt={title}
          referrerPolicy="no-referrer"
          loading="lazy"
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
        />

        {/* Dark Shadow Overlay masking */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-transparent to-black/30 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

        {/* Absolute floating controls: Rating badge top-left */}
        <div 
          className={cn(
            "absolute top-2.5 left-2.5 px-2 py-0.5 rounded-md bg-black/80 backdrop-blur-md border flex items-center gap-1 z-10 transition-colors",
            activeTheme === "anime" ? "border-[#00f0ff]/40 text-[#00f0ff]" : 
            activeTheme === "playful" ? "border-pink-500/20 text-pink-400" :
            activeTheme === "abyss" ? "border-red-950/20 text-red-500" :
            activeTheme === "cosmic" ? "border-purple-500/30 text-purple-400" : "border-white/5 text-gray-200"
          )}
        >
          <Star className="w-3 h-3 text-yellow-500 fill-current" />
          <span className="text-[10px] font-mono font-bold">
            {item.vote_average ? item.vote_average.toFixed(1) : "N/A"}
          </span>
        </div>

        {/* Absolute floating controls: Bookmark button top-right */}
        <button
          id={`media-bookmark-btn-${item.id}`}
          onClick={handleBookmarkClick}
          className={cn(
            "absolute top-2.5 right-2.5 p-2 rounded-lg backdrop-blur-sm border transition-all duration-350 cursor-pointer active:scale-90 z-10",
            isBookmarked 
              ? activeTheme === "anime" ? "bg-[#00f0ff]/20 border-[#00f0ff]/60 text-[#00f0ff]" :
                activeTheme === "playful" ? "bg-[#ff007f]/20 border-[#ff007f]/60 text-[#ff007f]" :
                activeTheme === "abyss" ? "bg-[#be0000]/20 border-[#be0000]/65 text-[#be0000]" :
                activeTheme === "cosmic" ? "bg-[#bf00ff]/20 border-[#bf00ff]/60 text-[#bf00ff]" : "bg-[#ff073a]/20 border-[#ff073a]/60 text-[#ff073a]"
              : "bg-black/60 border-white/5 text-gray-300 hover:text-white hover:bg-black/90 hover:border-white/20"
          )}
          title={isBookmarked ? "Remove from Watchlist" : "Add to Watchlist"}
        >
          {isBookmarked ? (
            <Check className="w-3.5 h-3.5 stroke-[2.5]" />
          ) : (
            <Bookmark className="w-3.5 h-3.5" />
          )}
        </button>

        {/* Film grain overlay (for Horror Abyss mode) */}
        {activeTheme === "abyss" && (
          <div className="absolute inset-0 pointer-events-none opacity-[0.06] mix-blend-overlay bg-[radial-gradient(#fff_1px,transparent_1px)] [background-size:16px_16px] animate-[pulse_3s_infinite]" />
        )}

        {/* Hover Centered Play Symbol Overlay */}
        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none z-10">
          <div 
            className="w-12 h-12 rounded-full border flex items-center justify-center transform scale-90 group-hover:scale-100 transition-transform duration-300 text-white shadow-lg"
            style={{ 
              backgroundColor: config.accentColor,
              borderColor: `${config.accentColor}c0`,
              boxShadow: `0 0 20px ${config.accentGlow}` 
            }}
          >
            <Play className="w-5 h-5 fill-white text-white ml-0.5" />
          </div>
        </div>
      </div>

      {/* Card Info details */}
      <div className="flex flex-col text-left px-1 mt-0.5">
        <h3 className={cn(
          "text-xs md:text-sm font-bold tracking-wide line-clamp-1 transition-colors uppercase",
          getThemeTitleClass()
        )}>
          {title}
        </h3>
        <div className="flex items-center gap-2 text-[10px] text-gray-500 font-mono">
          <span>{year}</span>
          <span className="w-1.5 h-1.5 rounded-full bg-gray-700" />
          <span 
            className="uppercase text-[9px] font-bold tracking-widest leading-none mt-[1px]"
            style={{ color: config.accentColor }}
          >
            {item.media_type === "tv" ? "TV SHOW" : "MOVIE"}
          </span>
        </div>
      </div>
    </motion.div>
  );
};
export default MediaCard;
