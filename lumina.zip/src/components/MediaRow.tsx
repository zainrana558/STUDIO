import React, { useRef, useState, useEffect } from "react";
import { ChevronLeft, ChevronRight, Eye } from "lucide-react";
import { MediaItem } from "../types";
import { MediaCard } from "./MediaCard";
import { cn } from "../lib/utils";

interface MediaRowProps {
  title: string;
  items: MediaItem[];
  onSeeAll?: () => void;
}

export const MediaRow: React.FC<MediaRowProps> = ({ title, items, onSeeAll }) => {
  const rowRef = useRef<HTMLDivElement>(null);
  const [showLeftArrow, setShowLeftArrow] = useState(false);
  const [showRightArrow, setShowRightArrow] = useState(true);

  // Re-evaluates arrow visibility based on scroll states
  const checkScrollState = () => {
    if (rowRef.current) {
      const { scrollLeft, scrollWidth, clientWidth } = rowRef.current;
      setShowLeftArrow(scrollLeft > 5);
      // Math.ceil protects against small floating point differences in some browsers
      setShowRightArrow(Math.ceil(scrollLeft + clientWidth) < scrollWidth - 5);
    }
  };

  useEffect(() => {
    const el = rowRef.current;
    if (el) {
      el.addEventListener("scroll", checkScrollState, { passive: true });
      // Call once initially
      checkScrollState();
      
      // Also observe resize to refresh arrows
      const observer = new ResizeObserver(() => checkScrollState());
      observer.observe(el);
      
      return () => {
        el.removeEventListener("scroll", checkScrollState);
        observer.disconnect();
      };
    }
  }, [items]);

  const scroll = (direction: "left" | "right") => {
    if (rowRef.current) {
      const { scrollLeft, clientWidth } = rowRef.current;
      const scrollOffset = direction === "left" 
        ? scrollLeft - clientWidth * 0.75 
        : scrollLeft + clientWidth * 0.75;

      rowRef.current.scrollTo({
        left: scrollOffset,
        behavior: "smooth",
      });
    }
  };

  if (!items || items.length === 0) return null;

  return (
    <div className="flex flex-col gap-3 py-4 w-full relative group/row select-none">
      {/* Title block */}
      <div className="flex items-center justify-between px-1">
        <div className="flex items-center gap-2">
          {/* Neon accent pipe */}
          <div className="w-1.5 h-5 rounded-full bg-gradient-to-b from-[#ff073a] to-[#bf00ff] shadow-[0_0_10px_rgba(255,7,58,0.4)]" />
          <h2 className="text-base md:text-xl font-bold font-sans tracking-wide uppercase text-white flex items-center">
            {title}
            <span className="ml-2.5 w-1.5 h-1.5 bg-[#00f0ff] rounded-full animate-pulse shadow-[0_0_8px_#00f0ff] shrink-0" />
          </h2>
          <span className="text-[10px] font-mono text-gray-500 font-medium px-2 py-0.5 rounded bg-white/5 uppercase">
            {items.length} Titles
          </span>
        </div>

        {onSeeAll && (
          <button
            onClick={onSeeAll}
            className="group/btn flex items-center gap-1.5 text-xs font-mono font-bold tracking-wider uppercase text-[#00f0ff] hover:text-white transition-colors cursor-pointer"
          >
            See All
            <ChevronRight className="w-3.5 h-3.5 group-hover/btn:translate-x-1 transition-transform" />
          </button>
        )}
      </div>

      {/* Row Wrapper with scroll indicators */}
      <div className="relative w-full">
        {/* Left Arrow button */}
        <button
          onClick={() => scroll("left")}
          className={cn(
            "absolute left-0 top-1/2 -translate-y-1/2 -ml-2 w-10 h-16 rounded-r-xl bg-white/5 border-r border-white/10 z-30 flex items-center justify-center text-white hover:text-[#ff073a] hover:border-[#ff073a]/40 transition-all duration-300 cursor-pointer shadow-lg opacity-0 group-hover/row:opacity-100 disabled:opacity-0 disabled:pointer-events-none backdrop-blur-md",
            !showLeftArrow && "pointer-events-none opacity-0!"
          )}
          aria-label="Scroll Left"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>

        {/* Right Arrow button */}
        <button
          onClick={() => scroll("right")}
          className={cn(
            "absolute right-0 top-1/2 -translate-y-1/2 -mr-2 w-10 h-16 rounded-l-xl bg-white/5 border-l border-white/10 z-30 flex items-center justify-center text-white hover:text-[#ff073a] hover:border-[#ff073a]/40 transition-all duration-300 cursor-pointer shadow-lg opacity-0 group-hover/row:opacity-100 disabled:opacity-0 disabled:pointer-events-none backdrop-blur-md",
            !showRightArrow && "pointer-events-none opacity-0!"
          )}
          aria-label="Scroll Right"
        >
          <ChevronRight className="w-5 h-5" />
        </button>

        {/* Fade Out Edge masks (indicates offscreen list on desktops) */}
        <div className="absolute left-0 top-0 bottom-0 w-12 bg-gradient-to-r from-[#0B0E11] to-transparent z-10 pointer-events-none opacity-0 group-hover/row:opacity-100 transition-opacity duration-300" />
        <div className="absolute right-0 top-0 bottom-0 w-12 bg-gradient-to-l from-[#0B0E11] to-transparent z-10 pointer-events-none opacity-0 group-hover/row:opacity-100 transition-opacity duration-300" />

        {/* Outer scrolling container */}
        <div 
          ref={rowRef}
          className="w-full overflow-x-auto overflow-y-hidden scroll-smooth scrollbar-hide py-2"
        >
          {/* Grid Layout that maps to flex elements inside list */}
          <div className="flex gap-4 md:gap-5 w-max px-1">
            {items.map((item) => (
              <div 
                key={item.id}
                className="w-[140px] sm:w-[170px] md:w-[190px] xl:w-[210px]"
              >
                <MediaCard item={item} />
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
export default MediaRow;
