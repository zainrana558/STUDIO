import React, { useState, useEffect } from "react";
import { 
  ArrowLeft, 
  Clock, 
  Calendar, 
  Star, 
  Check, 
  Plus, 
  Compass, 
  Users,
  Award,
  Trash2
} from "lucide-react";
import { MediaItem, MediaDetails } from "../types";
import { tmdbClient } from "../lib/tmdb/client";
import { useWatchlist } from "../context/WatchlistContext";
import { useAppStore } from "../lib/store";
import { useAuth } from "../context/AuthContext";
import { VideoPlayer } from "./VideoPlayer";
import { MediaRow } from "./MediaRow";
import { SkeletonText } from "./SkeletonLoader";
import { cn, getImageUrl } from "../lib/utils";

export const DetailsView: React.FC = () => {
  const { selectedMedia, selectMedia, setView } = useAppStore();
  const { addToWatchlist, removeFromWatchlist, isInWatchlist } = useWatchlist();
  const { user, currentProfile } = useAuth();

  const [details, setDetails] = useState<MediaDetails | null>(null);
  const [recommendations, setRecommendations] = useState<MediaItem[]>([]);
  const [loading, setLoading] = useState(true);

  // Profile-specific Ratings state
  const [profileRating, setProfileRating] = useState<number | null>(null);
  const [hoverRating, setHoverRating] = useState<number | null>(null);

  const activeMedia = selectedMedia;

  const getRatingsStorageKey = () => {
    if (user && currentProfile) {
      return `lumina_ratings_${user.email}_${currentProfile.id}`;
    }
    return null;
  };

  // 1. Fetch complete details + recommendation slider on selection change
  useEffect(() => {
    if (!activeMedia) return;

    const fetchDetails = async () => {
      setLoading(true);
      try {
        const detailsData = await tmdbClient.getDetails(activeMedia.media_type, activeMedia.id);
        setDetails(detailsData);

        // Recommendations fallback
        const recList = await tmdbClient.getPopular(activeMedia.media_type);
        const cleanRecs = (recList || []).filter(item => item.id !== activeMedia.id);
        setRecommendations(cleanRecs);
      } catch (err) {
        console.error("Details view fetch exception:", err);
      } finally {
        setLoading(false);
      }
    };

    fetchDetails();

    // Load active profile rating for this media item if any
    const ratingsKey = getRatingsStorageKey();
    if (ratingsKey) {
      try {
        const storedRatings = localStorage.getItem(ratingsKey);
        if (storedRatings) {
          const parsed = JSON.parse(storedRatings);
          setProfileRating(parsed[activeMedia.id] || null);
        } else {
          setProfileRating(null);
        }
      } catch (e) {
        console.error("Could not fetch profile ratings", e);
        setProfileRating(null);
      }
    } else {
      setProfileRating(null);
    }
  }, [activeMedia?.id, activeMedia?.media_type, user?.email, currentProfile?.id]);

  const handleRateContent = (ratingValue: number) => {
    if (!activeMedia) return;
    const ratingsKey = getRatingsStorageKey();
    if (!ratingsKey) return;

    try {
      const storedRatings = localStorage.getItem(ratingsKey);
      const parsed = storedRatings ? JSON.parse(storedRatings) : {};
      parsed[activeMedia.id] = ratingValue;
      localStorage.setItem(ratingsKey, JSON.stringify(parsed));
      setProfileRating(ratingValue);
    } catch (e) {
      console.error("Failed to commit profile rating", e);
    }
  };

  const handleClearRating = () => {
    if (!activeMedia) return;
    const ratingsKey = getRatingsStorageKey();
    if (!ratingsKey) return;

    try {
      const storedRatings = localStorage.getItem(ratingsKey);
      if (storedRatings) {
        const parsed = JSON.parse(storedRatings);
        delete parsed[activeMedia.id];
        localStorage.setItem(ratingsKey, JSON.stringify(parsed));
      }
      setProfileRating(null);
    } catch (e) {
      console.error("Failed to delete profile rating", e);
    }
  };

  if (!activeMedia) {
    return (
      <div className="flex flex-col items-center justify-center p-20 text-center font-sans">
        <Compass className="w-12 h-12 text-gray-650 mb-2 animate-spin-[10s]" />
        <p className="text-xs text-gray-500 font-mono font-bold uppercase">No target stream selected.</p>
        <button
          onClick={() => setView('home')}
          className="mt-3 px-4 py-2 text-xs font-mono rounded bg-[#ff073a] text-white uppercase font-bold"
        >
          Discover Browse
        </button>
      </div>
    );
  }

  const isBookmarked = isInWatchlist(activeMedia.id);
  const titleText = activeMedia.title || activeMedia.name || activeMedia.original_title || "Lumina Video";
  
  const formattedRuntime = details?.runtime 
    ? `${Math.floor(details.runtime / 60)}h ${details.runtime % 60}m`
    : details?.number_of_seasons
      ? `${details.number_of_seasons} Seasons (${details.number_of_episodes || 0} Ep)`
      : "142 mins";

  const bannerYear = activeMedia.release_date 
    ? activeMedia.release_date.split("-")[0] 
    : activeMedia.first_air_date 
      ? activeMedia.first_air_date.split("-")[0] 
      : "2024";

  return (
    <div className="flex flex-col gap-6 w-full text-left font-sans select-none pb-24">
      
      {/* 2. Top Navigation header back button */}
      <div className="flex items-center gap-3">
        <button
          onClick={() => selectMedia(null)}
          className="flex items-center gap-2.5 px-3 py-2 bg-white/5 border border-white/5 hover:border-white/10 hover:bg-white/10 transition-all text-xs font-mono font-bold tracking-wide text-gray-300 hover:text-white rounded-xl cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4 text-[#ff073a]" />
          Back to Listings
        </button>
        <div className="h-4 w-[1px] bg-white/10" />
        <span className="text-[10px] text-gray-500 font-mono uppercase tracking-widest hidden md:inline">
          Active Feed: {activeMedia.media_type.toUpperCase()} / ID: {activeMedia.id}
        </span>
      </div>

      {/* 3. Fully Operational Custom video player with details payload */}
      <VideoPlayer media={activeMedia} details={details} />

      {/* 4. Metadata Details Block */}
      {loading ? (
        <div className="flex flex-col gap-4 bg-white/2 border border-white/5 rounded-2xl p-6 mt-2">
          <div className="h-6 w-64 bg-gray-850 animate-pulse rounded"></div>
          <SkeletonText lines={4} />
        </div>
      ) : details ? (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-2">
          
          {/* Main Info Columns (2 Columns) */}
          <div className="lg:col-span-2 flex flex-col gap-4 bg-white/2 border border-white/5 rounded-2xl p-5 md:p-6 text-left relative overflow-hidden">
            
            {/* Ambient Background Glow Banner projection */}
            <div 
              className="absolute inset-0 w-full h-full bg-cover bg-center opacity-5 pointer-events-none"
              style={{ backgroundImage: `url(${getImageUrl(details.backdrop_path, 'w1280')})` }}
            />

            <div className="flex flex-wrap items-center gap-3 relative z-10">
              <span className="px-2 py-0.5 rounded bg-purple-550/20 border border-purple-500/40 text-[9px] font-mono tracking-widest font-bold text-purple-400 uppercase leading-none">
                {details.status || "Released"}
              </span>
              <span className="flex items-center gap-1 text-xs text-yellow-500 font-bold pl-2">
                <Star className="w-4 h-4 fill-current text-yellow-500" />
                {details.vote_average.toFixed(1)} / 10
              </span>
              {profileRating !== null && (
                <span className="flex items-center gap-1 text-xs text-[#00f0ff] font-mono font-black pl-2 border-l border-white/10">
                  YOUR RATING: {profileRating} ★
                </span>
              )}
              <span className="text-gray-400 text-xs pl-2 border-l border-white/10 flex items-center gap-1">
                <Clock className="w-3.5 h-3.5 text-[#00f0ff]" />
                {formattedRuntime}
              </span>
              <span className="text-gray-400 text-xs pl-2 border-l border-white/10 flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5 text-[#ff073a]" />
                {bannerYear}
              </span>
            </div>

            <h1 className="text-2xl md:text-3xl font-extrabold uppercase tracking-tight text-white mb-1 relative z-10 leading-none">
              {titleText}
            </h1>

            {details.tagline && (
              <p className="text-xs font-serif italic text-[#00f0ff]/90 relative z-10 leading-none">
                "{details.tagline}"
              </p>
            )}

            {/* Description copy */}
            <p className="text-sm text-gray-300 font-sans tracking-wide leading-relaxed relative z-10 mt-1 pb-3 border-b border-white/5">
              {details.overview || "This feature release deep-dives in the retro cinematic cybernetic ecosystem. Connect safe streams to enjoy multi-quality indices."}
            </p>

            {/* Genre tags panel */}
            <div className="flex flex-col gap-2 relative z-10">
              <span className="text-[10px] text-gray-500 font-mono uppercase tracking-widest">Tags / Genre Tags</span>
              <div className="flex flex-wrap gap-2">
                {details.genres?.map((g) => (
                  <span 
                    key={g.id}
                    className="px-2.5 py-1 text-[10px] font-mono font-medium rounded-md bg-white/5 border border-white/5 text-gray-300 hover:text-white"
                  >
                    {g.name}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Sidebar Actions & Ratings Column (1 Column) */}
          <div className="flex flex-col gap-4 bg-white/2 border border-white/5 rounded-2xl p-5 md:p-6 text-left">
            
            {/* Quick Actions buttons */}
            <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-[#ff073a] flex items-center gap-1.5 border-b border-white/5 pb-2">
              <Award className="w-3.5 h-3.5 stroke-[2.5]" />
              Lumina User Actions
            </h3>

            <div className="flex flex-col gap-3">
              <button
                onClick={() => {
                  if (isBookmarked) {
                    removeFromWatchlist(activeMedia.id);
                  } else {
                    addToWatchlist(activeMedia);
                  }
                }}
                className={cn(
                  "w-full flex items-center justify-center gap-2 py-2.5 rounded-xl text-xs font-mono font-bold uppercase tracking-wider cursor-pointer border transition-all duration-300 active:scale-95",
                  isBookmarked
                    ? "bg-emerald-550/15 border-emerald-500/40 text-emerald-400 hover:bg-emerald-500/25"
                    : "bg-white/5 border-white/5 hover:border-white/10 text-white hover:bg-white/10"
                )}
              >
                {isBookmarked ? (
                  <>
                    <Check className="w-4 h-4 stroke-[2.5] text-emerald-400" />
                    In My Watchlist
                  </>
                ) : (
                  <>
                    <Plus className="w-4 h-4" />
                    Add to Watchlist
                  </>
                )}
              </button>

              {/* ================= USER RATING (1-10 DECK) ================= */}
              <div className="bg-black/30 border border-white/5 rounded-xl p-3.5 text-center mt-1 flex flex-col gap-3">
                <div className="flex justify-between items-center text-[10px] font-mono uppercase tracking-wider text-gray-500">
                  <span>Profile Rating Hub</span>
                  <span className="text-white font-bold text-xs">
                    {profileRating ? `${profileRating} / 10` : "Unrated"}
                  </span>
                </div>

                {/* Stars 1-10 Horizontal nodes */}
                <div className="flex items-center justify-between gap-1">
                  {Array.from({ length: 10 }, (_, index) => {
                    const starsVal = index + 1;
                    const isYellow = hoverRating !== null 
                      ? starsVal <= hoverRating 
                      : profileRating !== null && starsVal <= profileRating;

                    return (
                      <button
                        key={starsVal}
                        type="button"
                        onClick={() => handleRateContent(starsVal)}
                        onMouseEnter={() => setHoverRating(starsVal)}
                        onMouseLeave={() => setHoverRating(null)}
                        className="p-0.5 transition-transform hover:scale-120 cursor-pointer text-gray-600 hover:text-yellow-400 active:scale-90"
                        title={`Rate: ${starsVal} / 10`}
                      >
                        <Star 
                          className={cn(
                            "w-4 h-4 transition-all duration-150", 
                            isYellow ? "text-yellow-400 fill-current" : "text-gray-600"
                          )} 
                        />
                      </button>
                    );
                  })}
                </div>

                {profileRating !== null && (
                  <button
                    onClick={handleClearRating}
                    className="flex items-center justify-center gap-1.5 text-[10px] font-mono uppercase text-[#ff073a] hover:underline cursor-pointer bg-transparent border-0 outline-0 mt-1"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    Clear My Rating
                  </button>
                )}
              </div>
            </div>

            {/* Cast List */}
            <div className="flex flex-col gap-3 mt-3">
              <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-gray-500 flex items-center gap-1.5 border-b border-white/5 pb-1.5">
                <Users className="w-3.5 h-3.5 stroke-[2.5]" />
                Top Cast Members
              </h3>

              <div className="flex flex-col gap-2.5 h-32 overflow-y-auto scrollbar-hide pr-1">
                {details.credits?.cast && details.credits.cast.length > 0 ? (
                  details.credits.cast.slice(0, 4).map((actor) => (
                    <div key={actor.id} className="flex items-center gap-3 border-b border-white/2 pb-1.5 last:border-0 last:pb-0">
                      <div className="w-7 h-7 rounded-full bg-gray-900 border border-white/10 overflow-hidden shrink-0">
                        <img 
                          src={getImageUrl(actor.profile_path, 'w342', 'avatar')} 
                          alt={actor.name} 
                          referrerPolicy="no-referrer"
                          loading="lazy"
                          className="w-full h-full object-cover" 
                        />
                      </div>
                      <div className="flex flex-col text-left min-w-0 leading-none">
                        <span className="text-xs font-bold text-gray-200 truncate">{actor.name}</span>
                        <span className="text-[10px] text-gray-500 font-mono truncate mt-0.5">{actor.character}</span>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="flex items-center justify-center py-5">
                    <span className="text-[10px] font-mono text-gray-500 uppercase">Cast list unindexed</span>
                  </div>
                )}
              </div>
            </div>

          </div>

        </div>
      ) : (
        <div className="p-10 border border-white/5 rounded-2xl bg-white/2 text-center text-xs text-gray-400">
          Failure: details failed to structure.
        </div>
      )}

      {/* 5. You May Also Like Recommendations segment */}
      {recommendations.length > 0 && (
        <div className="mt-4">
          <MediaRow title="More Like This Selection" items={recommendations} />
        </div>
      )}

    </div>
  );
};
export default DetailsView;
