import React from "react";

export const SkeletonCard: React.FC = () => {
  return (
    <div className="flex flex-col gap-2 w-full animate-pulse select-none">
      {/* 2:3 aspect placeholder for poster */}
      <div className="aspect-[2/3] w-full rounded-lg bg-gray-800/60 border border-gray-700/20 relative overflow-hidden">
        <div className="absolute inset-0 shimmer-anim"></div>
      </div>
      <div className="h-4 w-4/5 rounded bg-gray-800/60 relative overflow-hidden mt-1">
        <div className="absolute inset-0 shimmer-anim"></div>
      </div>
      <div className="flex gap-2 items-center">
        <div className="h-3 w-1/4 rounded bg-gray-800/60 relative overflow-hidden">
          <div className="absolute inset-0 shimmer-anim"></div>
        </div>
        <div className="h-3 w-1/3 rounded bg-gray-800/60 relative overflow-hidden">
          <div className="absolute inset-0 shimmer-anim"></div>
        </div>
      </div>
    </div>
  );
};

export const SkeletonRow: React.FC<{ cardCount?: number }> = ({ cardCount = 6 }) => {
  return (
    <div className="flex flex-col gap-3 py-4 w-full">
      <div className="h-6 w-48 rounded bg-gray-800/60 relative overflow-hidden mb-2">
        <div className="absolute inset-0 shimmer-anim"></div>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-4">
        {Array.from({ length: cardCount }).map((_, index) => (
          <SkeletonCard key={index} />
        ))}
      </div>
    </div>
  );
};

export const SkeletonText: React.FC<{ lines?: number }> = ({ lines = 4 }) => {
  return (
    <div className="flex flex-col gap-2 w-full py-2 animate-pulse">
      {Array.from({ length: lines }).map((_, idx) => {
        // Varying widths to look realistic
        const widths = ["w-full", "w-11/12", "w-4/5", "w-2/3", "w-1/2"];
        const wClass = widths[idx % widths.length];
        return (
          <div key={idx} className={`h-3 ${wClass} rounded bg-gray-800/60 relative overflow-hidden`}>
            <div className="absolute inset-0 shimmer-anim"></div>
          </div>
        );
      })}
    </div>
  );
};
