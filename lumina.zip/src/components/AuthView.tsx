import React, { useState } from "react";
import { useAuth } from "../context/AuthContext";
import { Play, Loader2, AlertCircle, ShieldAlert } from "lucide-react";

export const AuthView: React.FC = () => {
  const { login, signup } = useAuth();
  
  const [isSignUp, setIsSignUp] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !password.trim()) {
      setError("Please complete all credentials fields.");
      return;
    }
    if (password.length < 6) {
      setError("Password must be at least 6 characters.");
      return;
    }

    setLoading(true);
    setError("");

    try {
      if (isSignUp) {
        await signup(email.trim());
      } else {
        await login(email.trim(), "email");
      }
    } catch (err: any) {
      setError(err?.message || "Authentication attempt failed. Try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleOAuthLogin = async (provider: "google" | "github") => {
    setLoading(true);
    setError("");
    try {
      // Simulate OAuth login credentials retrieval
      const simulatedEmail = provider === "google" 
        ? "google.user@gmail.com" 
        : "github.developer@github.com";
      await login(simulatedEmail, provider);
    } catch (err: any) {
      setError(`Failed to sign in via ${provider.toUpperCase()}`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#0B0E11] px-4 py-12 relative overflow-hidden font-sans select-none">
      
      {/* Background Gradient Orbs */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden z-0">
        <div className="absolute top-[20%] left-[20%] w-[50%] h-[50%] bg-[#ff073a]/5 rounded-full blur-[150px]" />
        <div className="absolute bottom-[20%] right-[20%] w-[50%] h-[50%] bg-[#bf00ff]/5 rounded-full blur-[150px]" />
      </div>

      <div className="w-full max-w-md bg-white/5 border border-white/10 p-8 rounded-2xl backdrop-blur-3xl z-10 shadow-2xl relative text-center">
        
        {/* Logo Icon */}
        <div className="flex items-center justify-center gap-2 mb-8">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#ff073a] to-[#bf00ff] shadow-[0_0_15px_rgba(255,7,58,0.5)] flex items-center justify-center">
            <Play className="w-5 h-5 fill-white text-white ml-0.5" />
          </div>
          <span className="text-xl font-black tracking-tight font-sans uppercase text-white">
            LUMINA
          </span>
        </div>

        <h2 className="text-xl font-black text-white uppercase tracking-wider mb-2">
          {isSignUp ? "Create Account" : "Welcome Back"}
        </h2>
        <p className="text-xs text-white/50 mb-6">
          {isSignUp 
            ? "Sign up for Lumina to enjoy safe high-speed streams." 
            : "Sign in to access your custom profile configurations."}
        </p>

        {error && (
          <div className="mb-4 p-3 bg-red-500/10 border border-red-500/30 rounded-xl flex items-center gap-2 text-[11px] font-mono text-red-500 text-left">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="flex flex-col gap-4 text-left">
          
          <div>
            <label className="text-[10px] font-mono font-bold tracking-wider text-white/65 uppercase block mb-1.5">
              Email Address
            </label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="e.g. member@lumina.tv"
              className="w-full px-4 py-2.5 bg-black/40 border border-white/10 focus:border-[#00f0ff]/50 focus:glow-cyan rounded-xl text-xs font-mono text-white placeholder-gray-600 outline-0 transition-all font-sans"
              required
              disabled={loading}
            />
          </div>

          <div>
            <label className="text-[10px] font-mono font-bold tracking-wider text-white/65 uppercase block mb-1.5">
              Password
            </label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              className="w-full px-4 py-2.5 bg-black/40 border border-white/10 focus:border-[#00f0ff]/50 focus:glow-cyan rounded-xl text-xs font-mono text-white placeholder-gray-600 outline-0 transition-all font-sans"
              required
              disabled={loading}
            />
          </div>

          <button
            type="submit"
            className="w-full py-3 bg-[#ff073a] hover:bg-red-650 text-white rounded-xl text-xs font-bold font-mono uppercase tracking-wider transition-all duration-300 shadow-[0_4px_15px_rgba(255,7,58,0.3)] hover:scale-[1.01] active:scale-95 flex items-center justify-center gap-2 cursor-pointer mt-2"
            disabled={loading}
          >
            {loading ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : isSignUp ? (
              "Sign Up"
            ) : (
              "Sign In"
            )}
          </button>
        </form>

        {/* Separator */}
        <div className="flex items-center gap-3 my-6">
          <div className="flex-1 h-[1px] bg-white/10" />
          <span className="text-[10px] font-mono text-white/30 uppercase">Or Continue With</span>
          <div className="flex-1 h-[1px] bg-white/10" />
        </div>

        {/* Simulated OAuth Providers */}
        <div className="grid grid-cols-2 gap-3">
          <button
            onClick={() => handleOAuthLogin("google")}
            disabled={loading}
            className="flex items-center justify-center gap-2 py-2.5 bg-white/5 border border-white/10 hover:border-white/20 hover:bg-white/10 rounded-xl text-xs font-mono tracking-wide text-white transition-all cursor-pointer active:scale-95"
          >
            <svg className="w-4 h-4" viewBox="0 0 24 24">
              <path
                fill="currentColor"
                d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
              />
              <path
                fill="currentColor"
                d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
              />
              <path
                fill="currentColor"
                d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
              />
              <path
                fill="currentColor"
                d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
              />
            </svg>
            Google
          </button>

          <button
            onClick={() => handleOAuthLogin("github")}
            disabled={loading}
            className="flex items-center justify-center gap-2 py-2.5 bg-white/5 border border-white/10 hover:border-white/20 hover:bg-white/10 rounded-xl text-xs font-mono tracking-wide text-white transition-all cursor-pointer active:scale-95"
          >
            <svg className="w-4 h-4" viewBox="0 0 24 24" fill="currentColor">
              <path fillRule="evenodd" clipRule="evenodd" d="M12 2C6.477 2 2 6.477 2 12c0 4.42 2.865 8.17 6.839 9.49.5.092.682-.217.682-.482 0-.237-.008-.866-.013-1.7-2.782.603-3.369-1.34-3.369-1.34-.454-1.156-1.11-1.464-1.11-1.464-.908-.62.069-.608.069-.608 1.003.07 1.531 1.03 1.531 1.03.892 1.529 2.341 1.087 2.91.832.092-.647.35-1.088.636-1.338-2.22-.253-4.555-1.11-4.555-4.943 0-1.091.39-1.984 1.029-2.683-.103-.253-.446-1.27.098-2.647 0 0 .84-.269 2.75 1.025A9.564 9.564 0 0112 6.844c.85.004 1.705.115 2.504.337 1.909-1.294 2.747-1.025 2.747-1.025.546 1.377.203 2.394.1 2.647.64.699 1.028 1.592 1.028 2.683 0 3.842-2.339 4.687-4.566 4.935.359.309.678.919.678 1.852 0 1.336-.012 2.415-.012 2.743 0 .267.18.579.688.481C19.137 20.167 22 16.418 22 12c0-5.523-4.477-10-10-10z" />
            </svg>
            GitHub
          </button>
        </div>

        {/* Footer Toggle text */}
        <p className="mt-8 text-xs text-white/40">
          {isSignUp ? "Already registered at Lumina?" : "New to the Lumina stream experience?"}{" "}
          <button
            onClick={() => setIsSignUp(!isSignUp)}
            className="text-[#00f0ff] font-bold hover:underline ml-1 cursor-pointer bg-transparent border-0 outline-0"
          >
            {isSignUp ? "Sign In Instead" : "Create Profile Now"}
          </button>
        </p>

        {/* Extra Privacy Info */}
        <div className="flex items-center justify-center gap-1.5 mt-8 pt-4 border-t border-white/5 text-[9px] font-mono text-white/30 uppercase">
          <ShieldAlert className="w-3.5 h-3.5 text-[#ff073a]" />
          <span>Secure Browser Endpoint Verification Active</span>
        </div>

      </div>
    </div>
  );
};
export default AuthView;
