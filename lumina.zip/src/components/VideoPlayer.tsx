import React, { useState, useEffect, useRef } from "react";
import { 
  Play, 
  Pause, 
  RotateCcw, 
  Maximize, 
  Minimize, 
  Volume2, 
  VolumeX, 
  Settings as Gear, 
  Server, 
  Loader2, 
  AlertTriangle,
  ChevronLeft,
  ChevronRight,
  Rewind,
  FastForward,
  Layers,
  Tv as TVIcon,
  CheckCircle
} from "lucide-react";
import { MediaItem, MediaDetails } from "../types";
import { useHistory } from "../context/HistoryContext";
import { useAppStore } from "../lib/store";
import { formatTime, cn } from "../lib/utils";

interface VideoPlayerProps {
  media: MediaItem;
  details?: MediaDetails | null;
}

interface EmbedProvider {
  name: string;
  url: string;
}

export const VideoPlayer: React.FC<VideoPlayerProps> = ({ media, details }) => {
  const { updateHistory, getHistoryItem } = useHistory();
  const { playbackQuality, setPlaybackQuality } = useAppStore();

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [providers, setProviders] = useState<EmbedProvider[]>([]);
  const [selectedProviderIdx, setSelectedProviderIdx] = useState(0);
  const [iframeUrl, setIframeUrl] = useState("");

  // Episode Selection States (For TV Shows)
  const isTv = media.media_type === "tv";
  const numSeasons = details?.number_of_seasons || 1;
  const numEpisodes = details?.number_of_episodes || 10;
  
  const [currentSeason, setCurrentSeason] = useState(1);
  const [currentEpisode, setCurrentEpisode] = useState(1);

  // Simulated Visual Controls State
  const [isPlaying, setIsPlaying] = useState(true);
  const [duration, setDuration] = useState(6000); // default 1h 40m
  const [currentTime, setCurrentTime] = useState(0);
  const [volume, setVolume] = useState(0.85);
  const [isMuted, setIsMuted] = useState(false);
  const [showControls, setShowControls] = useState(true);
  const [isFullScreen, setIsFullScreen] = useState(false);

  // Menus toggling
  const [showServerMenu, setShowServerMenu] = useState(false);
  const [showQualityMenu, setShowQualityMenu] = useState(false);
  const [showSeasonDropdown, setShowSeasonDropdown] = useState(false);

  const playerWrapperRef = useRef<HTMLDivElement>(null);
  const controlsTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const playbackIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const saveCounterRef = useRef(0);

  const title = media.title || media.name || media.original_title || "Lumina Stream";

  // 1. Fetch backend embed sources when Media, Season, or Episode changes
  useEffect(() => {
    const fetchEmbedSources = async () => {
      setLoading(true);
      setError(false);
      try {
        const queryParams = new URLSearchParams({
          id: String(media.id),
          type: media.media_type,
          season: String(currentSeason),
          episode: String(currentEpisode)
        });

        const res = await fetch(`/api/embed?${queryParams.toString()}`);
        if (!res.ok) {
          throw new Error("Failed to load providers from proxy");
        }
        
        const data = await res.json();
        if (data.providers && data.providers.length > 0) {
          setProviders(data.providers);
          // Auto select first provider or preserve Index if valid
          const indexToSet = selectedProviderIdx < data.providers.length ? selectedProviderIdx : 0;
          setSelectedProviderIdx(indexToSet);
          setIframeUrl(data.providers[indexToSet].url);
        } else {
          throw new Error("Empty providers array");
        }
      } catch (err) {
        console.error("Failed to load secure embed proxy sources:", err);
        setError(true);
      } finally {
        setLoading(false);
      }
    };

    fetchEmbedSources();

    // Recover timeline historical state for metadata
    const progressId = isTv ? `${media.id}_S${currentSeason}_E${currentEpisode}` : media.id;
    // We can hold standard id or keys
    const saved = getHistoryItem(media.id);
    if (saved) {
      setCurrentTime(saved.currentTime);
      setDuration(saved.duration > 0 ? saved.duration : 5400);
    } else {
      setCurrentTime(0);
      setDuration(media.media_type === 'movie' ? 6200 : 2800);
    }
    // Reset save timer counter
    saveCounterRef.current = 0;
  }, [media.id, media.media_type, currentSeason, currentEpisode]);

  // Handle provider manual swaps
  const handleProviderSwap = (idx: number) => {
    if (providers[idx]) {
      setSelectedProviderIdx(idx);
      setIframeUrl(providers[idx].url);
      setLoading(true);
    }
  };

  // 2. Continuous Playback simulation (No side-effects inside state updater)
  useEffect(() => {
    if (playbackIntervalRef.current) clearInterval(playbackIntervalRef.current);

    if (isPlaying && !loading && !error) {
      playbackIntervalRef.current = setInterval(() => {
        setCurrentTime((prev) => {
          const next = prev + 1;
          if (next >= duration) {
            if (playbackIntervalRef.current) clearInterval(playbackIntervalRef.current);
            return duration;
          }
          return next;
        });
      }, 1000);
    }

    return () => {
      if (playbackIntervalRef.current) clearInterval(playbackIntervalRef.current);
    };
  }, [isPlaying, loading, error, duration]);

  // 2b. Progress and History Saving (Listening to time changes safely in useEffect)
  useEffect(() => {
    if (currentTime > 0) {
      if (currentTime >= duration) {
        setIsPlaying(false);
        updateHistory(media, duration, duration);
      } else {
        saveCounterRef.current += 1;
        if (saveCounterRef.current >= 15) {
          updateHistory(media, currentTime, duration);
          saveCounterRef.current = 0;
        }
      }
    }
  }, [currentTime, duration, media, updateHistory]);

  // 3. User seeking capabilities
  const handleSeek = (amount: number) => {
    const target = Math.min(duration, Math.max(0, currentTime + amount));
    setCurrentTime(target);
    updateHistory(media, target, duration);
    saveCounterRef.current = 0; // reset save timer threshold
  };

  // Scrubber adjustment
  const handleScrubChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const targetVal = parseFloat(e.target.value);
    setCurrentTime(targetVal);
    updateHistory(media, targetVal, duration);
    saveCounterRef.current = 0;
  };

  // Controls Auto-hide
  const triggerShowControls = () => {
    setShowControls(true);
    if (controlsTimeoutRef.current) clearTimeout(controlsTimeoutRef.current);
    
    controlsTimeoutRef.current = setTimeout(() => {
      if (isPlaying) {
        setShowControls(false);
        setShowServerMenu(false);
        setShowQualityMenu(false);
      }
    }, 3000);
  };

  useEffect(() => {
    triggerShowControls();
    return () => {
      if (controlsTimeoutRef.current) clearTimeout(controlsTimeoutRef.current);
    };
  }, [isPlaying]);

  // Fullscreen toggle
  const handleFullscreenToggle = () => {
    if (!playerWrapperRef.current) return;
    if (!document.fullscreenElement) {
      playerWrapperRef.current.requestFullscreen()
        .then(() => setIsFullScreen(true))
        .catch((err) => console.error("Could not trigger player fullscreen", err));
    } else {
      document.exitFullscreen();
      setIsFullScreen(false);
    }
  };

  useEffect(() => {
    const handleFsChange = () => {
      setIsFullScreen(!!document.fullscreenElement);
    };
    document.addEventListener("fullscreenchange", handleFsChange);
    return () => document.removeEventListener("fullscreenchange", handleFsChange);
  }, []);

  const handleRetry = () => {
    setLoading(true);
    setError(false);
    const iframe = document.getElementById("lumina-active-iframe") as HTMLIFrameElement;
    if (iframe) {
      iframe.src = iframeUrl;
    }
  };

  const activeProviderName = providers[selectedProviderIdx]?.name || "Primary Server";

  return (
    <div className="flex flex-col gap-5 w-full">
      
      {/* 1. Playback View Stage */}
      <div 
        ref={playerWrapperRef}
        id="lumina-integrated-player"
        onMouseMove={triggerShowControls}
        onMouseLeave={() => isPlaying && setShowControls(false)}
        className="relative w-full aspect-video rounded-2xl border border-white/5 bg-black overflow-hidden select-none group/player shadow-2xl"
      >
        {/* Core iframe stream */}
        {iframeUrl && !error && (
          <iframe
            id="lumina-active-iframe"
            src={iframeUrl}
            title={title}
            referrerPolicy="no-referrer"
            allowFullScreen
            allow="autoplay; encrypted-media; fullscreen"
            onLoad={() => setLoading(false)}
            onError={() => setError(true)}
            className={cn(
              "w-full h-full border-0 transition-opacity duration-300",
              loading ? "opacity-0" : "opacity-100"
            )}
          />
        )}

        {/* Loading overlay panel */}
        {loading && (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-[#0B0E11]/90 gap-3 z-30">
            <Loader2 className="w-10 h-10 text-[#ff073a] animate-spin glow-red" />
            <div className="text-center">
              <h3 className="text-sm font-bold font-mono text-gray-100 tracking-wider uppercase">Connecting Embed Nodes...</h3>
              <p className="text-[10px] text-gray-500 font-mono mt-1">Acquiring verified signatures for {activeProviderName}</p>
            </div>
          </div>
        )}

        {/* Error panel state */}
        {error && (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-gray-950/95 gap-4 z-30 p-6 text-center">
            <AlertTriangle className="w-12 h-12 text-[#ff073a] drop-shadow glow-red" />
            <div>
              <h3 className="text-sm font-bold font-mono text-white uppercase tracking-wider">Stream Connection Failed</h3>
              <p className="text-xs text-gray-400 mt-1 max-w-sm mx-auto font-sans">
                Could not establish bridge links via proxy servers. Switch embed providers below or retry connection.
              </p>
            </div>
            <div className="flex gap-3">
              <button
                onClick={handleRetry}
                className="px-4 py-2 text-xs font-mono font-bold tracking-wider rounded-lg bg-[#ff073a] text-white hover:bg-red-650 transition-all cursor-pointer"
              >
                Retry Link
              </button>
            </div>
          </div>
        )}

        {/* SIMULATED CONTROLS LAYER */}
        <div 
          className={cn(
            "absolute inset-0 bg-gradient-to-t from-black/95 via-transparent to-black/60 z-20 flex flex-col justify-between transition-opacity duration-400 pointer-events-none p-4 md:p-6",
            showControls ? "opacity-100 animate-fade-in" : "opacity-0"
          )}
        >
          {/* Top Info HUD */}
          <div className="flex items-start justify-between w-full pointer-events-auto">
            <div className="flex flex-col gap-1 text-left max-w-[70%]">
              <span className="text-[10px] font-mono text-[#ff073a] font-bold uppercase tracking-widest flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-[#ff073a] animate-pulse" />
                {isTv ? `EPISODIC: Season ${currentSeason}, Episode ${currentEpisode}` : "Movie Feature"}
              </span>
              <h2 className="text-md md:text-lg font-bold text-white uppercase tracking-wide truncate">
                {title}
              </h2>
            </div>

            <div className="flex items-center gap-2">
              <span className="hidden md:inline px-2.5 py-1 rounded-md bg-white/5 border border-white/10 text-[10px] font-mono tracking-wider font-bold text-gray-300 uppercase">
                Source: {activeProviderName}
              </span>
              <span className="hidden md:inline px-2.5 py-1 rounded-md bg-white/5 border border-white/10 text-[10px] font-mono tracking-wider font-bold text-gray-300 uppercase">
                Resolution: {playbackQuality.toUpperCase()}
              </span>
            </div>
          </div>

          {/* Bottom HUD HUD Panel */}
          <div className="flex flex-col gap-3.5 w-full pointer-events-auto">
            
            {/* Timeline slider Scrubber */}
            <div className="flex items-center gap-3 w-full group/scrub">
              <span className="text-[10px] text-gray-400 font-mono tracking-wider min-w-[36px]">
                {formatTime(currentTime)}
              </span>
              
              <input
                type="range"
                min={0}
                max={duration}
                value={currentTime}
                onChange={handleScrubChange}
                className="flex-1 h-1.5 rounded-full bg-white/15 outline-0 accent-[#ff073a] cursor-pointer hover:h-2 transition-all"
              />

              <span className="text-[10px] text-gray-400 font-mono tracking-wider min-w-[36px]">
                {formatTime(duration)}
              </span>
            </div>

            {/* Micro Controls Center Row */}
            <div className="flex items-center justify-between w-full">
              <div className="flex items-center gap-3 md:gap-4 select-none">
                
                {/* 10s Rewind Backward */}
                <button
                  onClick={() => handleSeek(-10)}
                  className="p-1.5 rounded-full hover:bg-white/10 text-gray-300 hover:text-white transition-all cursor-pointer active:scale-95"
                  title="Rewind 10 Seconds"
                >
                  <Rewind className="w-4 h-4 fill-current" />
                </button>

                {/* Play / Pause Toggle */}
                <button
                  onClick={() => setIsPlaying(!isPlaying)}
                  className="p-1.5 rounded-full hover:bg-white/15 text-white hover:text-[#ff073a] transition-all cursor-pointer active:scale-95"
                  title={isPlaying ? "Pause Viewport" : "Resume Viewport"}
                >
                  {isPlaying ? (
                    <Pause className="w-5 h-5 fill-current" />
                  ) : (
                    <Play className="w-5 h-5 fill-current ml-0.5" />
                  )}
                </button>

                {/* 10s Skip Forward */}
                <button
                  onClick={() => handleSeek(10)}
                  className="p-1.5 rounded-full hover:bg-white/10 text-gray-300 hover:text-white transition-all cursor-pointer active:scale-95"
                  title="Forward 10 Seconds"
                >
                  <FastForward className="w-4 h-4 fill-current" />
                </button>

                {/* Reset Slider */}
                <button
                  onClick={() => {
                    setCurrentTime(0);
                    setIsPlaying(true);
                    updateHistory(media, 0, duration);
                    saveCounterRef.current = 0;
                  }}
                  className="p-1.5 rounded-full hover:bg-white/15 text-gray-350 hover:text-white transition-all cursor-pointer"
                  title="Restart Movie"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                </button>

                <div className="h-4 w-[1px] bg-white/10" />

                {/* Simulated Volume */}
                <div className="flex items-center gap-1.5 group/volume">
                  <button
                    onClick={() => setIsMuted(!isMuted)}
                    className="p-1.5 rounded-full hover:bg-white/15 text-gray-300 hover:text-white transition-all cursor-pointer"
                  >
                    {isMuted || volume === 0 ? (
                      <VolumeX className="w-4 h-4 text-[#ff073a]" />
                    ) : (
                      <Volume2 className="w-4 h-4" />
                    )}
                  </button>
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.05"
                    value={isMuted ? 0 : volume}
                    onChange={(e) => {
                      const nextV = parseFloat(e.target.value);
                      setVolume(nextV);
                      setIsMuted(nextV === 0);
                    }}
                    className="w-16 h-1 rounded-full bg-white/15 accent-white cursor-pointer opacity-0 group-hover/volume:opacity-100 group-focus-within/volume:opacity-100 transition-opacity"
                  />
                </div>
              </div>

              {/* Server Nodes & Resolution Select Dropdowns */}
              <div className="flex items-center gap-2 relative">
                
                {/* Provider Manual Choice Selector */}
                <div className="relative">
                  <button
                    onClick={() => {
                      setShowServerMenu(!showServerMenu);
                      setShowQualityMenu(false);
                    }}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-black/60 border border-white/5 hover:border-white/10 text-xs font-mono font-bold tracking-wide text-gray-305 hover:text-white transition-all cursor-pointer"
                  >
                    <Server className="w-3.5 h-3.5 text-[#00f0ff]" />
                    <span>Provider</span>
                  </button>

                  {showServerMenu && (
                    <div className="absolute bottom-10 right-0 w-44 rounded-xl glass border border-white/10 shadow-2xl p-1.5 z-55 flex flex-col gap-1 pointer-events-auto">
                      <span className="text-[9px] font-mono text-gray-500 tracking-wider uppercase px-2 py-0.5 mb-1 text-left block border-b border-white/5">Embed Nodes</span>
                      {providers.map((prov, idx) => (
                        <button
                          key={prov.name}
                          type="button"
                          onClick={() => {
                            handleProviderSwap(idx);
                            setShowServerMenu(false);
                          }}
                          className={cn(
                            "w-full text-left px-2 py-1 text-[11px] font-mono rounded cursor-pointer transition-colors flex items-center justify-between",
                            selectedProviderIdx === idx
                              ? "bg-red-500/20 text-[#ff073a] font-bold"
                              : "text-gray-300 hover:bg-white/5 hover:text-white"
                          )}
                        >
                          <span>{prov.name}</span>
                          {selectedProviderIdx === idx && (
                            <CheckCircle className="w-3 h-3 text-[#ff073a] stroke-[2.5]" />
                          )}
                        </button>
                      ))}
                    </div>
                  )}
                </div>

                {/* Resolution Selector Dropdown */}
                <div className="relative">
                  <button
                    onClick={() => {
                      setShowQualityMenu(!showQualityMenu);
                      setShowServerMenu(false);
                    }}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-black/60 border border-white/5 hover:border-white/10 text-xs font-mono font-bold tracking-wide text-gray-305 hover:text-white transition-all cursor-pointer"
                  >
                    <Layers className="w-3.5 h-3.5 text-[#bf00ff]" />
                    <span>{playbackQuality.toUpperCase()}</span>
                  </button>

                  {showQualityMenu && (
                    <div className="absolute bottom-10 right-0 w-32 rounded-xl glass border border-white/10 shadow-2xl p-1.5 z-55 flex flex-col gap-1 pointer-events-auto">
                      <span className="text-[9px] font-mono text-gray-500 tracking-wider uppercase px-2 py-0.5 mb-1 text-left block border-b border-white/5">Quality Index</span>
                      {[
                        { val: 'auto', name: 'Automatic' },
                        { val: '1080p', name: '1080p Ultra' },
                        { val: '720p', name: '720p Sharp' }
                      ].map((ql) => (
                        <button
                          key={ql.val}
                          type="button"
                          onClick={() => {
                            setPlaybackQuality(ql.val);
                            setShowQualityMenu(false);
                          }}
                          className={cn(
                            "w-full text-left px-2 py-1 text-xs font-mono rounded cursor-pointer transition-colors",
                            playbackQuality === ql.val 
                              ? "bg-red-500/20 text-[#ff073a] font-bold" 
                              : "text-gray-300 hover:bg-white/5 hover:text-white"
                          )}
                        >
                          {ql.name}
                        </button>
                      ))}
                    </div>
                  )}
                </div>

                {/* Fullscreen toggle icon */}
                <button
                  onClick={handleFullscreenToggle}
                  className="p-1.5 rounded-full hover:bg-white/15 text-gray-300 hover:text-white transition-all cursor-pointer"
                  title="Fullscreen"
                >
                  {isFullScreen ? (
                    <Minimize className="w-4 h-4" />
                  ) : (
                    <Maximize className="w-4 h-4" />
                  )}
                </button>
              </div>
            </div>

          </div>
        </div>
      </div>

      {/* ================= EPISODE & SEASON PICKER (For TV Shows Only) ================= */}
      {isTv && (
        <div className="flex flex-col gap-3 bg-white/2 border border-white/5 rounded-2xl p-5 md:p-6 text-left animate-fade-in">
          
          <div className="flex flex-wrap items-center justify-between gap-4 border-b border-white/5 pb-3">
            <div className="flex items-center gap-2">
              <TVIcon className="w-5 h-5 text-[#ff073a]" />
              <h3 className="text-sm font-bold font-mono text-white uppercase tracking-wider">
                Episode Guide
              </h3>
            </div>

            {/* Season Selector Dropdown */}
            <div className="relative">
              <label className="text-[10px] text-gray-500 font-mono tracking-wider uppercase mr-2.5">Season:</label>
              <select
                value={currentSeason}
                onChange={(e) => {
                  setCurrentSeason(Number(e.target.value));
                  setCurrentEpisode(1); // auto reset episode to 1
                }}
                className="bg-black/40 border border-white/10 rounded-lg px-2.5 py-1.5 text-xs font-mono font-bold tracking-wide outline-none text-white cursor-pointer focus:border-[#00f0ff]"
              >
                {Array.from({ length: numSeasons }, (_, idx) => (
                  <option key={idx + 1} value={idx + 1} className="bg-[#0B0E11] text-white">
                    Season {idx + 1}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Grid list representing episodes in active season */}
          <div className="flex flex-wrap gap-2 pt-1.5 max-h-40 overflow-y-auto scrollbar-hide pr-1">
            {Array.from({ length: Math.ceil(numEpisodes / numSeasons) }, (_, idx) => {
              const epNum = idx + 1;
              const isActive = currentEpisode === epNum;
              
              return (
                <button
                  key={epNum}
                  onClick={() => setCurrentEpisode(epNum)}
                  className={cn(
                    "min-w-20 px-3 py-2 flex-1 md:flex-initial rounded-xl border text-center font-mono cursor-pointer transition-all duration-300 select-none",
                    isActive
                      ? "bg-gradient-to-r from-[#ff073a]/20 to-[#bf00ff]/10 border-[#ff073a] text-white font-black shadow-[0_0_12px_rgba(255,7,58,0.2)]"
                      : "bg-white/2 border-white/5 text-gray-400 hover:text-white hover:bg-white/5 hover:border-white/10"
                  )}
                >
                  <span className="text-[10px] block text-gray-500 uppercase leading-none mb-1">Episode</span>
                  <span className="text-xs leading-none">{epNum}</span>
                </button>
              );
            })}
          </div>

        </div>
      )}

    </div>
  );
};
export default VideoPlayer;
