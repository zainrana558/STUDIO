import React, { useState, useEffect, useRef } from "react";
import { 
  Home, 
  Flame, 
  Film, 
  Tv, 
  Bookmark, 
  History as HistoryIcon, 
  Settings as SettingsIcon,
  Search,
  Sparkles,
  Share2,
  Check
} from "lucide-react";
import { useAppStore, ViewType } from "../lib/store";
import { cn } from "../lib/utils";
import { useAuth, AVATAR_PRESETS } from "../context/AuthContext";
import { useAestheticTheme } from "../context/ThemeContext";
import { Logo } from "./Logo";
import { motion, useMotionValue, useSpring } from "motion/react";

// --- CUSTOM CURSOR FOLLOWER & MAGNETIC SNAP COMPONENT ---
interface MagneticTargetProps {
  children: React.ReactNode;
  radius?: number;
  className?: string;
}

export const MagneticTarget: React.FC<MagneticTargetProps> = ({ children, radius = 40, className }) => {
  const ref = useRef<HTMLDivElement>(null);
  const [position, setPosition] = useState({ x: 0, y: 0 });

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!ref.current) return;
    const { clientX, clientY } = e;
    const { left, top, width, height } = ref.current.getBoundingClientRect();
    const centerX = left + width / 2;
    const centerY = top + height / 2;
    
    const distanceX = clientX - centerX;
    const distanceY = clientY - centerY;
    const distance = Math.sqrt(distanceX * distanceX + distanceY * distanceY);

    if (distance < radius) {
      // Pull proportion represents a spring snap pull constant
      const pull = 0.42; 
      setPosition({ x: distanceX * pull, y: distanceY * pull });
    } else {
      setPosition({ x: 0, y: 0 });
    }
  };

  const handleMouseLeave = () => {
    setPosition({ x: 0, y: 0 });
  };

  return (
    <motion.div
      ref={ref}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      animate={{ x: position.x, y: position.y }}
      transition={{ type: "spring", stiffness: 220, damping: 14 }}
      className={className}
    >
      {children}
    </motion.div>
  );
};

export const Navbar: React.FC = () => {
  const { activeView, setView, searchQuery, setSearchQuery, selectedMedia } = useAppStore();
  const { currentProfile, clearActiveProfile } = useAuth();
  const { config } = useAestheticTheme();
  
  const [copied, setCopied] = useState(false);

  const handleShare = async () => {
    const shareUrl = typeof window !== "undefined" ? window.location.href : "";
    let text = "Check out Lumina Cinema!";
    if (selectedMedia) {
      text = `Check out "${selectedMedia.title || selectedMedia.name}" on Lumina Cinema!`;
    }
    const shareData = {
      title: "Lumina Cinema",
      text,
      url: shareUrl,
    };

    if (
      typeof navigator !== "undefined" &&
      navigator.share &&
      navigator.canShare &&
      navigator.canShare(shareData)
    ) {
      try {
        await navigator.share(shareData);
        return;
      } catch (err) {
        console.log("Web Share API rejected, falling back to copy", err);
      }
    }

    if (typeof navigator !== "undefined" && navigator.clipboard) {
      try {
        await navigator.clipboard.writeText(shareUrl);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
      } catch (err) {
        console.error("Failed to copy link:", err);
      }
    }
  };
  
  const activeAvatar = AVATAR_PRESETS[currentProfile?.avatarIdx ?? 0];
  
  // Custom Cursor Coordinate Tracker Springs
  const cursorX = useMotionValue(-100);
  const cursorY = useMotionValue(-100);
  
  const springConfig = { stiffness: 450, damping: 28 };
  const cursorSpringX = useSpring(cursorX, springConfig);
  const cursorSpringY = useSpring(cursorY, springConfig);

  const [mouseActive, setMouseActive] = useState(false);

  useEffect(() => {
    const updateMouseCoords = (e: MouseEvent) => {
      cursorX.set(e.clientX - 10);
      cursorY.set(e.clientY - 10);
      setMouseActive(true);
    };

    const handleMouseLeaveWindow = () => {
      setMouseActive(false);
    };

    window.addEventListener("mousemove", updateMouseCoords);
    document.addEventListener("mouseleave", handleMouseLeaveWindow);

    return () => {
      window.removeEventListener("mousemove", updateMouseCoords);
      document.removeEventListener("mouseleave", handleMouseLeaveWindow);
    };
  }, [cursorX, cursorY]);

  const navItems = [
    { view: "home" as ViewType, label: "Home", icon: Home },
    { view: "trending" as ViewType, label: "Trending", icon: Flame },
    { view: "movies" as ViewType, label: "Movies", icon: Film },
    { view: "tv" as ViewType, label: "TV Shows", icon: Tv },
    { view: "watchlist" as ViewType, label: "Watchlist", icon: Bookmark },
    { view: "history" as ViewType, label: "History", icon: HistoryIcon },
  ];

  const handleSearchFocus = () => {
    if (activeView !== "home") {
      setView("home");
    }
  };

  const handleSearchChange = (val: string) => {
    setSearchQuery(val);
    if (activeView !== "home") {
      setView("home");
    }
  };

  return (
    <>
      {/* 1. Cinematic Liquid Cursor Tracker Glow */}
      {mouseActive && (
        <motion.div
          id="lumina-custom-cursor-glow"
          className="pointer-events-none fixed top-0 left-0 w-5 h-5 rounded-full z-100 hidden lg:block mix-blend-screen overflow-visible"
          style={{
            x: cursorSpringX,
            y: cursorSpringY,
            backgroundColor: config.accentColor,
            boxShadow: `0 0 18px ${config.accentColor}, 0 0 36px ${config.accentColor}`,
          }}
          transition={{ ease: "easeOut" }}
        />
      )}

      {/* 2. Top-Fixed Glassmorphic Bar */}
      <nav 
        id="lumina-cinema-navbar"
        className="fixed top-0 left-0 right-0 h-16 bg-[#0a0d11]/80 backdrop-blur-2xl border-b border-white/5 z-45 flex items-center justify-between px-6 select-none transition-colors duration-500"
        style={{ borderBottomColor: `${config.accentColor}1e` }}
      >
        {/* Compact Dynamic Logo (with magnetic attraction!) */}
        <div className="flex items-center gap-3">
          <MagneticTarget radius={40}>
            <div 
              onClick={() => setView("home")}
              className="cursor-pointer font-bold leading-none pr-1"
            >
              <Logo size="md" />
            </div>
          </MagneticTarget>

          {/* Integrated Navbar Share Trigger */}
          <MagneticTarget radius={30}>
            <button
              type="button"
              onClick={handleShare}
              className="flex items-center justify-center p-1.5 rounded-lg bg-white/5 border border-white/5 hover:border-rose-500/20 hover:bg-rose-500/5 transition-all text-gray-400 hover:text-white cursor-pointer relative"
              title="Share Page Link"
            >
              {copied ? (
                <Check className="w-3.5 h-3.5 text-emerald-400 stroke-[2.5]" />
              ) : (
                <Share2 className="w-3.5 h-3.5 text-rose-500" />
              )}
            </button>
          </MagneticTarget>
        </div>

        {/* Center Links (Sleek Horizontal Bar) */}
        <div className="hidden md:flex items-center gap-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeView === item.view;

            return (
              <MagneticTarget key={item.view} radius={35}>
                <button
                  type="button"
                  onClick={() => setView(item.view)}
                  className={cn(
                    "relative flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-mono font-bold tracking-wide transition-all uppercase",
                    isActive 
                      ? "text-white" 
                      : "text-white/40 hover:text-white/80"
                  )}
                  style={isActive ? {
                    color: config.accentColor,
                    backgroundColor: `${config.accentColor}12`,
                    border: `1px solid ${config.accentColor}25`
                  } : undefined}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{item.label}</span>
                </button>
              </MagneticTarget>
            );
          })}
        </div>

        {/* Action Widgets (Search, Settings & Profile Switches) */}
        <div className="flex items-center gap-3.5">
          {/* Prominent Search Bar */}
          <div className="relative w-40 sm:w-52 md:w-60 lg:w-72">
            <span className="absolute inset-y-0 left-0 flex items-center pl-3.5 pointer-events-none text-gray-500">
              <Search className="w-4 h-4" />
            </span>
            <input
              id="navbar-search-input"
              type="text"
              placeholder="Search films, series, anime..."
              value={searchQuery}
              onFocus={handleSearchFocus}
              onChange={(e) => handleSearchChange(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 bg-white/5 border border-white/10 hover:border-white/20 focus:border-[#00f0ff]/50 focus:glow-cyan rounded-full text-xs font-medium text-white placeholder-gray-500 outline-none backdrop-blur-md transition-all font-sans"
            />
          </div>

          <MagneticTarget radius={35}>
            <button
              type="button"
              onClick={() => setView("settings")}
              className={cn(
                "p-2 rounded-xl border transition-all text-gray-400 hover:text-white cursor-pointer",
                activeView === "settings" ? "border-rose-500/20 bg-rose-500/5 text-rose-400" : "border-transparent"
              )}
            >
              <SettingsIcon className="w-4 h-4" />
            </button>
          </MagneticTarget>

          <div className="h-5 w-[1px] bg-white/10 hidden sm:block" />

          {/* Magnetic Profile trigger */}
          <MagneticTarget radius={30}>
            <div 
              onClick={clearActiveProfile}
              className="w-[30px] h-[30px] rounded-lg bg-white/5 border border-white/10 p-0.5 cursor-pointer hover:scale-105 transition-all text-white font-mono text-[9px] uppercase font-black shrink-0"
              title={`Active profile: ${currentProfile?.name}. Click to switch profiles.`}
            >
              <div className={`w-full h-full rounded bg-gradient-to-tr ${activeAvatar?.bgColor} flex items-center justify-center shadow`}>
                {currentProfile?.name.charAt(0)}
              </div>
            </div>
          </MagneticTarget>
        </div>
      </nav>
    </>
  );
};
export default Navbar;
