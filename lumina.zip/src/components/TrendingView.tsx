import React, { useState, useEffect } from "react";
import { Flame, Clock, HelpCircle, AlertOctagon } from "lucide-react";
import { MediaItem } from "../types";
import { tmdbClient } from "../lib/tmdb/client";
import { useAppStore } from "../lib/store";
import { MediaCard } from "./MediaCard";
import { SkeletonRow } from "./SkeletonLoader";
import { cn } from "../lib/utils";

export const TrendingView: React.FC = () => {
  const { selectMedia } = useAppStore();
  
  const [timeframe, setTimeframe] = useState<'day' | 'week'>('week');
  const [items, setItems] = useState<MediaItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchTrending = async () => {
      setLoading(true);
      try {
        const trendData = await tmdbClient.getTrending('all', timeframe);
        setItems(trendData || []);
      } catch (e) {
        console.error("Trending view query dispatch exception", e);
      } finally {
        setLoading(false);
      }
    };

    fetchTrending();
  }, [timeframe]);

  return (
    <div className="flex flex-col gap-6 w-full text-left font-sans select-none pb-20">
      
      {/* View Header with Timeframe Toggles */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-white/5 pb-4">
        <div>
          <span className="text-[10px] text-neon-red font-mono tracking-widest font-bold uppercase flex items-center gap-1.5">
            <Flame className="w-3.5 h-3.5 fill-current animate-pulse" />
            Lumina Realtime Charts
          </span>
          <h1 className="text-xl md:text-2xl font-extrabold tracking-tight text-white uppercase mt-0.5 leading-none">
            Trending Media Billboard
          </h1>
        </div>

        {/* Day/Week Selector Tabs */}
        <div className="flex items-center gap-1 bg-white/5 border border-white/10 p-1.5 rounded-xl">
          <button
            onClick={() => setTimeframe('day')}
            className={cn(
              "flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-mono font-bold uppercase transition-all cursor-pointer",
              timeframe === 'day' 
                ? "bg-neon-red text-white glow-red" 
                : "text-gray-400 hover:text-white"
            )}
          >
            <Clock className="w-3.5 h-3.5" />
            Daily Charts
          </button>
          
          <button
            onClick={() => setTimeframe('week')}
            className={cn(
              "flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-mono font-bold uppercase transition-all cursor-pointer",
              timeframe === 'week' 
                ? "bg-neon-red text-white glow-red" 
                : "text-gray-400 hover:text-white"
            )}
          >
            <Flame className="w-3.5 h-3.5" />
            Weekly Charts
          </button>
        </div>
      </div>

      {loading ? (
        <SkeletonRow cardCount={12} />
      ) : items.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 bg-white/2 rounded-2xl border border-dashed border-white/5">
          <AlertOctagon className="w-10 h-10 text-gray-500 mb-2" />
          <p className="text-xs text-gray-400 font-mono">No trending items loaded from network.</p>
        </div>
      ) : (
        /* --- HIGH-FIDELITY RANKED LAYOUT GRID --- */
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-x-8 gap-y-10 mt-2">
          {items.slice(0, 12).map((item, index) => (
            <div 
              key={item.id}
              className="relative group flex items-end pl-14" // Push left to accomodate massive number
            >
              {/* Massive Backdrop Rank Number (Creates beautiful overlapping depth) */}
              <div className="absolute left-0 bottom-4 text-[130px] font-black font-mono tracking-tighter leading-none select-none text-gray-800/20 group-hover:text-neon-red/25 group-hover:scale-105 group-hover:rotate-3 transition-all duration-300 z-0 pointer-events-none italic">
                {index + 1}
              </div>

              {/* Media card on top */}
              <div className="relative w-full z-10">
                <MediaCard item={item} />
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
export default TrendingView;
