import React, { useState, useRef } from "react";
import { 
  Home, 
  Flame, 
  Film, 
  Tv, 
  Bookmark, 
  History as HistoryIcon, 
  Settings as SettingsIcon,
  Menu,
  X,
  Search,
  Sparkles,
  Smile,
  Gamepad2,
  Clapperboard
} from "lucide-react";
import { useAppStore, ViewType } from "../lib/store";
import { cn } from "../lib/utils";
import { useAuth, AVATAR_PRESETS } from "../context/AuthContext";
import { useAestheticTheme } from "../context/ThemeContext";
import { Logo } from "./Logo";
import { motion } from "motion/react";

// --- HIGH PERFORMANCE MAGNETIC SNAPPING UTILITY ---
interface MagneticTargetProps {
  children: React.ReactNode;
  radius?: number;
  className?: string;
}

export const MagneticTarget: React.FC<MagneticTargetProps> = ({ children, radius = 42, className }) => {
  const ref = useRef<HTMLDivElement>(null);
  const [position, setPosition] = useState({ x: 0, y: 0 });

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!ref.current) return;
    const { clientX, clientY } = e;
    const { left, top, width, height } = ref.current.getBoundingClientRect();
    const centerX = left + width / 2;
    const centerY = top + height / 2;
    
    const distanceX = clientX - centerX;
    const distanceY = clientY - centerY;
    const distance = Math.sqrt(distanceX * distanceX + distanceY * distanceY);

    if (distance < radius) {
      // Pull proportional to closeness
      const pull = 0.38; // Proportional snap coefficient
      setPosition({ x: distanceX * pull, y: distanceY * pull });
    } else {
      setPosition({ x: 0, y: 0 });
    }
  };

  const handleMouseLeave = () => {
    setPosition({ x: 0, y: 0 });
  };

  return (
    <motion.div
      ref={ref}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      animate={{ x: position.x, y: position.y }}
      transition={{ type: "spring", stiffness: 220, damping: 13 }}
      className={className}
    >
      {children}
    </motion.div>
  );
};


export const Navigation: React.FC = () => {
  const { activeView, setView, activeGenre, setGenreView } = useAppStore();
  const { currentProfile, clearActiveProfile } = useAuth();
  const { config, activeTheme } = useAestheticTheme();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const activeAvatar = AVATAR_PRESETS[currentProfile?.avatarIdx ?? 0];

  const mainNavItems = [
    { view: 'home' as ViewType, label: 'Home', icon: Home },
    { view: 'trending' as ViewType, label: 'Trending', icon: Flame },
    { view: 'movies' as ViewType, label: 'Movies', icon: Film },
    { view: 'tv' as ViewType, label: 'TV Shows', icon: Tv },
    { view: 'watchlist' as ViewType, label: 'Watchlist', icon: Bookmark },
    { view: 'history' as ViewType, label: 'History', icon: HistoryIcon },
  ];

  const genreNavItems = [
    { genre: 'scifi', label: 'Sci-Fi', icon: Sparkles },
    { genre: 'horror', label: 'The Abyss', icon: Flame },
    { genre: 'anime', label: 'Anime', icon: Gamepad2 },
    { genre: 'cartoons', label: 'Playful', icon: Smile },
    { genre: 'movies', label: 'Classic', icon: Clapperboard },
  ];

  const handleNavClick = (view: ViewType) => {
    setView(view);
    setMobileMenuOpen(false);
  };

  const handleGenreClick = (genre: string) => {
    setGenreView(genre);
    setMobileMenuOpen(false);
  };

  return (
    <>
      {/* --- DESKTOP SIDEBAR (72px wide, fixed left) --- */}
      <aside 
        id="desktop-sidebar"
        className="hidden lg:flex flex-col items-center justify-between py-6 w-[72px] h-screen fixed top-0 left-0 bg-black/40 backdrop-blur-3xl border-r border-white/5 z-50 select-none transition-colors duration-500"
        style={{ borderRightColor: `${config.accentColor}1e` }}
      >
        {/* Dynamic Compact Logo */}
        <div 
          onClick={() => handleNavClick('home')}
          className="cursor-pointer mb-8 w-full flex justify-center py-2 relative"
        >
          <Logo iconOnly={true} size="md" />
        </div>

        {/* Mid Navigation items (Wrapped in Magnetic Targets!) */}
        <nav className="flex-1 flex flex-col gap-3.5 w-full items-center overflow-y-auto no-scrollbar py-2">
          {mainNavItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeView === item.view;

            return (
              <div key={item.view} className="relative group w-full flex justify-center py-0.5 shrink-0">
                <MagneticTarget radius={35} className="w-full flex justify-center">
                  <button
                    onClick={() => handleNavClick(item.view)}
                    className={cn(
                      "relative flex items-center justify-center w-[54px] h-11 rounded-xl transition-all duration-300 cursor-pointer",
                      isActive 
                        ? "" 
                        : "text-white/40 hover:text-white/90 hover:bg-white/5"
                    )}
                    style={isActive ? {
                      color: config.accentColor,
                      backgroundColor: `${config.accentColor}15`,
                      boxShadow: `inset 0 0 10px ${config.accentColor}0a, 0 2px 8px ${config.accentColor}10`
                    } : undefined}
                  >
                    <Icon className={cn("w-4.5 h-4.5", isActive && "stroke-[2.5]")} />
                  </button>
                </MagneticTarget>
                
                {/* Visual side tooltips */}
                <div className="absolute left-18 top-1/2 -translate-y-1/2 ml-2 px-2.5 py-1.5 rounded-lg bg-black/95 border border-white/10 text-[9px] font-bold tracking-widest text-white opacity-0 scale-90 origin-left group-hover:opacity-100 group-hover:scale-100 transition-all duration-350 pointer-events-none whitespace-nowrap z-50 font-mono uppercase">
                  {item.label}
                </div>
              </div>
            );
          })}

          {/* Aesthetic Divider line */}
          <div className="w-8 h-[1px] bg-white/10 my-1.5 shrink-0" />

          {/* Genre Dimensions Sub-navigation */}
          {genreNavItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeView === 'genre' && activeGenre === item.genre;

            return (
              <div key={item.genre} className="relative group w-full flex justify-center py-0.5 shrink-0">
                <MagneticTarget radius={35} className="w-full flex justify-center">
                  <button
                    onClick={() => handleGenreClick(item.genre)}
                    className={cn(
                      "relative flex items-center justify-center w-[54px] h-11 rounded-xl transition-all duration-300 cursor-pointer",
                      isActive 
                        ? "" 
                        : "text-white/40 hover:text-white/90 hover:bg-white/5"
                    )}
                    style={isActive ? {
                      color: config.accentColor,
                      backgroundColor: `${config.accentColor}15`,
                      boxShadow: `inset 0 0 10px ${config.accentColor}0a, 0 2px 8px ${config.accentColor}10`
                    } : undefined}
                  >
                    <Icon className={cn("w-4.5 h-4.5", isActive && "stroke-[2.5]")} />
                  </button>
                </MagneticTarget>
                
                {/* Visual side tooltips */}
                <div className="absolute left-18 top-1/2 -translate-y-1/2 ml-2 px-2.5 py-1.5 rounded-lg bg-black/95 border border-white/10 text-[9px] font-bold tracking-widest text-white opacity-0 scale-90 origin-left group-hover:opacity-100 group-hover:scale-100 transition-all duration-350 pointer-events-none whitespace-nowrap z-50 font-mono uppercase">
                  {item.label}
                </div>
              </div>
            );
          })}
        </nav>

        {/* Bottom Menu: Settings & Profile (All Magnetic Snap!) */}
        <div className="flex flex-col items-center gap-5 w-full">
          <div className="relative group w-full flex justify-center">
            <MagneticTarget radius={35} className="w-full flex justify-center">
              <button
                onClick={() => handleNavClick('settings')}
                className={cn(
                  "relative flex items-center justify-center w-[54px] h-11 rounded-xl transition-all duration-350",
                  activeView === 'settings'
                    ? ""
                    : "text-white/40 hover:text-white/90 hover:bg-white/5"
                )}
                style={activeView === 'settings' ? {
                  color: config.accentColor,
                  backgroundColor: `${config.accentColor}15`,
                } : undefined}
              >
                <SettingsIcon className="w-4.5 h-4.5" />
              </button>
            </MagneticTarget>
            
            <div className="absolute left-18 top-1/2 -translate-y-1/2 ml-2 px-2.5 py-1.5 rounded-lg bg-black/95 border border-white/10 text-[9px] font-bold tracking-widest text-white opacity-0 scale-90 origin-left group-hover:opacity-100 group-hover:scale-100 transition-all duration-350 pointer-events-none whitespace-nowrap z-50 font-mono uppercase">
              SETTINGS
            </div>
          </div>

          <MagneticTarget radius={30}>
            <div 
              onClick={clearActiveProfile}
              className="w-9 h-9 rounded-xl bg-white/5 border border-white/10 p-0.5 cursor-pointer hover:scale-105 transition-all mb-2"
              style={{ hoverBorderColor: config.accentColor }}
              title={`Active: ${currentProfile?.name} - Click to Switch Profiles`}
            >
              <div className={`w-full h-full rounded-lg bg-gradient-to-tr ${activeAvatar?.bgColor} flex items-center justify-center font-black shadow text-white text-[10px] font-mono`}>
                {currentProfile?.name.charAt(0)}
              </div>
            </div>
          </MagneticTarget>
        </div>
      </aside>


      {/* --- MOBILE TOP-BAR --- */}
      <header 
        id="mobile-header"
        className="flex lg:hidden items-center justify-between px-4 h-16 fixed top-0 left-0 right-0 bg-[#0B0E11]/90 backdrop-blur-3xl border-b border-white/5 z-50 select-none transition-colors duration-500"
        style={{ borderBottomColor: `${config.accentColor}12` }}
      >
        <div 
          onClick={() => handleNavClick('home')}
          className="flex items-center cursor-pointer pt-1"
        >
          <Logo size="sm" />
        </div>

        {/* Search input for responsive look */}
        <div className="flex items-center gap-2">
          <button 
            onClick={() => {
              setView('home');
              setTimeout(() => {
                const searchElem = document.getElementById('search-bar-input') as HTMLInputElement | null;
                if (searchElem) {
                  searchElem.focus();
                  searchElem.select();
                }
              }, 120);
            }}
            className="p-2 rounded-xl text-gray-400 hover:text-white hover:bg-white/5 cursor-pointer"
          >
            <Search className="w-4.5 h-4.5" />
          </button>

          <button 
            onClick={clearActiveProfile}
            className="w-7 h-7 rounded-lg bg-white/10 border border-white/15 p-0.5 hover:scale-105 active:scale-95 transition-all text-white font-mono text-[9px] uppercase font-black"
            title={`Active: ${currentProfile?.name} - Click to Switch`}
          >
            <div className={`w-full h-full rounded bg-gradient-to-tr ${activeAvatar?.bgColor} flex items-center justify-center shadow`}>
              {currentProfile?.name.charAt(0)}
            </div>
          </button>

          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 rounded-xl text-gray-300 hover:text-white hover:bg-white/5 relative"
          >
            {mobileMenuOpen ? <X className="w-5.5 h-5.5" style={{ color: config.accentColor }} /> : <Menu className="w-5.5 h-5.5" />}
          </button>
        </div>
      </header>


      {/* --- MOBILE SLIDE-DOWN NAVIGATION & SETTINGS AREA --- */}
      <div
        className={cn(
          "lg:hidden fixed left-0 right-0 border-b border-white/5 z-40 transition-all duration-400 overflow-y-auto flex flex-col gap-2 font-sans bg-[#0c0d12]/95 backdrop-blur-3xl",
          mobileMenuOpen ? "top-16 opacity-100 max-h-[85vh] p-5 shadow-2xl" : "top-[-500px] opacity-0 max-h-0 pointer-events-none"
        )}
        style={{ borderBottomColor: `${config.accentColor}1e` }}
      >
        <span className="text-[9px] text-gray-500 font-mono tracking-widest uppercase mb-1 block">Navigation Links</span>
        <div className="grid grid-cols-2 gap-2.5">
          {mainNavItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeView === item.view;
            return (
              <button
                key={item.view}
                onClick={() => handleNavClick(item.view)}
                className={cn(
                  "flex items-center gap-2.5 px-3.5 py-3 rounded-xl border text-xs font-bold transition-all text-left cursor-pointer",
                  isActive
                    ? "text-white"
                    : "bg-white/5 border-white/5 text-gray-400 hover:text-white"
                )}
                style={isActive ? {
                  borderColor: `${config.accentColor}50`,
                  backgroundImage: `linear-gradient(to right, ${config.accentColor}18, ${config.accentColor}06)`
                } : undefined}
              >
                <Icon className="w-4 h-4" style={{ color: isActive ? config.accentColor : '#9ca3af' }} />
                {item.label}
              </button>
            );
          })}
        </div>

        <span className="text-[9px] text-gray-500 font-mono tracking-widest uppercase mt-4 mb-1 block animate-fade-in">Aesthetic Dimensions</span>
        <div className="grid grid-cols-2 gap-2.5">
          {genreNavItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeView === 'genre' && activeGenre === item.genre;
            return (
              <button
                key={item.genre}
                onClick={() => handleGenreClick(item.genre)}
                className={cn(
                  "flex items-center gap-2.5 px-3.5 py-3 rounded-xl border text-xs font-bold transition-all text-left cursor-pointer",
                  isActive
                    ? "text-white"
                    : "bg-white/5 border-white/15 text-gray-400 hover:text-white"
                )}
                style={isActive ? {
                  borderColor: `${config.accentColor}50`,
                  backgroundImage: `linear-gradient(to right, ${config.accentColor}18, ${config.accentColor}06)`
                } : undefined}
              >
                <Icon className="w-4 h-4" style={{ color: isActive ? config.accentColor : '#9ca3af' }} />
                {item.label}
              </button>
            );
          })}
        </div>

        <div className="border-t border-white/5 my-3 pt-3 flex flex-col gap-2">
          <span className="text-[9px] text-gray-500 font-mono tracking-widest uppercase block mb-1">Preferences</span>
          <button
            onClick={() => handleNavClick('settings')}
            className={cn(
              "flex items-center gap-2.5 px-3.5 py-3 rounded-xl text-xs font-bold text-left border cursor-pointer",
              activeView === 'settings'
                ? "text-white"
                : "bg-white/5 border-transparent text-gray-400 hover:text-white"
            )}
            style={activeView === 'settings' ? {
              borderColor: `${config.accentColor}50`,
              backgroundImage: `linear-gradient(to right, ${config.accentColor}18, ${config.accentColor}06)`
            } : undefined}
          >
            <SettingsIcon className="w-4 h-4" style={{ color: activeView === 'settings' ? config.accentColor : '#9ca3af' }} />
            Lumina Configuration & API
          </button>
        </div>
      </div>


      {/* --- MOBILE BOTTOM BAR --- */}
      <nav 
        id="mobile-bottom-nav"
        className="flex lg:hidden items-center justify-around h-[64px] fixed bottom-0 left-0 right-0 bg-[#0B0E11]/90 backdrop-blur-3xl border-t border-white/5 z-50 select-none pb-safe transition-colors duration-500"
        style={{ borderTopColor: `${config.accentColor}12` }}
      >
        {mainNavItems.slice(0, 5).map((item) => {
          const Icon = item.icon;
          const isActive = activeView === item.view;

          return (
            <button
              key={item.view}
              onClick={() => handleNavClick(item.view)}
              className={cn(
                "flex flex-col items-center justify-center w-14 h-12 rounded-lg transition-all duration-200",
                isActive ? "" : "text-gray-400 hover:text-white"
              )}
              style={isActive ? { color: config.accentColor } : undefined}
            >
              <Icon className={cn("w-4.5 h-4.5", isActive && "stroke-[2.5]")} />
              <span className="text-[9px] mt-0.5 tracking-tighter text-center font-bold font-sans">
                {item.label === 'TV Shows' ? 'TV' : item.label}
              </span>
            </button>
          );
        })}
      </nav>
    </>
  );
};
export default Navigation;
