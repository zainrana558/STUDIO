import React, { useState, useEffect } from "react";
import { Film, Tv, Sparkles, Filter, ChevronRight } from "lucide-react";
import { MediaItem } from "../types";
import { tmdbClient } from "../lib/tmdb/client";
import { MOCK_GENRES } from "../lib/tmdb/mockData";
import { useAppStore } from "../lib/store";
import { MediaCard } from "./MediaCard";
import { SkeletonRow } from "./SkeletonLoader";
import { cn } from "../lib/utils";

interface CatalogViewProps {
  type: 'movie' | 'tv';
}

export const CatalogView: React.FC<CatalogViewProps> = ({ type }) => {
  const { selectMedia } = useAppStore();

  const [popular, setPopular] = useState<MediaItem[]>([]);
  const [topRated, setTopRated] = useState<MediaItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedGenreId, setSelectedGenreId] = useState<number | null>(null);

  // 1. Fetch catalog data based on type
  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      setSelectedGenreId(null); // Reset filter when switching between movies vs tv
      try {
        const [popData, topData] = await Promise.all([
          tmdbClient.getPopular(type),
          tmdbClient.getTopRated(type)
        ]);
        setPopular(popData || []);
        setTopRated(topData || []);
      } catch (err) {
        console.error(`Catalog fetch failed for ${type}:`, err);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [type]);

  // Combined unique list for filtered rendering
  const allLoadedItems = [...popular, ...topRated].reduce<MediaItem[]>((acc, current) => {
    const isDuplicate = acc.some(item => item.id === current.id);
    if (!isDuplicate) {
      acc.push(current);
    }
    return acc;
  }, []);

  // Filter items based on selected genre ID
  const filteredItems = selectedGenreId
    ? allLoadedItems.filter((item) => {
        if (item.genre_ids) {
          return item.genre_ids.includes(selectedGenreId);
        }
        if (item.genres) {
          return item.genres.some((g) => g.id === selectedGenreId);
        }
        return false;
      })
    : allLoadedItems;

  return (
    <div className="flex flex-col gap-6 w-full text-left font-sans select-none pb-20">
      
      {/* Header section */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border-b border-white/5 pb-4">
        <div>
          <span className="text-[10px] text-neon-red font-mono tracking-widest font-bold uppercase flex items-center gap-1.5 justify-start">
            {type === 'movie' ? <Film className="w-3.5 h-3.5" /> : <Tv className="w-3.5 h-3.5" />}
            Lumina Cinematic Index
          </span>
          <h1 className="text-xl md:text-2xl font-extrabold tracking-tight text-white uppercase mt-1 leading-none">
            {type === 'movie' ? "Feature Film Library" : "Television Series Hub"}
          </h1>
        </div>

        {/* Informative indicator badge */}
        <span className="px-3 py-1 rounded-full bg-white/5 border border-white/10 text-xs font-mono text-gray-400">
          Source Node: {type === 'movie' ? "TMDB Movies" : "TMDB Television"}
        </span>
      </div>

      {/* Scrolling Genre Chips Filter Bar */}
      <div className="flex flex-col gap-2 bg-white/2 border border-white/5 p-4 rounded-xl">
        <label className="text-[10px] text-gray-500 font-mono uppercase tracking-widest font-bold flex items-center gap-1.5">
          <Filter className="w-3 h-3 text-neon-red" />
          Filter by Genre Category
        </label>
        
        <div className="flex gap-2 overflow-x-auto scrollbar-hide py-1">
          {/* Universal Chip */}
          <button
            onClick={() => setSelectedGenreId(null)}
            className={cn(
              "px-3.5 py-1.5 rounded-lg text-xs font-mono font-bold uppercase tracking-wide transition-all border shrink-0 cursor-pointer",
              selectedGenreId === null
                ? "bg-neon-red text-white border-neon-red px-4 glow-red"
                : "bg-white/5 border-white/5 text-gray-400 hover:text-white hover:bg-white/10"
            )}
          >
            All Categories
          </button>

          {/* Individual Category Chips */}
          {MOCK_GENRES.map((gen) => {
            const isChipActive = selectedGenreId === gen.id;
            return (
              <button
                key={gen.id}
                onClick={() => setSelectedGenreId(gen.id)}
                className={cn(
                  "px-3.5 py-1.5 rounded-lg text-xs font-mono font-semibold uppercase tracking-wide transition-all border shrink-0 cursor-pointer",
                  isChipActive
                    ? "bg-neon-red text-white border-neon-red px-4 glow-red"
                    : "bg-white/5 border-white/5 text-gray-400 hover:text-white hover:bg-white/10"
                )}
              >
                {gen.name}
              </button>
            );
          })}
        </div>
      </div>

      {loading ? (
        <SkeletonRow cardCount={12} />
      ) : filteredItems.length === 0 ? (
        /* --- EMPTY FILTER VIEW --- */
        <div className="flex flex-col items-center justify-center p-20 border border-dashed border-white/5 rounded-2xl bg-white/2 text-center">
          <Filter className="w-10 h-10 text-gray-600 mb-2 stroke-[1.5]" />
          <p className="text-xs text-gray-400 font-mono uppercase">No titles match targeted genre filter.</p>
          <button
            onClick={() => setSelectedGenreId(null)}
            className="mt-3 px-4 py-2 font-mono text-xs font-bold uppercase rounded-lg bg-neon-red text-white hover:brightness-110 cursor-pointer"
          >
            Clear Filters
          </button>
        </div>
      ) : (
        /* --- CARDS DISPLAY GRID --- */
        <div className="flex flex-col gap-6">
          <div className="flex items-center gap-2 text-left">
            <span className="text-xs text-gray-400 font-mono uppercase tracking-wider">
              Displaying {filteredItems.length} filtered items
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-x-4 gap-y-7 leading-none">
            {filteredItems.map((item) => (
              <MediaCard key={item.id} item={item} />
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
export default CatalogView;
