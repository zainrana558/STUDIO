import React from "react";
import { 
  Bookmark, 
  History as HistoryIcon,
  Play, 
  Trash2, 
  Sparkles, 
  X, 
  Flame, 
  Clock,
  Film,
  RotateCcw
} from "lucide-react";
import { useWatchlist } from "../context/WatchlistContext";
import { useHistory } from "../context/HistoryContext";
import { useAppStore } from "../lib/store";
import { formatTime } from "../lib/utils";
import { cn } from "../lib/utils";
import { MediaCard } from "./MediaCard";

interface WatchHistoryViewProps {
  type: 'watchlist' | 'history';
}

export const WatchHistoryView: React.FC<WatchHistoryViewProps> = ({ type }) => {
  const { watchlist, removeFromWatchlist } = useWatchlist();
  const { history, removeFromHistory, clearHistory } = useHistory();
  const { selectMedia, setView } = useAppStore();

  const isWatchlist = type === 'watchlist';

  return (
    <div className="flex flex-col gap-6 w-full text-left font-sans select-none pb-20">
      
      {/* 1. Header and Clean Actions */}
      <div className="flex flex-row items-center justify-between gap-4 border-b border-white/5 pb-4">
        <div>
          <span className="text-[10px] text-neon-red font-mono tracking-widest font-bold uppercase flex items-center gap-1.5 justify-start">
            {isWatchlist ? <Bookmark className="w-3.5 h-3.5" /> : <HistoryIcon className="w-3.5 h-3.5" />}
            Personal Lumina Profile
          </span>
          <h1 className="text-xl md:text-2xl font-extrabold tracking-tight text-white uppercase mt-1 leading-none">
            {isWatchlist ? "My Bookmarked Watchlist" : "Media Playback History"}
          </h1>
        </div>

        {/* Action: Clear History logs if on history */}
        {!isWatchlist && history.length > 0 && (
          <button
            onClick={() => {
              if (window.confirm("Do you want to wipe all playback trajectory histories?")) {
                clearHistory();
              }
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-red-500/30 bg-red-500/10 text-red-400 hover:bg-red-500/20 text-xs font-mono font-bold tracking-wide transition-all cursor-pointer uppercase hover:glow-red"
          >
            <Trash2 className="w-3.5 h-3.5" />
            Clear Logs
          </button>
        )}
      </div>

      {/* 2. Main Trajectory */}
      {isWatchlist ? (
        /* --- WATCHLIST PORTFOLIO --- */
        watchlist.length === 0 ? (
          <div className="flex flex-col items-center justify-center p-20 border border-dashed border-white/5 bg-white/2 rounded-2xl text-center max-w-lg mx-auto mt-10">
            <Bookmark className="w-12 h-12 text-neon-purple mb-4 stroke-[1.5] animate-bounce" />
            <h3 className="text-sm font-bold font-mono text-white uppercase tracking-wider">Watchlist is Empty</h3>
            <p className="text-xs text-gray-500 font-sans mt-1">
              Assemble titles in the carousel or card sliders to populate quick launch streams here.
            </p>
            <button
              onClick={() => setView('home')}
              className="mt-4 px-4 py-2 font-mono text-xs font-bold uppercase rounded-lg bg-neon-red text-white hover:bg-red-600 transition-colors cursor-pointer"
            >
              Discover Cinema
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-x-4 gap-y-7 leading-none">
            {watchlist.map((item) => {
              // Cast from WatchlistItem to MediaItem to satisfy card props
              const mediaItem = {
                id: item.id,
                title: item.title,
                poster_path: item.poster_path,
                backdrop_path: item.backdrop_path,
                vote_average: item.vote_average,
                release_date: item.release_date,
                media_type: item.media_type,
                overview: "",
              };
              return <MediaCard key={item.id} item={mediaItem} />;
            })}
          </div>
        )
      ) : (
        /* --- PLAYBACK TRACKING LOGS (HISTORY) --- */
        history.length === 0 ? (
          <div className="flex flex-col items-center justify-center p-20 border border-dashed border-white/5 bg-white/2 rounded-2xl text-center max-w-lg mx-auto mt-10">
            <HistoryIcon className="w-12 h-12 text-neon-cyan mb-4 stroke-[1.5]" />
            <h3 className="text-sm font-bold font-mono text-white uppercase tracking-wider">No Playback Trajectories</h3>
            <p className="text-xs text-gray-400 font-sans mt-1">
              Trajectories of streaming speeds, servers, and progress timers will map out automatically when you slide into streams.
            </p>
            <button
              onClick={() => setView('home')}
              className="mt-4 px-4 py-2 font-mono text-xs font-bold uppercase rounded-lg bg-neon-cyan text-black hover:brightness-110 transition-all font-semibold cursor-pointer"
            >
              Start Streaming
            </button>
          </div>
        ) : (
          <div className="flex flex-col gap-4">
            <span className="text-xs text-gray-500 font-mono tracking-wide uppercase">
              Recent Streams ({history.length} items logged)
            </span>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {history.map((hItem) => {
                const isFinished = hItem.progress >= 95;
                const progressColorClass = isFinished 
                  ? "bg-emerald-500 shadow-sm"
                  : "bg-neon-red glow-red shadow-sm";

                return (
                  <div 
                    key={hItem.id}
                    className="flex gap-4 p-4 rounded-xl border border-white/5 bg-gradient-to-r from-card-dark to-black/40 hover:border-white/10 transition-all items-center relative group"
                  >
                    {/* Media Small Poster wrapper */}
                    <div className="w-16 h-24 rounded-lg overflow-hidden shrink-0 border border-white/5 bg-gray-950">
                      <img 
                        src={hItem.poster_path ? `https://image.tmdb.org/t/p/w185${hItem.poster_path}` : "https://images.unsplash.com/photo-1578301978693-85fa9c0320b9?q=80&w=150&auto=format&fit=crop"} 
                        alt={hItem.title} 
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        loading="lazy"
                      />
                    </div>

                    {/* Metadata Content area */}
                    <div className="flex-1 flex flex-col gap-1 text-left min-w-0">
                      <div className="flex items-center gap-1.5">
                        <span className="text-[8px] px-1.5 py-0.5 rounded font-mono font-bold uppercase tracking-widest text-white tracking-tighter bg-white/5 border border-white/5">
                          {hItem.media_type}
                        </span>
                        <span className="text-[9px] text-gray-500 font-mono tracking-wider">
                          Logged: {new Date(hItem.watchedAt).toLocaleDateString()}
                        </span>
                      </div>

                      <h3 className="text-sm font-bold text-gray-100 uppercase tracking-wide truncate pr-6">
                        {hItem.title}
                      </h3>

                      {/* Timeline status meters */}
                      <div className="flex flex-col gap-1 mt-1.5">
                        <div className="flex justify-between items-center text-[10px] font-mono text-gray-400">
                          <span>Progress: {hItem.progress}%</span>
                          <span>{formatTime(hItem.currentTime)} / {formatTime(hItem.duration)}</span>
                        </div>

                        {/* Progress slider bar */}
                        <div className="w-full h-1 rounded-full bg-white/10 overflow-hidden relative mt-1">
                          <div 
                            className={cn("h-full rounded-full transition-all duration-300", progressColorClass)}
                            style={{ width: `${hItem.progress}%` }}
                          />
                        </div>
                      </div>
                    </div>

                    {/* Fast Navigation Panel floating on hover right */}
                    <div className="flex flex-col gap-2 shrink-0">
                      {/* Trash deletes from history log */}
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          removeFromHistory(hItem.id);
                        }}
                        className="p-1.5 rounded-lg border border-transparent hover:border-white/10 hover:bg-white/5 text-gray-500 hover:text-white transition-all cursor-pointer active:scale-90"
                        title="Delete log entry"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>

                      {/* Play triggers details/player view */}
                      <button
                        onClick={() => {
                          const med = {
                            id: hItem.id,
                            title: hItem.title,
                            poster_path: hItem.poster_path,
                            backdrop_path: hItem.backdrop_path,
                            media_type: hItem.media_type,
                            overview: "",
                            vote_average: 8.0,
                          };
                          selectMedia(med);
                        }}
                        className="p-1.5 rounded-lg bg-neon-red border border-neon-red/20 text-white hover:glow-red-strong transition-all cursor-pointer active:scale-90 flex items-center justify-center"
                        title="Resume streaming"
                      >
                        <Play className="w-3.5 h-3.5 fill-white" />
                      </button>
                    </div>

                  </div>
                );
              })}
            </div>
          </div>
        )
      )}
    </div>
  );
};
export default WatchHistoryView;
