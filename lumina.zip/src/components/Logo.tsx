import React, { useState } from "react";
import { motion } from "motion/react";
import { useAestheticTheme } from "../context/ThemeContext";

interface LogoProps {
  className?: string;
  size?: "sm" | "md" | "lg";
  iconOnly?: boolean;
}

export const Logo: React.FC<LogoProps> = ({ className, size = "md", iconOnly = false }) => {
  const { activeTheme } = useAestheticTheme();
  const [isHovered, setIsHovered] = useState(false);

  // Sizing map for responsive application shells
  const dimensionMap = {
    sm: { width: 110, height: 32, iconSize: 22 },
    md: { width: 140, height: 40, iconSize: 28 },
    lg: { width: 200, height: 56, iconSize: 40 },
  };

  const { width, height } = dimensionMap[size];

  // Colors, gradients, and filters selection based on Theme state
  const getThemeAesthetic = () => {
    switch (activeTheme) {
      case "anime":
        return {
          iconStroke: "#00f0ff",
          iconFill: "rgba(0, 240, 255, 0.15)",
          textFill: "#ffffff",
          anchorColor: "#ff007f", // Neon pink distinct '2'
          filterId: "url(#anime-neon-glow)",
          glowColor: "#00f0ff",
        };
      case "playful":
        return {
          iconStroke: "#ff007f",
          iconFill: "rgba(255, 0, 127, 0.1)",
          textFill: "#ffffff",
          anchorColor: "#39ff14", // Bright lime playful '2'
          filterId: "url(#playful-shadow)",
          glowColor: "#ff007f",
        };
      case "abyss":
        return {
          iconStroke: "#be0000",
          iconFill: "rgba(190, 0, 0, 0.05)",
          textFill: "#737373", // Darker text representation
          anchorColor: "#ff0000", // Bloody crimson '2'
          filterId: "url(#abyss-chromatic-aberration)",
          glowColor: "#be0000",
        };
      case "cosmic":
        return {
          iconStroke: "#bf00ff",
          iconFill: "rgba(191, 0, 255, 0.12)",
          textFill: "#ffffff",
          anchorColor: "#00f0ff", // Electric cyan cosmic '2'
          filterId: "url(#cosmic-glassmorphic-glow)",
          glowColor: "#bf00ff",
        };
      case "classic":
      default:
        return {
          iconStroke: "#d4af37", // Pure Gold
          iconFill: "rgba(212, 175, 55, 0.08)",
          textFill: "#ffffff",
          anchorColor: "#e5e7eb", // Platinum silver '2' for dynamic anchor
          filterId: "url(#classic-theatrical-spotlight)",
          glowColor: "#d4af37",
        };
    }
  };

  const aesthetic = getThemeAesthetic();

  // Framer Motion variant physics definitions matching specific themes
  const getIconVariants = () => {
    switch (activeTheme) {
      case "anime":
        return {
          hover: {
            x: [0, -1.5, 1.5, -1, 1, 0],
            y: [0, 1, -1, 1, -1, 0],
            scale: 1.05,
            transition: {
              duration: 0.3,
              ease: "linear",
              repeat: Infinity,
            },
          },
        };
      case "playful":
        return {
          hover: {
            scale: 1.15,
            rotate: [0, -6, 8, -4, 4, 0],
            transition: {
              scale: {
                type: "spring",
                stiffness: 400,
                damping: 8,
              },
              rotate: {
                type: "keyframes",
                duration: 0.65,
                ease: "easeInOut",
              },
            },
          },
          tap: { scale: 0.85, rotate: -15 },
        };
      case "abyss":
        return {
          hover: {
            opacity: [1, 0.75, 1],
            scale: 0.98,
            transition: {
              duration: 2.0,
              repeat: Infinity,
              ease: "easeInOut",
            },
          },
        };
      case "cosmic":
        return {
          hover: {
            y: -3,
            scale: 1.05,
            transition: {
              repeat: Infinity,
              repeatType: "mirror" as const,
              duration: 1.6,
              ease: "easeInOut",
            },
          },
        };
      case "classic":
      default:
        return {
          hover: {
            scale: 1.04,
            transition: {
              type: "spring",
              stiffness: 220,
              damping: 15,
            },
          },
        };
    }
  };

  const getAnchorVariants = () => {
    switch (activeTheme) {
      case "anime":
        return {
          hover: {
            scale: [1, 1.25, 0.95, 1.1, 1],
            rotate: [0, 5, -5, 2, 0],
            skewX: [0, 15, -15, 0],
            transition: { duration: 0.45 },
          },
        };
      case "playful":
        return {
          hover: {
            scale: 1.35,
            y: -4,
            transition: {
              type: "spring",
              stiffness: 300,
              damping: 6,
            },
          },
        };
      case "abyss":
        return {
          hover: {
            scale: [1, 0.9, 1.1, 1],
            opacity: [1, 0.4, 0.9, 1],
            transition: { duration: 2.5, repeat: Infinity, ease: "easeInOut" },
          },
        };
      case "cosmic":
        return {
          hover: {
            rotate: 360,
            scale: 1.15,
            transition: { duration: 2.5, ease: "linear", repeat: Infinity },
          },
        };
      case "classic":
      default:
        return {
          hover: {
            opacity: [1, 0.5, 1],
            scale: 1.05,
            transition: { duration: 1.8, repeat: Infinity, ease: "easeInOut" },
          },
        };
    }
  };

  return (
    <div
      id="lumina-premium-brand-logo"
      className={`inline-flex items-center cursor-pointer select-none relative z-10 ${className}`}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <svg
        width={iconOnly ? (size === "sm" ? 32 : size === "lg" ? 56 : 38) : width}
        height={iconOnly ? (size === "sm" ? 32 : size === "lg" ? 56 : 38) : height}
        viewBox={iconOnly ? "4 0 28 40" : "0 0 140 40"}
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="w-full h-full overflow-visible"
      >
        <defs>
          {/* 1. Neon electric glow for Anime Mode */}
          <filter id="anime-neon-glow" x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur stdDeviation="1.5" result="blur1" />
            <feGaussianBlur stdDeviation="3.5" result="blur2" />
            <feMerge>
              <feMergeNode in="blur2" />
              <feMergeNode in="blur1" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>

          {/* 2. Soft bouncy shadowing for Cartoon Mode */}
          <filter id="playful-shadow" x="-30%" y="-30%" width="160%" height="160%">
            <feDropShadow dx="1" dy="3.5" stdDeviation="1.8" floodColor="#ff007f" floodOpacity="0.4" />
          </filter>

          {/* 3. Creepy chromatic aberration & subtle blur for Horror Mode */}
          <filter id="abyss-chromatic-aberration" x="-10%" y="-10%" width="120%" height="120%">
            <feOffset dx="-1.2" dy="0" result="red-offset" />
            <feColorMatrix
              type="matrix"
              values="1 0 0 0 0   0 0 0 0 0   0 0 0 0 0   0 0 0 1 0"
              in="red-offset"
              result="red-channel"
            />
            <feOffset dx="1.2" dy="0" result="blue-offset" />
            <feColorMatrix
              type="matrix"
              values="0 0 0 0 0   0 0 0 0 0   0 0 1 0 0   0 0 0 1 0"
              in="blue-offset"
              result="blue-channel"
            />
            <feMerge>
              <feMergeNode in="red-channel" />
              <feMergeNode in="blue-channel" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
            <feGaussianBlur stdDeviation="0.4" />
          </filter>

          {/* 4. Bioluminescent plasma gradient for Cosmic Mode */}
          <filter id="cosmic-glassmorphic-glow" x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur stdDeviation="2.5" result="blur" />
            <feComponentTransfer in="blur" result="glow">
              <feFuncA type="linear" slope="0.8" />
            </feComponentTransfer>
            <feMerge>
              <feMergeNode in="glow" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
          
          <linearGradient id="cosmic-charge-grad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#bf00ff" />
            <stop offset="50%" stopColor="#00f0ff" />
            <stop offset="100%" stopColor="#bf00ff" />
          </linearGradient>

          {/* 5. Theatrical Metallic Mask for Cinematic Classic */}
          <linearGradient id="classic-gold-grad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#b8860b" />
            <stop offset="30%" stopColor="#ffd700" />
            <stop offset="50%" stopColor="#ffffff" />
            <stop offset="70%" stopColor="#ffd700" />
            <stop offset="100%" stopColor="#9a7b1c" />
          </linearGradient>

          <filter id="classic-theatrical-spotlight" x="-10%" y="-10%" width="120%" height="120%">
            <feDropShadow dx="1" dy="1.5" stdDeviation="1.5" floodColor="#d4af37" floodOpacity="0.3" />
          </filter>
        </defs>

        {/* --- PART 1: THE ICON (Minimalistic Continuous Loop Intersection) --- */}
        <motion.g
          id="brand-icon-prism"
          variants={getIconVariants()}
          animate={isHovered ? "hover" : "normal"}
          whileTap="tap"
          filter={aesthetic.filterId}
          style={{ transformOrigin: "18px 20px" }}
        >
          {/* Dynamic Background aura inside outer vector */}
          <path
            d="M6 14 C6 8.5, 10.5 4, 16 4 H20 C25.5 4, 30 8.5, 30 14 V26 C30 31.5, 25.5 36, 20 36 H14 C8.5 36, 6 31.5, 6 26 Z"
            fill={aesthetic.iconFill}
            stroke={aesthetic.iconStroke}
            strokeWidth="1.5"
            className="transition-colors duration-500"
          />

          {/* Beautiful sleek intersecting ribbon loop (The L-2 loop) */}
          <motion.path
            d="M10 28 L10 12 C10 10, 14 10, 14 12 V24 L24 24 C26 24, 26 28, 24 28 Z"
            stroke={activeTheme === "cosmic" ? "url(#cosmic-charge-grad)" : aesthetic.iconStroke}
            strokeWidth="2.5"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="transition-colors duration-500"
            animate={activeTheme === "cosmic" ? {
              strokeDasharray: ["0, 40", "40, 0"],
              strokeDashoffset: [0, -80]
            } : undefined}
            transition={activeTheme === "cosmic" ? {
              duration: 4.0,
              repeat: Infinity,
              ease: "linear"
            } : undefined}
          />
          
          <path
            d="M17 14 L24 14 C26 14, 26 18, 24 19 L16 23 L25 23"
            stroke={aesthetic.anchorColor}
            strokeWidth="1.8"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="transition-colors duration-500"
          />

          {/* Tiny glowing prism bead at geometric center for high visual interest */}
          <circle
            cx="20"
            cy="20"
            r="1.8"
            fill={aesthetic.anchorColor}
            className="transition-colors duration-500 animate-pulse"
          />
        </motion.g>

        {/* --- PART 2: THE LOGOTYPE ("luminaa") --- */}
        {!iconOnly && (
          <g id="brand-wordmark" className="transition-all duration-500">
            <text
              x="42"
              y="26"
              fill={aesthetic.textFill}
              style={{
                fontFamily:
                  activeTheme === "anime"
                    ? "'Space Grotesk', system-ui, sans-serif"
                    : activeTheme === "playful"
                    ? "cursive, sans-serif"
                    : activeTheme === "abyss"
                    ? "serif"
                    : activeTheme === "cosmic"
                    ? "monospace"
                    : "system-ui, sans-serif",
                fontWeight: 900,
                fontSize: "19px",
                letterSpacing: activeTheme === "abyss" ? "0.22em" : "0.08em",
                textTransform: activeTheme === "abyss" ? "lowercase" : "uppercase",
                transition: "all 0.5s cubic-bezier(0.16, 1, 0.3, 1)",
              }}
              className="select-none transition-all duration-500"
            >
              {activeTheme === "abyss" ? "lumina" : "luminaa"}
            </text>
          </g>
        )}

        {/* --- PART 3: THE HIGHLY DISTINCT TRANSFORMABLE ANCHOR "2" --- */}
        {!iconOnly && (
          <motion.g
            id="brand-anchor-2"
            variants={getAnchorVariants()}
            animate={isHovered ? "hover" : "normal"}
            style={{ transformOrigin: "128px 24px" }}
          >
            {activeTheme === "playful" ? (
              // Round bubblegum styled "2"
              <text
                x="122"
                y="28"
                fill={aesthetic.anchorColor}
                style={{
                  fontFamily: "cursive, sans-serif",
                  fontWeight: 900,
                  fontSize: "26px",
                }}
              >
                2
              </text>
            ) : activeTheme === "anime" ? (
              // Cyberpunk jagged technical "2"
              <g>
                <path
                  d="M121 12 H133 L121 24 H134 V27 H119 L131 15 H121 Z"
                  fill={aesthetic.anchorColor}
                  filter="url(#anime-neon-glow)"
                />
                <rect x="119" y="10" width="1.5" height="18" fill="#00f0ff" opacity="0.6" />
              </g>
            ) : activeTheme === "abyss" ? (
              // Gothic classic editorial roman "II" or sharp raw letter
              <text
                x="122"
                y="25"
                fill={aesthetic.anchorColor}
                style={{
                  fontFamily: "serif",
                  fontWeight: "300",
                  fontSize: "18px",
                  letterSpacing: "0.1em",
                }}
              >
                ii
              </text>
            ) : activeTheme === "cosmic" ? (
              // Orbit terminal sci-fi mathematical "²"
              <g>
                <text
                  x="122"
                  y="19"
                  fill={aesthetic.anchorColor}
                  style={{
                    fontFamily: "monospace",
                    fontWeight: 800,
                    fontSize: "18px",
                  }}
                >
                  2
                </text>
                <circle cx="126" cy="14" r="9" stroke="#bf00ff" strokeWidth="1" strokeDasharray="2,2" />
              </g>
            ) : (
              // Classic premium brushed metal gold spotlight mask "2"
              <text
                x="122"
                y="26"
                fill="url(#classic-gold-grad)"
                style={{
                  fontFamily: "system-ui, sans-serif",
                  fontWeight: 800,
                  fontSize: "22px",
                }}
                filter={aesthetic.filterId}
              >
                2
              </text>
            )}
          </motion.g>
        )}
      </svg>
    </div>
  );
};
export default Logo;
