import React from "react";
import { useAppStore } from "./lib/store";
import { AuthProvider, useAuth } from "./context/AuthContext";
import { WatchlistProvider } from "./context/WatchlistContext";
import { HistoryProvider } from "./context/HistoryContext";
import { ThemeProvider, useAestheticTheme } from "./context/ThemeContext";
import { motion, AnimatePresence } from "motion/react";
import { getImageUrl } from "./lib/utils";

// View components
import { Navigation } from "./components/Navigation";
import { HomeView } from "./components/HomeView";
import { TrendingView } from "./components/TrendingView";
import { CatalogView } from "./components/CatalogView";
import { WatchHistoryView } from "./components/WatchHistoryView";
import { DetailsView } from "./components/DetailsView";
import { SettingsView } from "./components/SettingsView";
import { AuthView } from "./components/AuthView";
import { ProfileSelectionView } from "./components/ProfileSelectionView";
import { GenreHubView } from "./components/GenreHubView";
import { Loader2 } from "lucide-react";

function MainAppContent() {
  const { activeView, hoveredMedia, activeGenre } = useAppStore();
  const { user, currentProfile, loading } = useAuth();
  const { config } = useAestheticTheme();

  // 1. Loading state validation
  if (loading) {
    return (
      <div 
        className="min-h-screen flex flex-col items-center justify-center text-center transition-colors duration-500"
        style={{ backgroundColor: config?.bgColor || "#0B0E11" }}
      >
        <Loader2 
          className="w-10 h-10 animate-spin mb-4" 
          style={{ color: config?.accentColor || "#ff073a" }}
        />
        <p className="text-xs font-mono text-gray-500 uppercase tracking-widest">Loading Lumina Database...</p>
      </div>
    );
  }

  // 2. Unauthenticated state (Redirect to core Auth flow)
  if (!user) {
    return <AuthView />;
  }

  // 3. Authenticated but profile unselected (Redirect to profile picker)
  if (!currentProfile) {
    return <ProfileSelectionView />;
  }

  // 4. Authenticated & active profile initialized (Load standard Viewports)
  const renderActiveView = () => {
    switch (activeView) {
      case 'home':
        return <HomeView />;
      case 'trending':
        return <TrendingView />;
      case 'genre':
        return <GenreHubView />;
      case 'movies':
        return <CatalogView type="movie" />;
      case 'tv':
        return <CatalogView type="tv" />;
      case 'watchlist':
        return <WatchHistoryView type="watchlist" />;
      case 'history':
        return <WatchHistoryView type="history" />;
      case 'settings':
        return <SettingsView />;
      case 'player':
        return <DetailsView />;
      default:
        return <HomeView />;
    }
  };

  // Cinematic Shutter Page Transitions: sliding movie projector shutter with custom easing
  const shutterVariants = {
    initial: {
      clipPath: "inset(100% 0% 0% 0%)",
      opacity: 0,
      scale: 0.98,
      filter: "brightness(0.3) blur(6px)",
    },
    animate: {
      clipPath: "inset(0% 0% 0% 0%)",
      opacity: 1,
      scale: 1,
      filter: "brightness(1) blur(0px)",
      transition: {
        duration: 0.75,
        ease: [0.16, 1, 0.3, 1], // easeOutExpo
      }
    },
    exit: {
      clipPath: "inset(0% 0% 100% 0%)",
      opacity: 0,
      scale: 1.01,
      filter: "brightness(0.3) blur(6px)",
      transition: {
        duration: 0.55,
        ease: [0.7, 0, 0.84, 0], // easeInExpo
      }
    }
  };

  return (
    <div 
      className="min-h-screen text-gray-100 relative antialiased overflow-x-hidden pb-12 transition-colors duration-500"
      style={{ backgroundColor: config.bgColor }}
    >
      
      {/* Sleek Interface Ambient Background Glows */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden z-0">
        <div 
          className="absolute top-[-10%] left-[-10%] w-[45%] h-[45%] rounded-full blur-[140px] transition-all duration-700" 
          style={{ backgroundColor: `${config.accentColor}0e` }} // Ultra subtle transparent glow
        />
        <div 
          className="absolute bottom-[-10%] right-[-10%] w-[45%] h-[45%] rounded-full blur-[140px] transition-all duration-700" 
          style={{ backgroundColor: `${config.accentColor}07` }}
        />
      </div>

      {/* Fluid Backdrop Morphing: changes global page background via slow, hardware-accelerated transitions */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden z-0">
        <AnimatePresence>
          {hoveredMedia && (
            <motion.div
              key={hoveredMedia.id}
              initial={{ opacity: 0, scale: 1.04 }}
              animate={{ opacity: 0.24, scale: 1 }}
              exit={{ opacity: 0, scale: 1.02 }}
              transition={{ duration: 1.1, ease: "easeInOut" }}
              className="absolute inset-0 w-full h-full"
            >
              <img
                src={getImageUrl(hoveredMedia.backdrop_path || hoveredMedia.poster_path, 'original', 'backdrop')}
                alt=""
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover filter blur-[110px] scale-110 saturate-[1.65]"
              />
              <div 
                className="absolute inset-0 mix-blend-overlay opacity-25" 
                style={{ backgroundColor: config.accentColor }} 
              />
            </motion.div>
          )}
        </AnimatePresence>
      </div>
      
      {/* Main App Navigation (Desktop Sidebar & Responsive Mobile Bars) */}
      <Navigation />

      {/* Core Content Container view area */}
      <main 
        id="lumina-main-viewport"
        className="w-full max-w-7xl mx-auto px-4 sm:px-6 md:px-8 lg:px-10 pt-20 pb-24 lg:pt-8 lg:pb-8 lg:pl-28 transition-all duration-300 relative z-10"
      >
        <AnimatePresence mode="wait">
          <motion.div
            key={activeView === 'genre' ? `${activeView}-${activeGenre}` : activeView}
            initial="initial"
            animate="animate"
            exit="exit"
            variants={shutterVariants}
            className="w-full h-full relative"
          >
            {renderActiveView()}
          </motion.div>
        </AnimatePresence>
      </main>

    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <ThemeProvider>
        <WatchlistProvider>
          <HistoryProvider>
            <MainAppContent />
          </HistoryProvider>
        </WatchlistProvider>
      </ThemeProvider>
    </AuthProvider>
  );
}
