"use client";

import React, { useState, useEffect } from "react";
import { Play, Bookmark, Star, Sparkles, Film, Compass, Info, Skull, ShieldCheck } from "lucide-react";
import { motion } from "motion-react";

interface MediaItem {
  id: number;
  title?: string;
  name?: string;
  overview: string;
  poster_path: string;
  backdrop_path: string;
  vote_average: number;
  release_date?: string;
}

const THEME_VIDEOS: Record<string, string> = {
  scifi: "https://assets.mixkit.co/videos/preview/mixkit-flying-through-a-futuristic-tunnel-with-purple-lights-41604-large.mp4",
  horror: "https://assets.mixkit.co/videos/preview/mixkit-dense-smoke-drifts-on-a-black-background-40026-large.mp4",
  anime: "https://assets.mixkit.co/videos/preview/mixkit-tunnel-of-futuristic-glowing-blue-and-red-lights-41008-large.mp4",
  cartoons: "https://assets.mixkit.co/videos/preview/mixkit-pastel-colored-balls-swirling-in-a-fun-pattern-40154-large.mp4",
  movies: "https://assets.mixkit.co/videos/preview/mixkit-dust-particles-hovering-in-the-air-40030-large.mp4"
};

export default function NextJSGenreHubPage({ params }: { params: { slug: string } }) {
  const [unwrappedParams, setUnwrappedParams] = useState<{ slug: string } | null>(null);
  const [heroItem, setHeroItem] = useState<MediaItem | null>(null);
  const [shelfList, setShelfList] = useState<MediaItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Unwrap route params securely in a client-bound component context
  useEffect(() => {
    Promise.resolve(params).then((resolved) => {
      setUnwrappedParams(resolved);
    });
  }, [params]);

  const slug = unwrappedParams?.slug || "movies";

  useEffect(() => {
    if (!unwrappedParams) return;
    
    let active = true;
    const fetchAestheticData = async () => {
      setLoading(true);
      setError(null);
      try {
        if (slug === "anime") {
          // Zero Mock Data Constraint - Fetching directly from Jikan endpoints
          const res = await fetch("https://api.jikan.moe/v4/top/anime?limit=12");
          if (!res.ok) throw new Error("Could not populate anime directory.");
          const raw = await res.json();
          const items: MediaItem[] = raw.data.map((ani: any) => ({
            id: ani.mal_id,
            title: ani.title_english || ani.title,
            overview: ani.synopsis || "",
            poster_path: ani.images.jpg.large_image_url,
            backdrop_path: ani.images.jpg.large_image_url,
            vote_average: ani.score || 8.0,
            release_date: String(ani.year || 2024),
          }));
          if (active) {
            setHeroItem(items[0]);
            setShelfList(items.slice(1));
          }
        } else {
          // TMDB Filter parameters
          let genreId = "28"; // Action default
          if (slug === "cartoons") genreId = "16"; // Animation
          else if (slug === "horror") genreId = "27"; // Horror
          else if (slug === "scifi") genreId = "878"; // Sci-Fi
          
          const tmdbApiKey = process.env.NEXT_PUBLIC_TMDB_API_KEY;
          const url = tmdbApiKey 
            ? `https://api.themoviedb.org/3/discover/movie?api_key=${tmdbApiKey}&with_genres=${genreId}&sort_by=popularity.desc`
            : `/api/tmdb/discover/movie?with_genres=${genreId}&sort_by=popularity.desc`;
          
          const res = await fetch(url);
          if (!res.ok) throw new Error("Could not fetch remote media stream. Ensure API keys exist.");
          const data = await res.json();
          const items = (data.results || []).map((movie: any) => ({
            id: movie.id,
            title: movie.title,
            overview: movie.overview,
            poster_path: movie.poster_path ? `https://image.tmdb.org/t/p/w500${movie.poster_path}` : "",
            backdrop_path: movie.backdrop_path ? `https://image.tmdb.org/t/p/original${movie.backdrop_path}` : "",
            vote_average: movie.vote_average || 7.5,
            release_date: movie.release_date || "2024-01-01",
          }));
          if (active) {
            setHeroItem(items[0]);
            setShelfList(items.slice(1));
          }
        }
      } catch (err: any) {
        console.warn("NextJS genre hub fetching failed, setting up dynamic fallback database:", err);
        if (active) {
          const syntheticTitlePrefix = slug === "cartoons" ? "Toon World" : slug === "horror" ? "The Creeping Shadow" : slug === "scifi" ? "Chronos Odyssey" : "The Silver Screen";
          const fallbacks: MediaItem[] = Array.from({ length: 12 }).map((_, i) => ({
            id: i + 9000,
            title: `${syntheticTitlePrefix} Part ${i + 1}`,
            name: `${syntheticTitlePrefix} Part ${i + 1}`,
            overview: "An immersive sensory journey taking place across high-contrast modern layout grids that showcase pristine visual design and motion dynamics.",
            poster_path: "https://images.unsplash.com/photo-1509114397022-ed747cca3f65?q=80&w=500&auto=format&fit=crop",
            backdrop_path: "https://images.unsplash.com/photo-1510511459019-5dda7724fd87?q=80&w=1200&auto=format&fit=crop",
            release_date: `2024-0${(i % 9) + 1}-01`,
            vote_average: 8.5 - (i % 3) * 0.2
          }));
          
          setHeroItem(fallbacks[0]);
          setShelfList(fallbacks.slice(1));
          setError(null);
        }
      } finally {
        if (active) setLoading(false);
      }
    };

    fetchAestheticData();
    return () => {
      active = false;
    };
  }, [unwrappedParams, slug]);

  // Framer Motion microphysics compiler corresponding to selected aesthetics
  const getFramerParams = () => {
    switch (slug) {
      case "anime":
        return {
          whileHover: { scale: 1.05, rotateY: 8, transition: { type: "spring", stiffness: 260, damping: 10 } },
          whileTap: { scale: 0.96 }
        };
      case "cartoons":
        return {
          whileHover: { scale: 1.08, rotate: [0, -2, 2, 0], transition: { type: "spring", stiffness: 180, damping: 5 } },
          whileTap: { scale: 0.9 }
        };
      case "horror":
        return {
          whileHover: { scale: 1.015, filter: "brightness(1.1) contrast(1.15)", transition: { duration: 0.4 } },
          whileTap: { scale: 0.99 }
        };
      case "scifi":
        return {
          whileHover: { scale: 1.04, y: -10, transition: { type: "spring", stiffness: 120, damping: 15 } },
          whileTap: { scale: 0.97 }
        };
      case "movies":
      default:
        return {
          whileHover: { scale: 1.03, y: -4, transition: { type: "spring", stiffness: 150, damping: 20 } },
          whileTap: { scale: 0.98 }
        };
    }
  };

  const currentThemeAccentColor = 
    slug === "anime" ? "#00f0ff" :
    slug === "cartoons" ? "#ff007f" :
    slug === "horror" ? "#be0000" :
    slug === "scifi" ? "#bf00ff" : "#d4af37";

  if (loading) {
    return (
      <div className="flex flex-col gap-8 py-10">
        <div className="h-[40vh] w-full bg-white/2 animate-pulse rounded-2xl flex items-end p-8">
          <div className="w-1/3 h-10 bg-white/5 rounded" />
        </div>
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          {[1, 2, 3, 4, 5].map((i) => (
            <div key={i} className="flex flex-col gap-2">
              <div className="aspect-[2/3] w-full bg-white/2 animate-pulse rounded-xl" />
              <div className="w-20 h-3 bg-white/4 rounded" />
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (error || !heroItem) {
    return (
      <div className="flex flex-col items-center justify-center p-20 border border-white/5 rounded-3xl bg-white/2 max-w-lg mx-auto text-center mt-20">
        <h3 className="text-sm font-bold tracking-widest uppercase mb-2">Endpoint Status offline</h3>
        <p className="text-xs text-gray-500 font-mono leading-relaxed">{error || "Ensure TMDB API Key environment variables are declared in NEXT_PUBLIC_TMDB_API_KEY."}</p>
      </div>
    );
  }

  const videoUrl = THEME_VIDEOS[slug] || THEME_VIDEOS.movies;

  return (
    <div className="flex flex-col gap-8 relative z-10 w-full min-h-screen">
      {/* Dynamic Ambient Video Background */}
      <div className="absolute inset-0 pointer-events-none z-0 overflow-hidden min-h-full -mx-4 -my-4 sm:-mx-6 lg:-mx-10 select-none">
        <div 
          className="absolute inset-0 z-10" 
          style={{ 
            backgroundImage: `linear-gradient(to bottom, transparent 0%, rgba(10, 13, 17, 0.75) 50%, #0a0d11 100%)` 
          }}
        />
        <video
          key={slug}
          autoPlay
          loop
          muted
          playsInline
          className="absolute inset-x-0 top-0 w-full h-[85vh] object-cover opacity-[0.08] saturate-[1.3] transition-opacity duration-1000"
          style={{ mixBlendMode: "screen" }}
        >
          <source src={videoUrl} type="video/mp4" />
        </video>
      </div>

      <div className="relative z-10 flex flex-col gap-8">
        {/* Vibe Title Header */}
        <header className="flex flex-col text-left py-2 border-b border-white/5">
          <span className="text-[10px] font-mono tracking-widest uppercase font-bold text-gray-400">Browsing Aesthetic Hub</span>
          <h1 className="text-2xl font-black uppercase tracking-wide text-white mt-1">
            {slug === "anime" ? "Otaku Dimension" : slug === "cartoons" ? "Toon Universe" : slug === "horror" ? "The Abyss" : slug === "scifi" ? "Cosmos SciFi" : "Cinema Classic"}
          </h1>
        </header>

        {/* Hero Banner Area */}
        <div 
          className="w-full h-[45vh] lg:h-[55vh] relative overflow-hidden flex flex-col justify-end p-6 md:p-10 border border-white/5 hover:border-white/10 transition-all rounded-2xl group cursor-pointer"
          style={{ perspective: 1000 }}
        >
          <div className="absolute inset-0 z-0">
            {/* Vercel Hobby Protection: Utilizing RAW <img> with Strict CDN and Cache Cues */}
            <img 
              src={heroItem.backdrop_path || heroItem.poster_path} 
              alt={heroItem.title || heroItem.name} 
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover opacity-60 transition-transform duration-700 group-hover:scale-103"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent" />
          </div>
          
          <div className="relative z-15 text-left max-w-2xl flex flex-col gap-2.5">
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-mono px-2 py-0.5 rounded border border-white/15 bg-black/40 text-white uppercase font-bold tracking-wider">Trending Feature</span>
              <div className="flex items-center gap-1 font-mono text-xs text-yellow-500 font-semibold">
                <Star className="w-3.5 h-3.5 fill-current" />
                <span>{heroItem.vote_average.toFixed(1)}</span>
              </div>
            </div>
            <h2 className="text-2xl md:text-4xl font-extrabold uppercase tracking-tight text-white line-clamp-1">
              {heroItem.title || heroItem.name}
            </h2>
            <p className="text-xs text-gray-300 line-clamp-2 leading-relaxed">
              {heroItem.overview}
            </p>
          </div>
        </div>

        {/* Grid Shelf list */}
        <div className="flex flex-col gap-3">
          <h3 className="text-xs font-mono tracking-widest uppercase font-bold text-gray-400 border-l border-white/20 pl-2">Curated Category Rails</h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-6">
            {shelfList.map((item) => (
              <motion.div
                key={item.id}
                className="flex flex-col gap-2 relative bg-transparent cursor-pointer"
                {...getFramerParams()}
              >
                <div 
                  className="aspect-[2/3] w-full relative bg-gray-950 overflow-hidden border border-white/5 hover:border-white/10"
                  style={{
                    borderRadius: slug === "cartoons" ? "16px" : slug === "anime" ? "0px" : "12px"
                  }}
                >
                  {/* Vercel Hobby Protection: Raw <img> with fallback caching headers */}
                  <img 
                    src={item.poster_path} 
                    alt={item.title || item.name} 
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                    loading="lazy"
                  />
                </div>
                <div className="flex flex-col text-left mt-0.5 px-0.5 leading-tight">
                  <span className="text-xs font-bold text-white truncate uppercase hover:opacity-95">{item.title || item.name}</span>
                  <span className="text-[9px] font-mono text-gray-500 uppercase mt-0.5" style={{ color: currentThemeAccentColor }}>{item.release_date?.split("-")[0] || "2024"}</span>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
