import React from "react";
import { Metadata } from "next";

export type ThemeMode = "classic" | "anime" | "playful" | "abyss" | "cosmic";

interface ThemeConfig {
  bgColor: string;
  accentColor: string;
  logoGlow: string;
  fontFamily: string;
  cardRadius: string;
}

const NEXT_THEME_SPECS: Record<string, ThemeConfig> = {
  anime: {
    bgColor: "#0d1117",
    accentColor: "#00f0ff",
    logoGlow: "rgba(0, 240, 255, 0.4)",
    fontFamily: "var(--font-space-grotesk)",
    cardRadius: "rounded-none",
  },
  cartoons: {
    bgColor: "#0e0b16",
    accentColor: "#ff007f",
    logoGlow: "rgba(255, 0, 127, 0.4)",
    fontFamily: "var(--font-fredoka)",
    cardRadius: "rounded-2xl",
  },
  horror: {
    bgColor: "#050505",
    accentColor: "#be0000",
    logoGlow: "rgba(190, 0, 0, 0.3)",
    fontFamily: "var(--font-cinzel)",
    cardRadius: "rounded-none",
  },
  scifi: {
    bgColor: "#020210",
    accentColor: "#bf00ff",
    logoGlow: "rgba(191, 0, 255, 0.5)",
    fontFamily: "var(--font-orbitron)",
    cardRadius: "rounded-xl",
  },
  movies: {
    bgColor: "#0B0E11",
    accentColor: "#d4af37",
    logoGlow: "rgba(212, 175, 55, 0.4)",
    fontFamily: "var(--font-geist-sans)",
    cardRadius: "rounded-xl",
  },
};

// Next.js dynamic metadata generator
export async function generateMetadata({ params }: { params: { slug: string } }): Promise<Metadata> {
  const resolvedParams = await params;
  const slug = resolvedParams.slug;
  const titles: Record<string, string> = {
    anime: "Otaku Mode - Cyberpunk Anime Stream",
    cartoons: "Playful Mode - Family & Cartoons Hub",
    horror: "The Abyss - Editorial Horror Stream",
    scifi: "Cosmic - Space, Sci-Fi & Fantasy",
    movies: "Cinematic Classic - Movies, Action & Drama",
  };

  return {
    title: `Luminaa2 - ${titles[slug] || "Aesthetic Streaming"}`,
    description: `Browse curated streams in a dynamic visually morphed layout custom tailored for ${slug} fans.`,
  };
}

export default async function GenreLayout({
  children,
  params,
}: {
  children: React.ReactNode;
  params: { slug: string };
}) {
  const resolvedParams = await params;
  const slug = resolvedParams.slug || "movies";
  const theme = NEXT_THEME_SPECS[slug] || NEXT_THEME_SPECS.movies;

  return (
    <div
      className="min-h-screen text-gray-100 relative transition-colors duration-500 overflow-x-hidden pb-12"
      style={{ 
        backgroundColor: theme.bgColor,
        fontFamily: theme.fontFamily,
        colorScheme: "dark"
      }}
    >
      {/* Dynamic Ambient Blur Glows matching the Genre theme */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden z-0">
        <div
          className="absolute top-[-10%] left-[-10%] w-[45%] h-[45%] rounded-full blur-[130px] transition-all duration-700 opacity-20"
          style={{ backgroundColor: theme.accentColor }}
        />
        <div
          className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] rounded-full blur-[130px] transition-all duration-700 opacity-10"
          style={{ backgroundColor: theme.accentColor }}
        />
      </div>

      {/* Main Content Injector */}
      <div className="relative z-10 w-full max-w-7xl mx-auto px-4 sm:px-6 md:px-8 pt-6">
        {children}
      </div>
    </div>
  );
}
