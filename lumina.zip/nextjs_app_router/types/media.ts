export interface Genre {
  id: number;
  name: string;
}

export interface CastMember {
  id: number;
  name: string;
  character: string;
  profile_path: string | null;
}

export interface MediaItem {
  id: number;
  title?: string;
  name?: string;
  original_title?: string;
  original_name?: string;
  overview: string;
  poster_path: string;
  backdrop_path: string;
  media_type: 'movie' | 'tv';
  release_date?: string;
  first_air_date?: string;
  vote_average: number;
  vote_count?: number;
  genre_ids?: number[];
  genres?: Genre[];
}

export interface MediaDetails extends MediaItem {
  tagline?: string;
  runtime?: number;
  number_of_episodes?: number;
  number_of_seasons?: number;
  genres: Genre[];
  credits?: {
    cast: CastMember[];
  };
  status?: string;
}

// Supabase State Tracking for Watchlist
export interface SupabaseWatchlistItem {
  id: string; // db unique id
  profile_id: string; // linked user profile in supabase
  tmdb_id: number;
  media_type: 'movie' | 'tv';
  title: string;
  poster_path: string;
  backdrop_path: string;
  vote_average: number;
  release_date?: string;
  added_at: string; // ISO timestamp
}

// Supabase Playback Payload Synchronizer ("Continue Watching")
export interface ContinueWatchingPayload {
  tmdb_id: number;
  media_type: 'movie' | 'tv';
  title: string;
  poster_path: string;
  backdrop_path: string;
  active_season: number; // 1 for movies
  active_episode: number; // 1 for movies
  progress_percentage: number; // (current_time / duration) * 100
  absolute_stop_timestamp: number; // in seconds
  updated_at: string; // ISO timestamp
}
