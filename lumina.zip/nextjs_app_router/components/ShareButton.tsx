"use client";

import React, { useState } from "react";
import { Share2, Check } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

export const ShareButton: React.FC = () => {
  const [copied, setCopied] = useState(false);
  const [showToast, setShowToast] = useState(false);

  const handleShare = async () => {
    const shareUrl = typeof window !== "undefined" ? window.location.href : "";
    const shareData = {
      title: "Lumina Cinema",
      text: "Check out this film projection on Lumina Cinema!",
      url: shareUrl,
    };

    // Use Web Share API if natively supported and valid
    if (
      typeof navigator !== "undefined" &&
      navigator.share &&
      navigator.canShare &&
      navigator.canShare(shareData)
    ) {
      try {
        await navigator.share(shareData);
        return;
      } catch (err) {
        console.log("Native share handler dismissed, reverting to copy clipboard API...", err);
      }
    }

    // Standard high-reliability fallback to clipboard copy
    if (typeof navigator !== "undefined" && navigator.clipboard) {
      try {
        await navigator.clipboard.writeText(shareUrl);
        setCopied(true);
        setShowToast(true);
        setTimeout(() => setCopied(false), 2000);
        setTimeout(() => setShowToast(false), 3000);
      } catch (err) {
        console.error("Clipboard operational warning:", err);
      }
    }
  };

  return (
    <div className="relative inline-block">
      <motion.button
        type="button"
        onClick={handleShare}
        animate={copied ? { 
          scale: [1, 1.05, 1],
          borderColor: "rgba(16, 185, 129, 0.4)",
          backgroundColor: "rgba(16, 185, 129, 0.1)",
          boxShadow: "0 0 12px rgba(16, 185, 129, 0.2)"
        } : { 
          scale: 1,
          borderColor: "rgba(255, 255, 255, 0.05)",
          backgroundColor: "rgba(255, 255, 255, 0.05)",
          boxShadow: "none"
        }}
        transition={{ duration: 0.3, ease: "easeOut" }}
        className="flex items-center gap-2 px-3 py-1.5 sm:px-3.5 sm:py-2 rounded-xl border text-xs font-mono font-bold uppercase tracking-wider text-gray-300 hover:text-white cursor-pointer relative overflow-hidden active:scale-95 hover:border-rose-500/30 hover:bg-rose-500/5 transition-[border-color,background-color]"
        whileTap={{ scale: 0.95 }}
      >
        <AnimatePresence mode="wait">
          {copied ? (
            <motion.div
              key="check"
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.8, opacity: 0 }}
              className="flex items-center gap-1.5 text-emerald-400 font-bold"
            >
              <Check className="w-4 h-4 text-emerald-400 stroke-[2.5]" />
              <span>Copied!</span>
            </motion.div>
          ) : (
            <motion.div
              key="share"
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.8, opacity: 0 }}
              className="flex items-center gap-1.5"
            >
              <Share2 className="w-4 h-4 text-[#ff073a]" />
              <span>Share Frame</span>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.button>

      {/* Micro floating contextual alert */}
      <AnimatePresence>
        {showToast && (
          <motion.div
            initial={{ opacity: 0, y: 10, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 10, scale: 0.95 }}
            className="absolute top-full left-1/2 -translate-x-1/2 mt-2 z-50 whitespace-nowrap px-3 py-1 text-[9px] font-mono font-bold text-rose-400 bg-black/90 border border-rose-500/20 rounded-md shadow-xl backdrop-blur-md pointer-events-none"
          >
            LINK COPIED TO CLIPBOARD
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default ShareButton;
