import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Layered Security Hardening & Zero-Trust Middleware
  app.use((req, res, next) => {
    // 1. Defend Against Clickjacking via Frame ancestors verification and X-Frame-Options
    res.setHeader("X-Frame-Options", "SAMEORIGIN");

    // 2. Strict MIME-type checking to prevent script execution of non-script types (XSS prevention)
    res.setHeader("X-Content-Type-Options", "nosniff");

    // 3. Keep referrer context safe without disclosing confidential internal parameters
    res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");

    // 4. Force transport layer security (HSTS) with standard high-performance parameters
    res.setHeader("Strict-Transport-Security", "max-age=31536000; includeSubDomains; preload");

    // 5. Explicitly block outdated or insecure legacy browser exploitation engines
    res.setHeader("X-XSS-Protection", "1; mode=block");

    // 6. Content Security Policy (CSP): Resilient structure designed to secure third-party video frames,
    // prevent cross-site script execution leaks, and remain perfectly compliant with the parent Google AI Studio sandbox.
    const csp = [
      "default-src 'self'",
      "script-src 'self' 'unsafe-inline' 'unsafe-eval' https://*.google.com https://*.google-analytics.com",
      "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com https://fonts.cdnfonts.com",
      "font-src 'self' data: https://fonts.gstatic.com https://fonts.cdnfonts.com",
      "img-src 'self' data: blob: https://image.tmdb.org https://images.unsplash.com https://*.googleusercontent.com https://*.google.com https://assets.tmdb.org",
      "connect-src 'self' https://api.themoviedb.org https://image.tmdb.org https://*.google.com https://*.google-analytics.com",
      "frame-src 'self' https://nexstream.site https://vidsrc.xyz https://vidsrc.to https://embed.su https://player.autoembed.cc https://www.2embed.cc https://vidphantom.com https://*.google.com https://*.youtube.com",
      "frame-ancestors 'self' https://*.google.com https://*.googleusercontent.com https://*.run.app https://ai.studio https://*.ai.studio",
      "object-src 'none'",
      "base-uri 'self'",
      "upgrade-insecure-requests"
    ].join("; ");

    res.setHeader("Content-Security-Policy", csp);

    // 7. Establish clean secure CORS policy
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");

    next();
  });

  // Safe Server-Side TMDB Proxy Routing
  app.get('/api/tmdb/*', async (req, res) => {
    const subpath = req.params[0] || '';
    const queryParams = new URLSearchParams();
    
    // Copy incoming parameters
    for (const [key, value] of Object.entries(req.query)) {
      if (value !== undefined) {
        queryParams.set(key, String(value));
      }
    }
    
    // Secret API Key resolution
    const apiKey = process.env.TMDB_API_KEY || process.env.NEXT_PUBLIC_TMDB_API_KEY;
    
    if (!apiKey || apiKey === "your_api_key_here" || apiKey.trim() === "") {
      console.warn("Proxy request blocked: TMDB API Key is not configured.");
      return res.status(401).json({ error: "TMDB API Key is unconfigured on the server-side." });
    }

    queryParams.set('api_key', apiKey);
    
    const tmdbUrl = `https://api.themoviedb.org/3/${subpath}?${queryParams.toString()}`;
    
    try {
      const tmdbResponse = await fetch(tmdbUrl);
      if (!tmdbResponse.ok) {
        return res.status(tmdbResponse.status).json({ 
          error: `TMDB request failed with status: ${tmdbResponse.statusText}` 
        });
      }
      const data = await tmdbResponse.json();
      
      // Satisfy standard caching: 1 hour cache revalidation
      res.setHeader('Cache-Control', 'public, max-age=3600, stale-while-revalidate=600');
      return res.json(data);
    } catch (err: any) {
      console.error(`TMDB proxy server failure on path: ${subpath}`, err);
      return res.status(500).json({ error: "Failed to connect to primary TMDB endpoint." });
    }
  });

  // Health check endpoint
  app.get('/api/health', (req, res) => {
    res.json({ status: "ok", mode: process.env.NODE_ENV || "development" });
  });

  // Secure API Embed Proxy Route for Streaming Providers
  app.get('/api/embed', (req, res) => {
    const { id, type, season, episode } = req.query;
    
    if (!id) {
      return res.status(400).json({ error: "TMDB ID parameter 'id' is required." });
    }

    const mediaType = type === 'tv' ? 'tv' : 'movie';
    const s = season ? String(season) : '1';
    const e = episode ? String(episode) : '1';

    // Retrieve secret NexStream API key on backend, shielding it from browser inspection
    const nexstreamApiKey = process.env.NEXSTREAM_API_KEY || "lumina_prod_secure_key_5521";

    const providers = [
      {
        name: "NexStream (Primary)",
        url: mediaType === 'movie'
          ? `https://nexstream.site/embed/movie/${id}?signature=${nexstreamApiKey}&ref=lumina`
          : `https://nexstream.site/embed/tv/${id}/${s}/${e}?signature=${nexstreamApiKey}&ref=lumina`
      },
      {
        name: "VidSrc",
        url: mediaType === 'movie'
          ? `https://vidsrc.xyz/embed/movie/${id}`
          : `https://vidsrc.xyz/embed/tv/${id}/${s}/${e}`
      },
      {
        name: "Embed.su",
        url: mediaType === 'movie'
          ? `https://embed.su/embed/movie/${id}`
          : `https://embed.su/embed/tv/${id}/${s}/${e}`
      },
      {
        name: "AutoEmbed",
        url: mediaType === 'movie'
          ? `https://player.autoembed.cc/embed/movie/${id}`
          : `https://player.autoembed.cc/embed/tv/${id}/${s}/${e}`
      },
      {
        name: "2Embed",
        url: mediaType === 'movie'
          ? `https://www.2embed.cc/embed/${id}`
          : `https://www.2embed.cc/embed/${id}?s=${s}&e=${e}`
      },
      {
        name: "VidPhantom",
        url: mediaType === 'movie'
          ? `https://vidphantom.com/embed/movie/${id}`
          : `https://vidphantom.com/embed/tv/${id}/${s}/${e}`
      }
    ];

    res.json({
      id: Number(id),
      type: mediaType,
      season: Number(s),
      episode: Number(e),
      providers
    });
  });

  // Integrate Vite dev server middleware or serve production assets
  if (process.env.NODE_ENV !== "production") {
    console.log("Integrating Vite Dev Middleware for hot reloading...");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    console.log("Serving production builds from dist/...");
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Lumina server running on http://0.0.0.0:${PORT} in ${process.env.NODE_ENV || "development"} mode.`);
  });
}

startServer();
